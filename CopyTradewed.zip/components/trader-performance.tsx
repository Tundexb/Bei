"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface PerformanceData {
  monthly: {
    month: string
    return: number
  }[]
}

interface TraderPerformanceProps {
  performance: PerformanceData
}

export function TraderPerformance({ performance }: TraderPerformanceProps) {
  return (
    <div className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={performance.monthly}
          margin={{
            top: 5,
            right: 30,
            left: 20,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis dataKey="month" />
          <YAxis tickFormatter={(value) => `${value}%`} domain={[-10, "auto"]} />
          <Tooltip formatter={(value) => [`${value}%`, "Return"]} labelFormatter={(label) => `${label} 2023`} />
          <Bar
            dataKey="return"
            fill={(data) => (data.return >= 0 ? "hsl(var(--primary))" : "hsl(var(--destructive))")}
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

