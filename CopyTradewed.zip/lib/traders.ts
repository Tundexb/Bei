import { create } from "zustand"
import { persist } from "zustand/middleware"

export type Trader = {
  id: number
  name: string
  avatar: string
  initials: string
  roi: number
  winRate: number
  riskLevel: string
  followers: number
  trades: number
  following: boolean
}

type TradersState = {
  traders: Trader[]
  followedTraders: number[]
  toggleFollow: (traderId: number) => void
  isFollowing: (traderId: number) => boolean
  getTrader: (traderId: number) => Trader | undefined
}

// Mock traders data
const initialTraders: Trader[] = [
  {
    id: 1,
    name: "Alex Morgan",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "AM",
    roi: 32.4,
    winRate: 78,
    riskLevel: "Medium",
    followers: 1245,
    trades: 342,
    following: true,
  },
  {
    id: 2,
    name: "Sarah Chen",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "SC",
    roi: 28.7,
    winRate: 82,
    riskLevel: "Low",
    followers: 987,
    trades: 256,
    following: true,
  },
  {
    id: 3,
    name: "Michael Johnson",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "MJ",
    roi: 41.2,
    winRate: 71,
    riskLevel: "High",
    followers: 2134,
    trades: 512,
    following: true,
  },
  {
    id: 4,
    name: "David Wilson",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "DW",
    roi: 24.9,
    winRate: 75,
    riskLevel: "Medium",
    followers: 756,
    trades: 198,
    following: false,
  },
  {
    id: 5,
    name: "Emma Thompson",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "ET",
    roi: 36.8,
    winRate: 80,
    riskLevel: "Medium",
    followers: 1567,
    trades: 387,
    following: false,
  },
  {
    id: 6,
    name: "Robert Zhang",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "RZ",
    roi: 19.5,
    winRate: 68,
    riskLevel: "Low",
    followers: 432,
    trades: 156,
    following: false,
  },
  {
    id: 7,
    name: "Jessica Lee",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "JL",
    roi: 45.2,
    winRate: 73,
    riskLevel: "High",
    followers: 1876,
    trades: 423,
    following: false,
  },
  {
    id: 8,
    name: "Thomas Brown",
    avatar: "/placeholder.svg?height=40&width=40",
    initials: "TB",
    roi: 31.7,
    winRate: 77,
    riskLevel: "Medium",
    followers: 921,
    trades: 287,
    following: false,
  },
]

export const useTraders = create<TradersState>()(
  persist(
    (set, get) => ({
      traders: initialTraders,
      followedTraders: initialTraders.filter((t) => t.following).map((t) => t.id),
      toggleFollow: (traderId) => {
        set((state) => {
          const isCurrentlyFollowing = state.followedTraders.includes(traderId)

          // Update the traders array
          const updatedTraders = state.traders.map((trader) =>
            trader.id === traderId
              ? {
                  ...trader,
                  following: !isCurrentlyFollowing,
                  followers: isCurrentlyFollowing ? trader.followers - 1 : trader.followers + 1,
                }
              : trader,
          )

          // Update the followedTraders array
          const updatedFollowedTraders = isCurrentlyFollowing
            ? state.followedTraders.filter((id) => id !== traderId)
            : [...state.followedTraders, traderId]

          return {
            traders: updatedTraders,
            followedTraders: updatedFollowedTraders,
          }
        })
      },
      isFollowing: (traderId) => {
        return get().followedTraders.includes(traderId)
      },
      getTrader: (traderId) => {
        return get().traders.find((trader) => trader.id === traderId)
      },
    }),
    {
      name: "traders-storage",
    },
  ),
)

