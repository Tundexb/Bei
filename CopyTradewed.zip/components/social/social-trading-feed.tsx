"use client"

import type React from "react"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  BarChart2,
  Copy,
  DollarSign,
  Heart,
  ImageIcon,
  Loader2,
  MessageSquare,
  MoreHorizontal,
  PenSquare,
  Share2,
  Shield,
  Star,
  TrendingUp,
  LineChart,
  Users,
  AlertTriangle,
  Repeat2,
  Clock,
  TrendingDown,
} from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useAuth } from "@/lib/auth"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/router"

// Post type
type Post = {
  id: string
  author: {
    id: string
    name: string
    username: string
    avatar: string
    isVerified: boolean
    badges: string[]
  }
  content: string
  timestamp: string
  likes: number
  comments: number
  isLiked: boolean
  isSaved: boolean
  attachments?: {
    type: "image" | "chart" | "trade"
    url: string
    caption?: string
  }[]
  tradeDetails?: {
    symbol: string
    type: "buy" | "sell"
    entry: number
    target?: number
    stopLoss?: number
    result?: "win" | "loss"
    profit?: number
    profitPercentage?: number
  }
}

type Trade = {
  symbol: string
  type: "buy" | "sell"
  entry: number
  target?: number
  stopLoss?: number
  status?: "open" | "closed" | "cancelled"
  result?: "win" | "loss"
  profit?: number
  profitPercentage?: number
}

// Sample posts data
const samplePosts: Post[] = [
  {
    id: "post1",
    author: {
      id: "trader1",
      name: "Sarah Johnson",
      username: "sarahtrader",
      avatar: "/avatars/sarah.jpg",
      isVerified: true,
      badges: ["professional_trader", "consistent_performer"],
    },
    content:
      "Just opened a new position on $AAPL. Technical indicators are showing a strong uptrend. Target price is $190.",
    timestamp: new Date(Date.now() - 35 * 60 * 1000).toISOString(), // 35 minutes ago
    likes: 42,
    comments: 7,
    isLiked: true,
    isSaved: false,
    attachments: [
      {
        type: "chart",
        url: "/charts/eurusd-chart.jpg",
        caption: "EUR/USD 4H Chart",
      },
    ],
    tradeDetails: {
      symbol: "AAPL",
      type: "buy",
      entry: 175.5,
      target: 190.0,
      stopLoss: 170.0,
      status: "open",
    },
  },
  {
    id: "post2",
    author: {
      id: "user2",
      name: "Michael Chen",
      username: "miketrader",
      avatar: "/avatars/michael.jpg",
      isVerified: true,
      badges: ["risk_manager", "market_veteran"],
    },
    content:
      "Closed my AAPL position today with a nice profit. The tech sector is showing strength despite market uncertainties. Looking for new opportunities in the semiconductor space.",
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), // 3 hours ago
    likes: 78,
    comments: 12,
    isLiked: false,
    isSaved: true,
    tradeDetails: {
      symbol: "AAPL",
      type: "buy",
      entry: 187.5,
      target: 195.0,
      stopLoss: 182.0,
      result: "win",
      profit: 750,
      profitPercentage: 4.0,
    },
  },
  {
    id: "post3",
    author: {
      id: "user3",
      name: "Emma Wilson",
      username: "emmatrader",
      avatar: "/avatars/emma.jpg",
      isVerified: false,
      badges: ["active_trader"],
    },
    content:
      "Market analysis for today: The Fed's recent comments suggest potential rate cuts in the coming months. This could be bullish for growth stocks, especially in the tech sector.",
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
    likes: 31,
    comments: 5,
    isLiked: false,
    isSaved: false,
    attachments: [
      {
        type: "chart",
        url: "/charts/sp500-chart.jpg",
        caption: "S&P 500 Daily Chart",
      },
    ],
  },
  {
    id: "post4",
    author: {
      id: "user4",
      name: "David Rodriguez",
      avatar: "/avatars/david.jpg",
      isVerified: true,
      role: "trader",
      badges: ["diversified_trader", "community_contributor"],
    },
    content:
      "Bitcoin showing strength above $60K. The recent institutional adoption is a game-changer. I'm maintaining my long position with a trailing stop. What's your BTC strategy?",
    timestamp: "2023-11-21T06:15:00Z",
    likes: 105,
    comments: 23,
    shares: 7,
    liked: true,
    attachments: [
      {
        type: "chart",
        url: "/charts/btc-chart.jpg",
        caption: "BTC/USD Daily Chart",
      },
    ],
    tradeDetails: {
      symbol: "BTC/USD",
      type: "buy",
      entry: 58750,
      target: 65000,
      stopLoss: 55000,
      result: "open",
    },
  },
  {
    id: "post5",
    author: {
      id: "user5",
      name: "Sophia Lee",
      avatar: "/avatars/sophia.jpg",
      verified: true,
      role: "trader",
      badges: ["professional_trader", "winning_streak"],
    },
    content:
      "Just closed my GBP/JPY trade with a 120 pip profit! The strategy of trading the London-Tokyo session overlap continues to work well for me. Will share more setups tomorrow.",
    timestamp: "2023-11-21T06:15:00Z",
    likes: 67,
    comments: 9,
    shares: 0,
    liked: false,
    tradeDetails: {
      symbol: "GBP/JPY",
      type: "buy",
      entry: 186.5,
      target: 188.0,
      stopLoss: 185.8,
      result: "win",
      profit: 450,
      profitPercentage: 0.8,
    },
  },
]

// Badge mapping
const badgeInfo: Record<string, { icon: React.ReactNode; color: string }> = {
  professional_trader: { icon: <Shield className="h-3 w-3" />, color: "bg-purple-500" },
  consistent_performer: { icon: <TrendingUp className="h-3 w-3" />, color: "bg-green-500" },
  risk_manager: { icon: <Shield className="h-3 w-3" />, color: "bg-blue-500" },
  market_veteran: { icon: <Star className="h-3 w-3" />, color: "bg-orange-500" },
  active_trader: { icon: <BarChart2 className="h-3 w-3" />, color: "bg-purple-500" },
  diversified_trader: { icon: <Copy className="h-3 w-3" />, color: "bg-indigo-500" },
  community_contributor: { icon: <MessageSquare className="h-3 w-3" />, color: "bg-pink-500" },
  winning_streak: { icon: <TrendingUp className="h-3 w-3" />, color: "bg-yellow-500" },
}

export function SocialTradingFeed() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [posts, setPosts] = useState<Post[]>(samplePosts)
  const [newPostContent, setNewPostContent] = useState("")
  const [isPosting, setIsPosting] = useState(false)
  const [activeTab, setActiveTab] = useState("all")
  const router = useRouter()

  const handleLikePost = (postId: string) => {
    try {
      setPosts(
        posts.map((post) => {
          if (post.id === postId) {
            return {
              ...post,
              liked: !post.liked,
              likes: post.liked ? post.likes - 1 : post.likes + 1,
            }
          }
          return post
        }),
      )
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem processing your action. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleSharePost = (postId: string) => {
    try {
      toast({
        title: "Post shared",
        description: "The post has been shared to your profile.",
      })

      setPosts(
        posts.map((post) => {
          if (post.id === postId) {
            return {
              ...post,
              shares: post.shares + 1,
            }
          }
          return post
        }),
      )
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem sharing the post. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleSubmitPost = () => {
    try {
      if (!newPostContent.trim()) {
        toast({
          title: "Empty post",
          description: "Please enter some content for your post.",
          variant: "destructive",
        })
        return
      }

      const newPost: Post = {
        id: `post${Date.now()}`,
        author: {
          id: "currentUser",
          name: "Current User",
          avatar: "/avatars/default.jpg",
          isVerified: false,
          role: "user",
        },
        content: newPostContent,
        timestamp: new Date().toISOString(),
        likes: 0,
        comments: 0,
        shares: 0,
        liked: false,
      }

      setPosts([newPost, ...posts])
      setNewPostContent("")
      setIsPosting(false)

      toast({
        title: "Post published",
        description: "Your post has been published to the feed.",
      })
    } catch (error) {
      toast({
        title: "Signup failed",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleViewProfile = (userId: string) => {
    try {
      router.push(`/social/profile/${userId}`)
    } catch (error) {
      toast({
        title: "Navigation error",
        description: "There was a problem navigating to the profile. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleViewComments = (postId: string) => {
    try {
      router.push(`/social/post/${postId}`)
    } catch (error) {
      toast({
        title: "Navigation error",
        description: "There was a problem navigating to the comments. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleCopyTrade = (trade: Trade) => {
    try {
      toast({
        title: "Trade copied",
        description: `${trade.type.toUpperCase()} order for ${trade.symbol} has been added to your copy queue.`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem copying the trade. Please try again.",
        variant: "destructive",
      })
    }
  }

  const formatTimestamp = (timestamp: string) => {
    try {
      const date = new Date(timestamp)
      const now = new Date()
      const diffMs = now.getTime() - date.getTime()
      const diffMins = Math.round(diffMs / 60000)
      const diffHours = Math.round(diffMs / 3600000)
      const diffDays = Math.round(diffMs / 86400000)

      if (diffMins < 60) {
        return `${diffMins}m ago`
      } else if (diffHours < 24) {
        return `${diffHours}h ago`
      } else {
        return `${diffDays}d ago`
      }
    } catch (error) {
      return "Unknown time"
    }
  }

  const filteredPosts =
    activeTab === "all"
      ? posts
      : activeTab === "traders"
        ? posts.filter((post) => post.author.role === "trader")
        : activeTab === "signals"
          ? posts.filter((post) => post.tradeDetails)
          : posts

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Social Feed</h2>
        <p className="text-muted-foreground">Connect with traders and share insights</p>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex gap-3">
            <Avatar>
              <AvatarImage src={user?.avatar || "/avatars/default.jpg"} alt={user?.name || "User"} />
              <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <Textarea
                placeholder="Share your trading insights or ask a question..."
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                className="resize-none mb-3"
                rows={3}
              />
              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">
                    <ImageIcon className="mr-2 h-4 w-4" />
                    Image
                  </Button>
                  <Button variant="outline" size="sm">
                    <LineChart className="mr-2 h-4 w-4" />
                    Chart
                  </Button>
                  <Button variant="outline" size="sm">
                    <DollarSign className="mr-2 h-4 w-4" />
                    Trade
                  </Button>
                </div>
                <Button onClick={handleSubmitPost} disabled={!newPostContent.trim() || isPosting}>
                  {isPosting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Posting...
                    </>
                  ) : (
                    <>
                      <PenSquare className="mr-2 h-4 w-4" />
                      Post
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Posts</TabsTrigger>
          <TabsTrigger value="traders">Traders</TabsTrigger>
          <TabsTrigger value="signals">Signals</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6 space-y-4">
          {filteredPosts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onLike={handleLikePost}
              onShare={handleSharePost}
              handleCopyTrade={handleCopyTrade}
              handleViewComments={handleViewComments}
            />
          ))}
        </TabsContent>

        <TabsContent value="traders" className="mt-6 space-y-4">
          {filteredPosts.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                  <Users className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mb-2 text-lg font-semibold">No trader posts</h3>
                <p className="text-sm text-muted-foreground">Follow some traders to see their posts here.</p>
              </CardContent>
            </Card>
          ) : (
            filteredPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                onLike={handleLikePost}
                onShare={handleSharePost}
                handleCopyTrade={handleCopyTrade}
                handleViewComments={handleViewComments}
              />
            ))
          )}
        </TabsContent>

        <TabsContent value="signals" className="mt-6 space-y-4">
          {filteredPosts.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                  <BarChart2 className="h-6 w-6 text-muted-foreground" />
                </div>
                <h3 className="mb-2 text-lg font-medium">No trading signals</h3>
                <p className="text-sm text-muted-foreground">
                  Follow traders who share their signals to see them here.
                </p>
              </CardContent>
            </Card>
          ) : (
            filteredPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                onLike={handleLikePost}
                onShare={handleSharePost}
                handleCopyTrade={handleCopyTrade}
                handleViewComments={handleViewComments}
              />
            ))
          )}
        </TabsContent>

        <TabsContent value="following" className="mt-6 space-y-4">
          <Card>
            <CardContent className="p-8 text-center">
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-muted">
                <Users className="h-6 w-6 text-muted-foreground" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Follow some traders</h3>
              <p className="text-sm text-muted-foreground">
                You're not following anyone yet. Discover and follow traders to see their posts here.
              </p>
              <Button className="mt-4" onClick={() => router.push("/dashboard/traders")}>
                Discover Traders
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function PostCard({
  post,
  onLike,
  onShare,
  handleCopyTrade,
  handleViewComments,
}: {
  post: Post
  onLike: (id: string) => void
  onShare: (id: string) => void
  handleCopyTrade: (trade: Trade) => void
  handleViewComments: (postId: string) => void
}) {
  return (
    <Card>
      <CardHeader className="p-4 pb-0">
        <div className="flex justify-between">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src={post.author.avatar || "/avatars/default.jpg"} alt={post.author.name} />
              <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center">
                <span className="font-medium">{post.author.name}</span>
                {post.author.isVerified && (
                  <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700">
                    <Shield className="mr-1 h-3 w-3" />
                    Verified
                  </Badge>
                )}
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <span>@{post.author.username}</span>
                <span className="mx-1">•</span>
                <span>{formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}</span>
              </div>
            </div>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem
                onClick={() =>
                  toast({ title: "Following", description: `You are now following ${post.author.name}` })
                }
              >
                <Users className="mr-2 h-4 w-4" />
                Follow {post.author.name}
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() =>
                  toast({
                    title: "Trader Copied",
                    description: `You are now copying trades from ${post.author.name}`,
                  })
                }
              >
                <Repeat2 className="mr-2 h-4 w-4" />
                Copy this trader
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() =>
                  toast({
                    title: "Report Submitted",
                    description: "Thank you for helping keep our community safe",
                  })
                }
              >
                <AlertTriangle className="mr-2 h-4 w-4" />
                Report post
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </CardHeader>

      <CardContent className="p-4">
        <p className="whitespace-pre-line">{post.content}</p>

        {/* Trade details */}
        {post.tradeDetails && (
          <div className="mt-3 p-3 bg-muted rounded-md">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <Badge className={post.tradeDetails.type === "buy" ? "bg-green-500" : "bg-red-500"}>
                  {post.tradeDetails.type === "buy" ? (
                    <TrendingUp className="mr-1 h-3 w-3" />
                  ) : (
                    <TrendingDown className="mr-1 h-3 w-3" />
                  )}
                  {post.tradeDetails.type.toUpperCase()}
                </Badge>
                <span className="ml-2 font-bold">{post.tradeDetails.symbol}</span>
              </div>
              <Badge
                variant={
                  post.tradeDetails.result === "open"
                    ? "outline"
                    : post.tradeDetails.result === "win"
                      ? "default"
                      : "destructive"
                }
              >
                {post.tradeDetails.result === "open" ? (
                  <Clock className="mr-1 h-3 w-3" />
                ) : post.tradeDetails.result === "win" ? (
                  <TrendingUp className="mr-1 h-3 w-3" />
                ) : (
                  <TrendingDown className="mr-1 h-3 w-3" />
                )}
                {post.tradeDetails.result === "open"
                  ? "Open"
                  : post.tradeDetails.result === "win"
                    ? "Closed (Win)"
                    : "Closed (Loss)"\
                    : "Cancelled"}
              </Badge>
            </div>

            <div className="grid grid-cols-3 gap-2 text-sm">
              <div>
                <div className="text-muted-foreground">Entry</div>
                <div className="font-medium">{post.tradeDetails.entry}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Target</div>
                <div className="font-medium">{post.tradeDetails.target}</div>
              </div>
              <div>
                <div className="text-muted-foreground">Stop Loss</div>
                <div className="font-medium">{post.tradeDetails.stopLoss}</div>
              </div>
            </div>

            {post.tradeDetails.profit !== undefined && (
              <div className="mt-2 flex items-center">
                <div className="text-muted-foreground mr-2">Profit/Loss:</div>
                <div className={`font-medium ${post.tradeDetails.profit > 0 ? "text-green-500" : "text-red-500"}`}>
                  {post.tradeDetails.profit > 0 ? "+" : ""}
                  {post.tradeDetails.profit}%
                </div>
              </div>
            )}

            <div className="mt-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={() => handleCopyTrade(post.tradeDetails as Trade)}
              >
                <Repeat2 className="mr-1 h-4 w-4" />
                Copy This Trade
              </Button>
            </div>
          </div>
        )}

        {/* Attachments */}
        {post.attachments && post.attachments[0]?.type === 'image' && (
          <div className="mt-3">
            <img src={post.attachments[0].url || "/placeholder.svg"} alt="Post image" className="rounded-md w-full" />
          </div>
        )}

        {post.attachments && post.attachments[0]?.type === 'chart' && (
          <div className="mt-3">
            <img src={post.attachments[0].url || "/placeholder.svg"} alt="Chart" className="rounded-md w-full" />
          </div>
        )}
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onLike(post.id)}
            className={post.isLiked ? "text-primary" : ""}
          >
            <Heart className={`mr-1 h-4 w-4 ${post.isLiked ? "fill-primary" : ""}`} />
            {post.likes}
          </Button>

          <Button variant="ghost" size="sm" onClick={() => handleViewComments(post.id)}>
            <MessageSquare className="mr-1 h-4 w-4" />
            {post.comments}
          </Button>

          <Button variant="ghost" size="sm" onClick={() => onShare(post.id)}>
            <Share2 className="mr-1 h-4 w-4" />
            Share
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

