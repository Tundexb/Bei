"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { TrendingUp, Eye, EyeOff, Loader2, Check, X } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { useToast } from "@/components/ui/use-toast"
import { Progress } from "@/components/ui/progress"
import { sendEmail } from "@/lib/email-service"

export default function SignupPage() {
  const router = useRouter()
  const { signup } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [passwordStrength, setPasswordStrength] = useState(0)
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    terms: false,
    marketingConsent: false,
  })
  const [formErrors, setFormErrors] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    terms: "",
  })

  const passwordRequirements = [
    { id: "length", label: "At least 8 characters", met: formData.password.length >= 8 },
    { id: "uppercase", label: "At least 1 uppercase letter", met: /[A-Z]/.test(formData.password) },
    { id: "lowercase", label: "At least 1 lowercase letter", met: /[a-z]/.test(formData.password) },
    { id: "number", label: "At least 1 number", met: /[0-9]/.test(formData.password) },
    { id: "special", label: "At least 1 special character", met: /[^A-Za-z0-9]/.test(formData.password) },
  ]

  // Calculate password strength
  useEffect(() => {
    const metRequirements = passwordRequirements.filter((req) => req.met).length
    setPasswordStrength((metRequirements / passwordRequirements.length) * 100)
  }, [formData.password])

  const validateForm = () => {
    let valid = true
    const errors = {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      confirmPassword: "",
      terms: "",
    }

    // First name validation
    if (!formData.firstName.trim()) {
      errors.firstName = "First name is required"
      valid = false
    }

    // Last name validation
    if (!formData.lastName.trim()) {
      errors.lastName = "Last name is required"
      valid = false
    }

    // Email validation
    if (!formData.email) {
      errors.email = "Email is required"
      valid = false
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Email is invalid"
      valid = false
    }

    // Password validation
    if (!formData.password) {
      errors.password = "Password is required"
      valid = false
    } else if (passwordStrength < 60) {
      errors.password = "Password is not strong enough"
      valid = false
    }

    // Confirm password validation
    if (formData.password !== formData.confirmPassword) {
      errors.confirmPassword = "Passwords don't match"
      valid = false
    }

    // Terms validation
    if (!formData.terms) {
      errors.terms = "You must agree to the terms of service"
      valid = false
    }

    setFormErrors(errors)
    return valid
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }))

    // Clear error when user types
    if (formErrors[name as keyof typeof formErrors]) {
      setFormErrors((prev) => ({ ...prev, [name]: "" }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    setIsLoading(true)

    try {
      const fullName = `${formData.firstName} ${formData.lastName}`
      const success = await signup(fullName, formData.email, formData.password)

      if (success) {
        // Send welcome email
        await sendEmail({
          to: formData.email,
          template: "welcome",
          data: {
            name: fullName,
          },
        })

        toast({
          title: "Account created",
          description: "Welcome to TradeCopy! Your account has been created successfully.",
        })

        // Also show a toast about the welcome email
        toast({
          title: "Welcome email sent",
          description: "Check your inbox for a welcome email with getting started tips.",
        })

        router.push("/dashboard")
      } else {
        toast({
          title: "Signup failed",
          description: "An error occurred while creating your account. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Signup failed",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 40) return "bg-red-500"
    if (passwordStrength < 60) return "bg-orange-500"
    if (passwordStrength < 80) return "bg-yellow-500"
    return "bg-green-500"
  }

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-muted/40 p-4">
      <Link href="/" className="absolute left-8 top-8 flex items-center gap-2 md:left-12 md:top-12">
        <TrendingUp className="h-6 w-6" />
        <span className="text-xl font-bold">TradeCopy</span>
      </Link>

      <Card className="w-full max-w-md">
        <form onSubmit={handleSubmit}>
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold">Create an account</CardTitle>
            <CardDescription>Enter your information to create your TradeCopy account</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First name</Label>
                <Input
                  id="firstName"
                  name="firstName"
                  placeholder="John"
                  value={formData.firstName}
                  onChange={handleChange}
                  disabled={isLoading}
                  className={formErrors.firstName ? "border-red-500" : ""}
                />
                {formErrors.firstName && <p className="text-xs text-red-500">{formErrors.firstName}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last name</Label>
                <Input
                  id="lastName"
                  name="lastName"
                  placeholder="Doe"
                  value={formData.lastName}
                  onChange={handleChange}
                  disabled={isLoading}
                  className={formErrors.lastName ? "border-red-500" : ""}
                />
                {formErrors.lastName && <p className="text-xs text-red-500">{formErrors.lastName}</p>}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="name@example.com"
                value={formData.email}
                onChange={handleChange}
                disabled={isLoading}
                className={formErrors.email ? "border-red-500" : ""}
              />
              {formErrors.email && <p className="text-xs text-red-500">{formErrors.email}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleChange}
                  disabled={isLoading}
                  className={formErrors.password ? "border-red-500 pr-10" : "pr-10"}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                  onClick={() => setShowPassword(!showPassword)}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {formData.password && (
                <>
                  <div className="space-y-2 mt-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs">Password strength</span>
                      <span className="text-xs">
                        {passwordStrength < 40
                          ? "Weak"
                          : passwordStrength < 60
                            ? "Fair"
                            : passwordStrength < 80
                              ? "Good"
                              : "Strong"}
                      </span>
                    </div>
                    <Progress value={passwordStrength} className={getPasswordStrengthColor()} />
                  </div>
                  <div className="space-y-1 mt-2">
                    {passwordRequirements.map((req) => (
                      <div key={req.id} className="flex items-center text-xs">
                        {req.met ? (
                          <Check className="h-3 w-3 mr-2 text-green-500" />
                        ) : (
                          <X className="h-3 w-3 mr-2 text-red-500" />
                        )}
                        <span className={req.met ? "text-green-700" : "text-muted-foreground"}>{req.label}</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
              {formErrors.password && <p className="text-xs text-red-500">{formErrors.password}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Confirm password</Label>
              <div className="relative">
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  disabled={isLoading}
                  className={formErrors.confirmPassword ? "border-red-500 pr-10" : "pr-10"}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  tabIndex={-1}
                >
                  {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {formErrors.confirmPassword && <p className="text-xs text-red-500">{formErrors.confirmPassword}</p>}
            </div>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="terms"
                  name="terms"
                  checked={formData.terms}
                  onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, terms: checked === true }))}
                  disabled={isLoading}
                />
                <label
                  htmlFor="terms"
                  className={`text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${formErrors.terms ? "text-red-500" : ""}`}
                >
                  I agree to the{" "}
                  <Link href="/terms" className="text-primary hover:underline">
                    terms of service
                  </Link>{" "}
                  and{" "}
                  <Link href="/privacy" className="text-primary hover:underline">
                    privacy policy
                  </Link>
                </label>
              </div>
              {formErrors.terms && <p className="text-xs text-red-500">{formErrors.terms}</p>}
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="marketingConsent"
                name="marketingConsent"
                checked={formData.marketingConsent}
                onCheckedChange={(checked) => setFormData((prev) => ({ ...prev, marketingConsent: checked === true }))}
                disabled={isLoading}
              />
              <label
                htmlFor="marketingConsent"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                I agree to receive marketing communications from TradeCopy
              </label>
            </div>
            <Button className="w-full" type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating account...
                </>
              ) : (
                "Create account"
              )}
            </Button>
            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative px-4 text-xs uppercase bg-background text-muted-foreground">
                Or continue with
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="w-full" type="button" disabled={isLoading}>
                Google
              </Button>
              <Button variant="outline" className="w-full" type="button" disabled={isLoading}>
                Apple
              </Button>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-sm text-center text-muted-foreground">
              Already have an account?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Log in
              </Link>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

