"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useToast } from "@/components/ui/use-toast"
import { CheckCircle, Clock, RefreshCw, Server, Shield, XCircle } from "lucide-react"
import { useCopyTrading } from "@/lib/copy-trading"
import { useBrokerIntegration } from "@/lib/broker-integration"

export function StatusDashboard() {
  const { toast } = useToast()
  const { isEnabled } = useCopyTrading()
  const { getBrokerAccounts } = useBrokerIntegration()

  const [isLoading, setIsLoading] = useState(true)
  const [systemStatus, setSystemStatus] = useState({
    copyTradingEngine: { status: "unknown", latency: 0 },
    brokerConnections: { status: "unknown", count: 0 },
    marketDataFeed: { status: "unknown", latency: 0 },
    notificationSystem: { status: "unknown" },
    databaseSystem: { status: "unknown", latency: 0 },
    emailSystem: { status: "unknown" },
    lastUpdated: new Date().toISOString(),
  })

  // Simulate loading system status
  useEffect(() => {
    const checkSystemStatus = async () => {
      try {
        setIsLoading(true)

        // In a real app, these would be actual API calls to check system status
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Get broker accounts to check connection status
        const accounts = await getBrokerAccounts()

        setSystemStatus({
          copyTradingEngine: {
            status: isEnabled ? "operational" : "disabled",
            latency: Math.floor(Math.random() * 50) + 10,
          },
          brokerConnections: {
            status: accounts.length > 0 ? "operational" : "warning",
            count: accounts.length,
          },
          marketDataFeed: {
            status: "operational",
            latency: Math.floor(Math.random() * 100) + 50,
          },
          notificationSystem: {
            status: "operational",
          },
          databaseSystem: {
            status: "operational",
            latency: Math.floor(Math.random() * 20) + 5,
          },
          emailSystem: {
            status: process.env.SENDGRID_API_KEY ? "operational" : "warning",
          },
          lastUpdated: new Date().toISOString(),
        })
      } catch (error) {
        toast({
          title: "Error checking system status",
          description: "There was a problem checking the system status. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    checkSystemStatus()

    // Refresh status every 5 minutes
    const interval = setInterval(checkSystemStatus, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [isEnabled, getBrokerAccounts, toast])

  const handleRefresh = async () => {
    try {
      setIsLoading(true)

      // In a real app, these would be actual API calls to check system status
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Get broker accounts to check connection status
      const accounts = await getBrokerAccounts()

      setSystemStatus({
        ...systemStatus,
        copyTradingEngine: {
          status: isEnabled ? "operational" : "disabled",
          latency: Math.floor(Math.random() * 50) + 10,
        },
        brokerConnections: {
          status: accounts.length > 0 ? "operational" : "warning",
          count: accounts.length,
        },
        lastUpdated: new Date().toISOString(),
      })

      toast({
        title: "Status refreshed",
        description: "System status has been updated.",
      })
    } catch (error) {
      toast({
        title: "Error refreshing status",
        description: "There was a problem refreshing the system status. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const formatTimestamp = (timestamp: string) => {
    try {
      return new Date(timestamp).toLocaleString()
    } catch (error) {
      return "Unknown time"
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "operational":
        return (
          <Badge className="bg-green-500">
            <CheckCircle className="mr-1 h-3 w-3" />
            Operational
          </Badge>
        )
      case "warning":
        return (
          <Badge variant="outline" className="text-orange-500 border-orange-500">
            <Clock className="mr-1 h-3 w-3" />
            Warning
          </Badge>
        )
      case "error":
        return (
          <Badge variant="destructive">
            <XCircle className="mr-1 h-3 w-3" />
            Error
          </Badge>
        )
      case "disabled":
        return (
          <Badge variant="outline" className="text-gray-500">
            <Clock className="mr-1 h-3 w-3" />
            Disabled
          </Badge>
        )
      default:
        return (
          <Badge variant="outline">
            <Clock className="mr-1 h-3 w-3" />
            Unknown
          </Badge>
        )
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>System Status</CardTitle>
          <CardDescription>Current status of platform components</CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isLoading}>
          <RefreshCw className={`mr-2 h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Server className="mr-2 h-5 w-5 text-muted-foreground" />
                <div>
                  <div className="font-medium">Copy Trading Engine</div>
                  {systemStatus.copyTradingEngine.status === "operational" && (
                    <div className="text-xs text-muted-foreground">
                      Latency: {systemStatus.copyTradingEngine.latency}ms
                    </div>
                  )}
                </div>
              </div>
              {getStatusBadge(systemStatus.copyTradingEngine.status)}
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Shield className="mr-2 h-5 w-5 text-muted-foreground" />
                <div>
                  <div className="font-medium">Broker Connections</div>
                  <div className="text-xs text-muted-foreground">
                    {systemStatus.brokerConnections.count} active connections
                  </div>
                </div>
              </div>
              {getStatusBadge(systemStatus.brokerConnections.status)}
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Server className="mr-2 h-5 w-5 text-muted-foreground" />
                <div>
                  <div className="font-medium">Market Data Feed</div>
                  <div className="text-xs text-muted-foreground">Latency: {systemStatus.marketDataFeed.latency}ms</div>
                </div>
              </div>
              {getStatusBadge(systemStatus.marketDataFeed.status)}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Server className="mr-2 h-5 w-5 text-muted-foreground" />
                <div>
                  <div className="font-medium">Notification System</div>
                </div>
              </div>
              {getStatusBadge(systemStatus.notificationSystem.status)}
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Server className="mr-2 h-5 w-5 text-muted-foreground" />
                <div>
                  <div className="font-medium">Database System</div>
                  <div className="text-xs text-muted-foreground">Latency: {systemStatus.databaseSystem.latency}ms</div>
                </div>
              </div>
              {getStatusBadge(systemStatus.databaseSystem.status)}
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Server className="mr-2 h-5 w-5 text-muted-foreground" />
                <div>
                  <div className="font-medium">Email System</div>
                </div>
              </div>
              {getStatusBadge(systemStatus.emailSystem.status)}
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        Last updated: {formatTimestamp(systemStatus.lastUpdated)}
      </CardFooter>
    </Card>
  )
}

