"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Clock,
  FileCheck,
  FileText,
  HelpCircle,
  Loader2,
  LockKeyhole,
  Shield,
  Star,
  Upload,
  User,
  UserCheck,
} from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useAuth } from "@/lib/auth"

// Verification status types
type VerificationStatus = "unverified" | "pending" | "verified" | "rejected"

// Verification levels
type VerificationLevel = "basic" | "advanced" | "professional"

// Verification requirements
const verificationRequirements = {
  basic: [
    { id: "email", label: "Email Verification", completed: true },
    { id: "phone", label: "Phone Verification", completed: false },
    { id: "terms", label: "Terms Acceptance", completed: true },
  ],
  advanced: [
    { id: "identity", label: "Identity Verification", completed: false },
    { id: "address", label: "Address Verification", completed: false },
    { id: "broker", label: "Broker Account Linking", completed: false },
  ],
  professional: [
    { id: "trading_history", label: "Trading History Verification", completed: false },
    { id: "performance", label: "Performance Verification", completed: false },
    { id: "compliance", label: "Compliance Check", completed: false },
  ],
}

export function TraderVerification() {
  const { toast } = useToast()
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState<VerificationLevel>("basic")
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus>("unverified")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false)
  const [currentDocument, setCurrentDocument] = useState("")
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isUploading, setIsUploading] = useState(false)

  // Form states
  const [formData, setFormData] = useState({
    fullName: "",
    dateOfBirth: "",
    nationality: "",
    address: "",
    city: "",
    postalCode: "",
    country: "",
    phoneNumber: "",
    tradingExperience: "",
    brokerAccounts: "",
    publicProfile: true,
    showRealName: false,
    showPerformance: true,
  })

  // Calculate completion percentage for each level
  const getCompletionPercentage = (level: VerificationLevel) => {
    const requirements = verificationRequirements[level]
    const completed = requirements.filter((req) => req.completed).length
    return Math.round((completed / requirements.length) * 100)
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleSubmitVerification = () => {
    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      setVerificationStatus("pending")
      setIsSubmitting(false)

      toast({
        title: "Verification Submitted",
        description: "Your verification request has been submitted and is pending review.",
      })
    }, 2000)
  }

  const handleUploadDocument = (documentType: string) => {
    setCurrentDocument(documentType)
    setUploadDialogOpen(true)
  }

  const simulateUpload = () => {
    setIsUploading(true)
    setUploadProgress(0)

    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)

          // Mark the requirement as completed
          if (currentDocument === "identity" || currentDocument === "address") {
            verificationRequirements.advanced.find((req) => req.id === currentDocument)!.completed = true
          } else if (currentDocument === "trading_history" || currentDocument === "performance") {
            verificationRequirements.professional.find((req) => req.id === currentDocument)!.completed = true
          }

          setTimeout(() => {
            setUploadDialogOpen(false)

            toast({
              title: "Document Uploaded",
              description: "Your document has been successfully uploaded and is pending review.",
            })
          }, 500)

          return 100
        }
        return prev + 10
      })
    }, 300)
  }

  const getVerificationStatusBadge = () => {
    switch (verificationStatus) {
      case "unverified":
        return (
          <Badge variant="outline" className="text-muted-foreground">
            Unverified
          </Badge>
        )
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
            Pending Review
          </Badge>
        )
      case "verified":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Verified</Badge>
      case "rejected":
        return <Badge variant="destructive">Rejected</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Trader Verification</h2>
          <p className="text-muted-foreground">Verify your identity to unlock trader features and build trust</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">Status:</span>
          {getVerificationStatusBadge()}
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Verification Progress</CardTitle>
          <CardDescription>Complete all verification steps to become a verified trader</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant={getCompletionPercentage("basic") === 100 ? "default" : "outline"}>Basic</Badge>
                <span className="text-sm">{getCompletionPercentage("basic")}% Complete</span>
              </div>
              {getCompletionPercentage("basic") === 100 && (
                <Badge variant="outline" className="bg-green-100 text-green-800">
                  <CheckCircle2 className="mr-1 h-3 w-3" />
                  Completed
                </Badge>
              )}
            </div>
            <Progress value={getCompletionPercentage("basic")} className="h-2" />

            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                <Badge variant={getCompletionPercentage("advanced") === 100 ? "default" : "outline"}>Advanced</Badge>
                <span className="text-sm">{getCompletionPercentage("advanced")}% Complete</span>
              </div>
              {getCompletionPercentage("advanced") === 100 && (
                <Badge variant="outline" className="bg-green-100 text-green-800">
                  <CheckCircle2 className="mr-1 h-3 w-3" />
                  Completed
                </Badge>
              )}
            </div>
            <Progress value={getCompletionPercentage("advanced")} className="h-2" />

            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center gap-2">
                <Badge variant={getCompletionPercentage("professional") === 100 ? "default" : "outline"}>
                  Professional
                </Badge>
                <span className="text-sm">{getCompletionPercentage("professional")}% Complete</span>
              </div>
              {getCompletionPercentage("professional") === 100 && (
                <Badge variant="outline" className="bg-green-100 text-green-800">
                  <CheckCircle2 className="mr-1 h-3 w-3" />
                  Completed
                </Badge>
              )}
            </div>
            <Progress value={getCompletionPercentage("professional")} className="h-2" />
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="basic" value={activeTab} onValueChange={(value) => setActiveTab(value as VerificationLevel)}>
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="basic" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            Basic
          </TabsTrigger>
          <TabsTrigger value="advanced" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Advanced
          </TabsTrigger>
          <TabsTrigger value="professional" className="flex items-center gap-2">
            <Star className="h-4 w-4" />
            Professional
          </TabsTrigger>
        </TabsList>

        <TabsContent value="basic">
          <Card>
            <CardHeader>
              <CardTitle>Basic Verification</CardTitle>
              <CardDescription>Verify your basic information to get started</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                {verificationRequirements.basic.map((req) => (
                  <div key={req.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      {req.completed ? (
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                      ) : (
                        <Clock className="h-5 w-5 text-muted-foreground" />
                      )}
                      <span>{req.label}</span>
                    </div>
                    {!req.completed && (
                      <Button size="sm" variant="outline">
                        Complete
                        <ChevronRight className="ml-2 h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <Separator className="my-4" />

              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="fullName">Full Name</Label>
                    <Input
                      id="fullName"
                      name="fullName"
                      value={formData.fullName}
                      onChange={handleInputChange}
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dateOfBirth">Date of Birth</Label>
                    <Input
                      id="dateOfBirth"
                      name="dateOfBirth"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nationality">Nationality</Label>
                    <Input
                      id="nationality"
                      name="nationality"
                      value={formData.nationality}
                      onChange={handleInputChange}
                      placeholder="Enter your nationality"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phoneNumber">Phone Number</Label>
                    <Input
                      id="phoneNumber"
                      name="phoneNumber"
                      value={formData.phoneNumber}
                      onChange={handleInputChange}
                      placeholder="Enter your phone number"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="flex items-center text-sm text-muted-foreground">
                <LockKeyhole className="mr-2 h-4 w-4" />
                Your information is securely stored
              </div>
              <Button onClick={handleSubmitVerification} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    Save & Continue
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="advanced">
          <Card>
            <CardHeader>
              <CardTitle>Advanced Verification</CardTitle>
              <CardDescription>Verify your identity and address to unlock more features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                {verificationRequirements.advanced.map((req) => (
                  <div key={req.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      {req.completed ? (
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                      ) : (
                        <Clock className="h-5 w-5 text-muted-foreground" />
                      )}
                      <span>{req.label}</span>
                    </div>
                    {!req.completed && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          if (req.id === "identity" || req.id === "address") {
                            handleUploadDocument(req.id)
                          } else if (req.id === "broker") {
                            // Navigate to broker connection page
                            window.location.href = "/dashboard/connect-broker"
                          }
                        }}
                      >
                        {req.id === "identity" || req.id === "address" ? (
                          <>
                            Upload Document
                            <Upload className="ml-2 h-4 w-4" />
                          </>
                        ) : req.id === "broker" ? (
                          <>
                            Connect Broker
                            <ChevronRight className="ml-2 h-4 w-4" />
                          </>
                        ) : (
                          <>
                            Complete
                            <ChevronRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <Separator className="my-4" />

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Input
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    placeholder="Enter your street address"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      placeholder="Enter your city"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="postalCode">Postal Code</Label>
                    <Input
                      id="postalCode"
                      name="postalCode"
                      value={formData.postalCode}
                      onChange={handleInputChange}
                      placeholder="Enter your postal code"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="country">Country</Label>
                    <Input
                      id="country"
                      name="country"
                      value={formData.country}
                      onChange={handleInputChange}
                      placeholder="Enter your country"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="flex items-center text-sm text-muted-foreground">
                <Shield className="mr-2 h-4 w-4" />
                ID verification helps prevent fraud
              </div>
              <Button onClick={handleSubmitVerification} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    Save & Continue
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="professional">
          <Card>
            <CardHeader>
              <CardTitle>Professional Trader Verification</CardTitle>
              <CardDescription>Verify your trading experience to become a professional trader</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                {verificationRequirements.professional.map((req) => (
                  <div key={req.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      {req.completed ? (
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                      ) : (
                        <Clock className="h-5 w-5 text-muted-foreground" />
                      )}
                      <span>{req.label}</span>

                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-6 w-6">
                              <HelpCircle className="h-4 w-4 text-muted-foreground" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="max-w-xs">
                              {req.id === "trading_history"
                                ? "Upload trading statements from your broker to verify your trading history."
                                : req.id === "performance"
                                  ? "Provide performance metrics from your trading accounts."
                                  : "Complete compliance checks to ensure regulatory compliance."}
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    {!req.completed && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          if (req.id === "trading_history" || req.id === "performance") {
                            handleUploadDocument(req.id)
                          }
                        }}
                      >
                        {req.id === "trading_history" || req.id === "performance" ? (
                          <>
                            Upload Document
                            <Upload className="ml-2 h-4 w-4" />
                          </>
                        ) : (
                          <>
                            Complete
                            <ChevronRight className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <Separator className="my-4" />

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="tradingExperience">Trading Experience</Label>
                  <Textarea
                    id="tradingExperience"
                    name="tradingExperience"
                    value={formData.tradingExperience}
                    onChange={handleInputChange}
                    placeholder="Describe your trading experience, strategies, and expertise"
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="brokerAccounts">Broker Accounts</Label>
                  <Textarea
                    id="brokerAccounts"
                    name="brokerAccounts"
                    value={formData.brokerAccounts}
                    onChange={handleInputChange}
                    placeholder="List your broker accounts and trading platforms you use"
                    rows={2}
                  />
                </div>

                <div className="space-y-4 pt-2">
                  <h3 className="text-sm font-medium">Profile Settings</h3>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="publicProfile">Public Profile</Label>
                      <p className="text-sm text-muted-foreground">Make your trader profile visible to other users</p>
                    </div>
                    <Switch
                      id="publicProfile"
                      checked={formData.publicProfile}
                      onCheckedChange={(checked) => handleSwitchChange("publicProfile", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="showRealName">Show Real Name</Label>
                      <p className="text-sm text-muted-foreground">Display your real name instead of username</p>
                    </div>
                    <Switch
                      id="showRealName"
                      checked={formData.showRealName}
                      onCheckedChange={(checked) => handleSwitchChange("showRealName", checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="showPerformance">Show Performance</Label>
                      <p className="text-sm text-muted-foreground">Display your trading performance metrics publicly</p>
                    </div>
                    <Switch
                      id="showPerformance"
                      checked={formData.showPerformance}
                      onCheckedChange={(checked) => handleSwitchChange("showPerformance", checked)}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <div className="flex items-center text-sm text-muted-foreground">
                <UserCheck className="mr-2 h-4 w-4" />
                Professional verification increases your visibility
              </div>
              <Button onClick={handleSubmitVerification} disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    Submit for Verification
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Document Upload Dialog */}
      <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Upload Document</DialogTitle>
            <DialogDescription>
              {currentDocument === "identity"
                ? "Upload a valid government-issued ID (passport, driver's license, or ID card)"
                : currentDocument === "address"
                  ? "Upload a proof of address (utility bill, bank statement, etc. less than 3 months old)"
                  : currentDocument === "trading_history"
                    ? "Upload trading statements from your broker (last 6 months)"
                    : "Upload performance metrics from your trading accounts"}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center">
              <FileText className="h-10 w-10 text-muted-foreground mb-2" />
              <p className="text-sm text-center text-muted-foreground mb-2">
                Drag and drop your document here, or click to browse
              </p>
              <Button variant="outline" disabled={isUploading}>
                <Upload className="mr-2 h-4 w-4" />
                Browse Files
              </Button>
            </div>

            {isUploading && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Uploading document...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}

            <div className="text-sm text-muted-foreground">
              <p className="flex items-center">
                <AlertCircle className="h-4 w-4 mr-2" />
                Supported formats: JPG, PNG, PDF (max 10MB)
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setUploadDialogOpen(false)} disabled={isUploading}>
              Cancel
            </Button>
            <Button onClick={simulateUpload} disabled={isUploading}>
              {isUploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <FileCheck className="mr-2 h-4 w-4" />
                  Upload Document
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

