"use client"
import { useToast } from "@/components/ui/use-toast"

// Sample performance data
const performanceData = {
  overall: {
    totalProfit: 12450.75,
    profitPercentage: 18.7,
    winRate: 62.5,
    totalTrades: 48,
    winningTrades: 30,
    losingTrades: 18,
    averageWin: 650.25,
    averageLoss: 320.45,
    largestWin: 2150.8,
    largestLoss: 875.3,
    profitFactor: 2.3,
    sharpeRatio: 1.8,
    maxDrawdown: 8.2,
    maxDrawdownAmount: 3250.4,
    averageHoldingTime: "3d 4h",
    bestDay: "2023-11-15",
    worstDay: "2023-10-22",
    bestDayAmount: 1850.25,
    worstDayAmount: -1250.75,
    monthlyPerformance: [
      { month: "Jan", profit: 1250.5, profitPercentage: 2.1 },
      { month: "Feb", profit: 1850.25, profitPercentage: 3.0 },
      { month: "Mar", profit: -750.4, profitPercentage: -1.2 },
      { month: "Apr", profit: 2150.8, profitPercentage: 3.4 },
      { month: "May", profit: 1450.3, profitPercentage: 2.2 },
      { month: "Jun", profit: 950.75, profitPercentage: 1.4 },
      { month: "Jul", profit: -450.25, profitPercentage: -0.7 },
      { month: "Aug", profit: 1750.4, profitPercentage: 2.6 },
      { month: "Sep", profit: 2250.6, profitPercentage: 3.3 },
      { month: "Oct", profit: 1050.2, profitPercentage: 1.5 },
      { month: "Nov", profit: 1650.35, profitPercentage: 2.3 },
      { month: "Dec", profit: -750.75, profitPercentage: -1.0 },
    ],
  },
  stocks: {
    totalProfit: 7850.5,
    profitPercentage: 15.2,
    winRate: 58.3,
    totalTrades: 24,
    winningTrades: 14,
    losingTrades: 10,
    averageWin: 750.45,
    averageLoss: 280.35,
    largestWin: 1850.6,
    largestLoss: 650.2,
    profitFactor: 2.1,
    sharpeRatio: 1.6,
    maxDrawdown: 7.5,
    maxDrawdownAmount: 2150.3,
    averageHoldingTime: "5d 2h",
    bestDay: "2023-11-15",
    worstDay: "2023-10-22",
    bestDayAmount: 1450.25,
    worstDayAmount: -850.75,
  },
  forex: {
    totalProfit: 3250.25,
    profitPercentage: 22.4,
    winRate: 68.7,
    totalTrades: 16,
    winningTrades: 11,
    losingTrades: 5,
    averageWin: 450.35,
    averageLoss: 220.45,
    largestWin: 1250.6,
    largestLoss: 450.2,
    profitFactor: 2.8,
    sharpeRatio: 2.1,
    maxDrawdown: 5.2,
    maxDrawdownAmount: 950.3,
    averageHoldingTime: "1d 6h",
    bestDay: "2023-09-05",
    worstDay: "2023-07-12",
    bestDayAmount: 950.25,
    worstDayAmount: -450.75,
  },
  crypto: {
    totalProfit: 1350.0,
    profitPercentage: 28.5,
    winRate: 62.5,
    totalTrades: 8,
    winningTrades: 5,
    losingTrades: 3,
    averageWin: 550.25,
    averageLoss: 350.45,
    largestWin: 950.8,
    largestLoss: 550.3,
    profitFactor: 2.6,
    sharpeRatio: 1.9,
    maxDrawdown: 12.5,
    maxDrawdownAmount: 750.4,
    averageHoldingTime: "2d 12h",
    bestDay: "2023-08-22",
    worstDay: "2023-10-05",
    bestDayAmount: 750.25,
    worstDayAmount: -550.75,
  },
}

export function PerformanceMetrics() {
  const { toast } = useToast()

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Performance Metrics</h2>
          <p className="text-muted-foreground">Analyze your trading performance across different markets</p>
        </div>
      </div>
    </div>
  )
}

