"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BrokerConnectionWizard } from "@/components/broker-connection-wizard"
import { useRouter } from "next/navigation"
import { ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function ConnectBrokerPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("stocks")

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center">
        <Button variant="ghost" size="sm" onClick={() => router.back()} className="mr-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <h1 className="text-3xl font-bold">Connect Broker</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Connect Your Trading Account</CardTitle>
          <CardDescription>
            Connect your brokerage account to enable copy trading. Your credentials are securely encrypted.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="stocks" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="stocks">Stocks</TabsTrigger>
              <TabsTrigger value="forex">Forex</TabsTrigger>
              <TabsTrigger value="crypto">Crypto</TabsTrigger>
            </TabsList>
            <TabsContent value="stocks">
              <BrokerConnectionWizard category="stocks" />
            </TabsContent>
            <TabsContent value="forex">
              <BrokerConnectionWizard category="forex" />
            </TabsContent>
            <TabsContent value="crypto">
              <BrokerConnectionWizard category="crypto" />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

