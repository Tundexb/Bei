"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { CopyTradingOverview } from "@/components/copy-trading-overview"
import { CopiedTradesHistory } from "@/components/copied-trades-history"
import { CopyTradingPerformance } from "@/components/copy-trading-performance"
import { CopyTradingActivity } from "@/components/copy-trading-activity"
import { useRouter } from "next/navigation"
import { Settings, AlertCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { useCopyTrading } from "@/lib/copy-trading"
import { CopyTradingEngine } from "@/components/copy-trading-engine"

export default function CopyTradingDashboardPage() {
  const router = useRouter()
  const { isEnabled } = useCopyTrading()
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Copy Trading Dashboard</h1>
        <Button variant="outline" onClick={() => router.push("/dashboard/settings/copy-trading")}>
          <Settings className="mr-2 h-4 w-4" />
          Copy Trading Settings
        </Button>
      </div>

      {!isEnabled && (
        <Alert variant="warning">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Copy Trading is disabled</AlertTitle>
          <AlertDescription>
            You need to enable copy trading in your settings to start copying trades from traders you follow.
            <Button
              variant="link"
              className="h-auto p-0 ml-2"
              onClick={() => router.push("/dashboard/settings/copy-trading")}
            >
              Go to settings
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <CopyTradingEngine />

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="history">Trade History</TabsTrigger>
          <TabsTrigger value="activity">Activity Log</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <CopyTradingOverview />
        </TabsContent>
        <TabsContent value="performance" className="space-y-4">
          <CopyTradingPerformance />
        </TabsContent>
        <TabsContent value="history" className="space-y-4">
          <CopiedTradesHistory />
        </TabsContent>
        <TabsContent value="activity" className="space-y-4">
          <CopyTradingActivity />
        </TabsContent>
      </Tabs>
    </div>
  )
}

