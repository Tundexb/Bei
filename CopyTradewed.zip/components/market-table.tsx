"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, TrendingDown, Plus, AlertCircle } from "lucide-react"
import { useMarket, type MarketAsset } from "@/lib/market"
import { usePortfolio } from "@/lib/portfolio"
import { useToast } from "@/components/ui/use-toast"
import { useNotifications } from "@/lib/notifications"
import { useAuth } from "@/lib/auth"
import { sendEmail } from "@/lib/email-service"

// Sample data for different market types
const marketData = {
  stocks: [
    {
      symbol: "AAPL",
      name: "Apple Inc.",
      price: 187.42,
      change: 1.24,
      changePercent: 0.67,
      volume: "32.5M",
      marketCap: "2.94T",
      type: "stock" as const,
    },
    {
      symbol: "MSFT",
      name: "Microsoft Corp.",
      price: 412.65,
      change: 3.78,
      changePercent: 0.92,
      volume: "28.1M",
      marketCap: "3.07T",
      type: "stock" as const,
    },
    {
      symbol: "GOOGL",
      name: "Alphabet Inc.",
      price: 142.89,
      change: -0.56,
      changePercent: -0.39,
      volume: "18.7M",
      marketCap: "1.82T",
      type: "stock" as const,
    },
    {
      symbol: "AMZN",
      name: "Amazon.com Inc.",
      price: 178.12,
      change: 2.34,
      changePercent: 1.33,
      volume: "25.3M",
      marketCap: "1.85T",
      type: "stock" as const,
    },
    {
      symbol: "NVDA",
      name: "NVIDIA Corp.",
      price: 824.36,
      change: 12.45,
      changePercent: 1.53,
      volume: "42.8M",
      marketCap: "2.03T",
      type: "stock" as const,
    },
    {
      symbol: "TSLA",
      name: "Tesla Inc.",
      price: 215.65,
      change: -3.24,
      changePercent: -1.48,
      volume: "35.2M",
      marketCap: "685.4B",
      type: "stock" as const,
    },
    {
      symbol: "META",
      name: "Meta Platforms Inc.",
      price: 342.78,
      change: 5.67,
      changePercent: 1.68,
      volume: "22.6M",
      marketCap: "878.3B",
      type: "stock" as const,
    },
    {
      symbol: "NFLX",
      name: "Netflix Inc.",
      price: 678.92,
      change: 10.34,
      changePercent: 1.55,
      volume: "8.7M",
      marketCap: "298.5B",
      type: "stock" as const,
    },
  ],
  crypto: [
    {
      symbol: "BTC",
      name: "Bitcoin",
      price: 62487.23,
      change: 1245.67,
      changePercent: 2.03,
      volume: "$42.8B",
      marketCap: "$1.22T",
      type: "crypto" as const,
    },
    {
      symbol: "ETH",
      name: "Ethereum",
      price: 3421.56,
      change: 87.34,
      changePercent: 2.62,
      volume: "$28.3B",
      marketCap: "$411.2B",
      type: "crypto" as const,
    },
    {
      symbol: "SOL",
      name: "Solana",
      price: 142.78,
      change: -3.45,
      changePercent: -2.36,
      volume: "$12.5B",
      marketCap: "$62.8B",
      type: "crypto" as const,
    },
    {
      symbol: "ADA",
      name: "Cardano",
      price: 0.58,
      change: 0.02,
      changePercent: 3.57,
      volume: "$1.8B",
      marketCap: "$20.5B",
      type: "crypto" as const,
    },
    {
      symbol: "DOT",
      name: "Polkadot",
      price: 7.23,
      change: 0.18,
      changePercent: 2.55,
      volume: "$982.3M",
      marketCap: "$9.2B",
      type: "crypto" as const,
    },
    {
      symbol: "DOGE",
      name: "Dogecoin",
      price: 0.12,
      change: -0.01,
      changePercent: -7.69,
      volume: "$2.1B",
      marketCap: "$17.3B",
      type: "crypto" as const,
    },
    {
      symbol: "LINK",
      name: "Chainlink",
      price: 14.56,
      change: 0.87,
      changePercent: 6.35,
      volume: "$1.2B",
      marketCap: "$8.7B",
      type: "crypto" as const,
    },
    {
      symbol: "AVAX",
      name: "Avalanche",
      price: 32.45,
      change: 1.23,
      changePercent: 3.94,
      volume: "$1.5B",
      marketCap: "$12.1B",
      type: "crypto" as const,
    },
  ],
  forex: [
    {
      symbol: "EUR/USD",
      name: "Euro / US Dollar",
      price: 1.0842,
      change: -0.0012,
      changePercent: -0.11,
      volume: "$98.7B",
      range: "1.0830-1.0865",
      type: "forex" as const,
    },
    {
      symbol: "GBP/USD",
      name: "British Pound / US Dollar",
      price: 1.2654,
      change: 0.0023,
      changePercent: 0.18,
      volume: "$72.3B",
      range: "1.2630-1.2680",
      type: "forex" as const,
    },
    {
      symbol: "USD/JPY",
      name: "US Dollar / Japanese Yen",
      price: 151.23,
      change: 0.45,
      changePercent: 0.3,
      volume: "$84.5B",
      range: "150.80-151.40",
      type: "forex" as const,
    },
    {
      symbol: "USD/CAD",
      name: "US Dollar / Canadian Dollar",
      price: 1.3542,
      change: -0.0034,
      changePercent: -0.25,
      volume: "$45.2B",
      range: "1.3520-1.3580",
      type: "forex" as const,
    },
    {
      symbol: "AUD/USD",
      name: "Australian Dollar / US Dollar",
      price: 0.6587,
      change: 0.0021,
      changePercent: 0.32,
      volume: "$38.9B",
      range: "0.6570-0.6600",
      type: "forex" as const,
    },
    {
      symbol: "NZD/USD",
      name: "New Zealand Dollar / US Dollar",
      price: 0.5978,
      change: 0.0015,
      changePercent: 0.25,
      volume: "$22.1B",
      range: "0.5960-0.5990",
      type: "forex" as const,
    },
    {
      symbol: "USD/CHF",
      name: "US Dollar / Swiss Franc",
      price: 0.8923,
      change: -0.0018,
      changePercent: -0.2,
      volume: "$32.7B",
      range: "0.8910-0.8950",
      type: "forex" as const,
    },
    {
      symbol: "EUR/GBP",
      name: "Euro / British Pound",
      price: 0.8567,
      change: -0.0025,
      changePercent: -0.29,
      volume: "$28.4B",
      range: "0.8550-0.8590",
      type: "forex" as const,
    },
  ],
}

interface MarketTableProps {
  type: "stocks" | "crypto" | "forex"
}

export function MarketTable({ type }: MarketTableProps) {
  const { addToWatchlist, isInWatchlist } = useMarket()
  const { addPosition, addTrade, updateBalance } = usePortfolio()
  const { addNotification } = useNotifications()
  const { user } = useAuth()
  const { toast } = useToast()

  const [selectedAsset, setSelectedAsset] = useState<MarketAsset | null>(null)
  const [tradeDialogOpen, setTradeDialogOpen] = useState(false)
  const [orderType, setOrderType] = useState<"BUY" | "SELL">("BUY")
  const [quantity, setQuantity] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const data = marketData[type]

  const handleTrade = (asset: MarketAsset) => {
    setSelectedAsset(asset)
    setOrderType("BUY")
    setQuantity("")
    setTradeDialogOpen(true)
  }

  const handleAddToWatchlist = (asset: MarketAsset) => {
    if (!isInWatchlist(asset.symbol)) {
      addToWatchlist(asset)
      toast({
        title: "Added to watchlist",
        description: `${asset.symbol} has been added to your watchlist.`,
      })
    } else {
      toast({
        title: "Already in watchlist",
        description: `${asset.symbol} is already in your watchlist.`,
      })
    }
  }

  const calculateTotal = () => {
    if (!selectedAsset || !quantity || isNaN(Number.parseFloat(quantity))) return 0
    return selectedAsset.price * Number.parseFloat(quantity)
  }

  const handleExecuteTrade = async () => {
    if (!selectedAsset || !quantity || isNaN(Number.parseFloat(quantity))) {
      toast({
        title: "Invalid quantity",
        description: "Please enter a valid quantity.",
        variant: "destructive",
      })
      return
    }

    const total = calculateTotal()

    setIsProcessing(true)

    // Simulate API call
    setTimeout(async () => {
      try {
        const tradeId = Date.now().toString()
        const parsedQuantity = Number.parseFloat(quantity)

        // Add trade to history
        addTrade({
          id: tradeId,
          symbol: selectedAsset.symbol,
          name: selectedAsset.name,
          type: orderType,
          price: selectedAsset.price,
          quantity: parsedQuantity,
          total: total,
          date: new Date().toISOString(),
          status: "executed",
        })

        // If BUY, add position
        if (orderType === "BUY") {
          addPosition({
            id: tradeId,
            symbol: selectedAsset.symbol,
            name: selectedAsset.name,
            type: selectedAsset.type,
            entryPrice: selectedAsset.price,
            currentPrice: selectedAsset.price,
            quantity: parsedQuantity,
            openDate: new Date().toISOString(),
          })

          // Deduct from balance
          updateBalance(-total)
        } else {
          // Add to balance for SELL
          updateBalance(total)
        }

        // Add notification
        addNotification({
          title: "Trade Executed",
          message: `Your order to ${orderType.toLowerCase()} ${parsedQuantity} ${selectedAsset.symbol} at ${selectedAsset.price.toLocaleString()} has been executed.`,
          type: "trade",
          link: "/dashboard/portfolio",
        })

        // Send trade executed email
        if (user?.email) {
          await sendEmail({
            to: user.email,
            template: "trade-executed",
            data: {
              symbol: selectedAsset.symbol,
              type: orderType,
              price: selectedAsset.price.toLocaleString(),
              quantity: parsedQuantity,
              total: total.toLocaleString(),
              time: new Date().toLocaleString(),
            },
          })
        }

        toast({
          title: "Trade executed",
          description: `Your ${orderType.toLowerCase()} order for ${selectedAsset.symbol} has been executed successfully.`,
        })

        setTradeDialogOpen(false)
      } catch (error) {
        toast({
          title: "Trade failed",
          description: "An error occurred while executing your trade. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsProcessing(false)
      }
    }, 1500)
  }

  return (
    <div className="space-y-4">
      <div className="overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Symbol</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Change</TableHead>
              <TableHead>{type === "forex" ? "Range" : "Volume"}</TableHead>
              <TableHead>{type === "forex" ? "Volume" : "Market Cap"}</TableHead>
              <TableHead className="text-right">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.map((asset) => (
              <TableRow key={asset.symbol}>
                <TableCell className="font-medium">{asset.symbol}</TableCell>
                <TableCell>{asset.name}</TableCell>
                <TableCell>
                  {type === "forex"
                    ? asset.price.toFixed(4)
                    : type === "crypto" && asset.price < 1
                      ? `$${asset.price.toFixed(4)}`
                      : `$${asset.price.toLocaleString()}`}
                </TableCell>
                <TableCell>
                  <div className={`flex items-center gap-1 ${asset.change >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {asset.change >= 0 ? (
                      <>
                        +{type === "forex" ? asset.change.toFixed(4) : asset.change.toLocaleString()} (
                        {asset.changePercent.toFixed(2)}%)
                        <TrendingUp className="h-4 w-4" />
                      </>
                    ) : (
                      <>
                        {type === "forex" ? asset.change.toFixed(4) : asset.change.toLocaleString()} (
                        {asset.changePercent.toFixed(2)}%)
                        <TrendingDown className="h-4 w-4" />
                      </>
                    )}
                  </div>
                </TableCell>
                <TableCell>{type === "forex" ? asset.range : asset.volume}</TableCell>
                <TableCell>{type === "forex" ? asset.volume : asset.marketCap}</TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleTrade(asset)}>
                      Trade
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleAddToWatchlist(asset)}>
                      <Plus className="h-4 w-4" />
                      <span className="sr-only">Add to watchlist</span>
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={tradeDialogOpen} onOpenChange={setTradeDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Trade {selectedAsset?.symbol}</DialogTitle>
            <DialogDescription>
              {selectedAsset?.name} -{" "}
              {selectedAsset?.type === "forex"
                ? selectedAsset?.price?.toFixed(4)
                : selectedAsset?.type === "crypto" && selectedAsset?.price < 1
                  ? `$${selectedAsset?.price?.toFixed(4)}`
                  : `$${selectedAsset?.price?.toLocaleString()}`}
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="market" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="market">Market</TabsTrigger>
              <TabsTrigger value="limit">Limit</TabsTrigger>
              <TabsTrigger value="stop">Stop</TabsTrigger>
            </TabsList>
            <TabsContent value="market" className="space-y-4 pt-4">
              <div className="flex items-center justify-between">
                <div className="grid gap-2">
                  <Label htmlFor="quantity">Quantity</Label>
                  <Input
                    id="quantity"
                    placeholder="Enter quantity"
                    value={quantity}
                    onChange={(e) => setQuantity(e.target.value)}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="total">Total</Label>
                  <Input id="total" placeholder="Total amount" value={calculateTotal().toLocaleString()} readOnly />
                </div>
              </div>
              <div className="grid gap-2">
                <Label>Order Type</Label>
                <div className="flex gap-2">
                  <Button
                    className={`w-full ${orderType === "BUY" ? "" : "opacity-50"}`}
                    onClick={() => setOrderType("BUY")}
                  >
                    Buy
                  </Button>
                  <Button
                    variant="destructive"
                    className={`w-full ${orderType === "SELL" ? "" : "opacity-50"}`}
                    onClick={() => setOrderType("SELL")}
                  >
                    Sell
                  </Button>
                </div>
              </div>
              <div className="flex items-center gap-2 rounded-md bg-muted p-3 text-sm">
                <AlertCircle className="h-4 w-4 text-muted-foreground" />
                <p className="text-muted-foreground">Market orders execute immediately at the current market price.</p>
              </div>
            </TabsContent>
            <TabsContent value="limit" className="space-y-4 pt-4">
              <div className="grid gap-2">
                <Label htmlFor="limit-price">Limit Price</Label>
                <Input id="limit-price" placeholder="Enter limit price" />
              </div>
              <div className="flex items-center justify-between">
                <div className="grid gap-2">
                  <Label htmlFor="limit-quantity">Quantity</Label>
                  <Input id="limit-quantity" placeholder="Enter quantity" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="limit-total">Total</Label>
                  <Input id="limit-total" placeholder="Total amount" readOnly />
                </div>
              </div>
              <div className="grid gap-2">
                <Label>Order Type</Label>
                <div className="flex gap-2">
                  <Button className="w-full">Buy</Button>
                  <Button variant="destructive" className="w-full">
                    Sell
                  </Button>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="stop" className="space-y-4 pt-4">
              <div className="grid gap-2">
                <Label htmlFor="stop-price">Stop Price</Label>
                <Input id="stop-price" placeholder="Enter stop price" />
              </div>
              <div className="flex items-center justify-between">
                <div className="grid gap-2">
                  <Label htmlFor="stop-quantity">Quantity</Label>
                  <Input id="stop-quantity" placeholder="Enter quantity" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="stop-total">Total</Label>
                  <Input id="stop-total" placeholder="Total amount" readOnly />
                </div>
              </div>
              <div className="grid gap-2">
                <Label>Order Type</Label>
                <div className="flex gap-2">
                  <Button className="w-full">Buy</Button>
                  <Button variant="destructive" className="w-full">
                    Sell
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => setTradeDialogOpen(false)} disabled={isProcessing}>
              Cancel
            </Button>
            <Button onClick={handleExecuteTrade} disabled={isProcessing}>
              {isProcessing ? "Processing..." : "Place Order"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

