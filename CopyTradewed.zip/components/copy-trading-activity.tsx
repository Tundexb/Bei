"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, TrendingUp, Settings, AlertCircle, DollarSign, User, Filter, Clock } from "lucide-react"
import { useCopyTrading } from "@/lib/copy-trading"
import { formatDistanceToNow } from "date-fns"

export function CopyTradingActivity() {
  const { activities } = useCopyTrading()
  const [searchQuery, setSearchQuery] = useState("")
  const [typeFilter, setTypeFilter] = useState("all")

  // Filter activities based on search query and type filter
  const filteredActivities = activities.filter((activity) => {
    const matchesSearch = activity.description.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesType = typeFilter === "all" || activity.type === typeFilter

    return matchesSearch && matchesType
  })

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "trade_copied":
        return <TrendingUp className="h-5 w-5 text-blue-500" />
      case "trade_executed":
        return <DollarSign className="h-5 w-5 text-green-500" />
      case "trade_failed":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      case "position_closed":
        return <DollarSign className="h-5 w-5 text-purple-500" />
      case "settings_changed":
        return <Settings className="h-5 w-5 text-amber-500" />
      case "trader_followed":
        return <User className="h-5 w-5 text-green-500" />
      case "trader_unfollowed":
        return <User className="h-5 w-5 text-red-500" />
      case "copy_trading_enabled":
        return <TrendingUp className="h-5 w-5 text-green-500" />
      case "copy_trading_disabled":
        return <TrendingUp className="h-5 w-5 text-red-500" />
      case "risk_limit_reached":
        return <AlertCircle className="h-5 w-5 text-amber-500" />
      default:
        return <Clock className="h-5 w-5 text-muted-foreground" />
    }
  }

  const getActivityTypeBadge = (type: string) => {
    switch (type) {
      case "trade_copied":
        return <Badge className="bg-blue-100 text-blue-800">Trade Copied</Badge>
      case "trade_executed":
        return <Badge className="bg-green-100 text-green-800">Trade Executed</Badge>
      case "trade_failed":
        return <Badge variant="destructive">Trade Failed</Badge>
      case "position_closed":
        return <Badge className="bg-purple-100 text-purple-800">Position Closed</Badge>
      case "settings_changed":
        return <Badge className="bg-amber-100 text-amber-800">Settings Changed</Badge>
      case "trader_followed":
        return <Badge className="bg-green-100 text-green-800">Trader Followed</Badge>
      case "trader_unfollowed":
        return <Badge variant="outline">Trader Unfollowed</Badge>
      case "copy_trading_enabled":
        return <Badge className="bg-green-100 text-green-800">Copy Trading Enabled</Badge>
      case "copy_trading_disabled":
        return <Badge variant="destructive">Copy Trading Disabled</Badge>
      case "risk_limit_reached":
        return <Badge className="bg-amber-100 text-amber-800">Risk Limit Reached</Badge>
      default:
        return <Badge variant="outline">{type.replace(/_/g, " ")}</Badge>
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Activity Log</CardTitle>
        <CardDescription>Detailed log of all copy trading activities</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div className="relative w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search activities..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="mr-2 h-4 w-4" />
              <SelectValue placeholder="Activity Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Activities</SelectItem>
              <SelectItem value="trade_copied">Trade Copied</SelectItem>
              <SelectItem value="trade_executed">Trade Executed</SelectItem>
              <SelectItem value="trade_failed">Trade Failed</SelectItem>
              <SelectItem value="position_closed">Position Closed</SelectItem>
              <SelectItem value="settings_changed">Settings Changed</SelectItem>
              <SelectItem value="trader_followed">Trader Followed</SelectItem>
              <SelectItem value="trader_unfollowed">Trader Unfollowed</SelectItem>
              <SelectItem value="copy_trading_enabled">Copy Trading Enabled</SelectItem>
              <SelectItem value="copy_trading_disabled">Copy Trading Disabled</SelectItem>
              <SelectItem value="risk_limit_reached">Risk Limit Reached</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {filteredActivities.length > 0 ? (
          <div className="space-y-4">
            {filteredActivities.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3 border-b pb-4 last:border-0 last:pb-0">
                <div className="mt-0.5">{getActivityIcon(activity.type)}</div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        {getActivityTypeBadge(activity.type)}
                        <span className="text-sm font-medium">{activity.description}</span>
                      </div>
                      {activity.metadata && (
                        <div className="mt-1 text-xs text-muted-foreground">
                          {activity.metadata.symbol && (
                            <span>
                              {activity.metadata.type} {activity.metadata.symbol}
                              {activity.metadata.price && ` @ $${activity.metadata.price}`}
                              {activity.metadata.quantity && ` × ${activity.metadata.quantity}`}
                              {activity.metadata.total && ` = $${activity.metadata.total}`}
                            </span>
                          )}
                          {activity.metadata.traderName && !activity.metadata.symbol && (
                            <span>Trader: {activity.metadata.traderName}</span>
                          )}
                          {activity.metadata.ruleName && <span>Rule: {activity.metadata.ruleName}</span>}
                          {activity.metadata.reason && <span>Reason: {activity.metadata.reason}</span>}
                        </div>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground whitespace-nowrap">
                      {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-8">
            <Clock className="h-10 w-10 text-muted-foreground mb-2" />
            <p className="text-muted-foreground">No activities found matching your filters.</p>
            {(searchQuery || typeFilter !== "all") && (
              <Button
                variant="link"
                onClick={() => {
                  setSearchQuery("")
                  setTypeFilter("all")
                }}
              >
                Clear filters
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

