"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useTraders } from "@/lib/traders"
import { useToast } from "@/components/ui/use-toast"
import { Award, Check, Search, TrendingUp, Users } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface TraderDiscoveryStepProps {
  onboardingData: any
  updateOnboardingData: (data: any) => void
}

export function TraderDiscoveryStep({ onboardingData, updateOnboardingData }: TraderDiscoveryStepProps) {
  const { traders, toggleFollow } = useTraders()
  const { toast } = useToast()

  const [searchTerm, setSearchTerm] = useState("")
  const [sortBy, setSortBy] = useState("performance")
  const [selectedTraders, setSelectedTraders] = useState<number[]>([])

  // Filter traders based on risk profile if available
  const filteredTraders = traders.filter((trader) => {
    // Filter by search term
    if (searchTerm && !trader.name.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false
    }

    // Filter by risk profile if available
    if (onboardingData.riskProfile) {
      if (onboardingData.riskProfile === "conservative" && trader.riskLevel !== "Low") {
        return false
      }
      if (onboardingData.riskProfile === "moderate" && trader.riskLevel === "High") {
        return false
      }
    }

    return true
  })

  // Sort traders
  const sortedTraders = [...filteredTraders].sort((a, b) => {
    if (sortBy === "performance") return b.roi - a.roi
    if (sortBy === "followers") return b.followers - a.followers
    if (sortBy === "winRate") return b.winRate - a.winRate
    return 0
  })

  const handleToggleTrader = (traderId: number) => {
    setSelectedTraders((prev) => {
      if (prev.includes(traderId)) {
        return prev.filter((id) => id !== traderId)
      } else {
        return [...prev, traderId]
      }
    })
  }

  const handleFollowTraders = () => {
    // Follow selected traders
    selectedTraders.forEach((traderId) => {
      if (!traders.find((t) => t.id === traderId)?.following) {
        toggleFollow(traderId)
      }
    })

    // Update onboarding data
    updateOnboardingData({ followedTraders: selectedTraders })

    toast({
      title: "Traders followed",
      description: `You are now following ${selectedTraders.length} traders.`,
    })
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold">Discover Traders</h2>
        <p className="text-muted-foreground">Find and follow traders that match your trading style and risk profile</p>
      </div>

      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search traders..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="performance">Best Performance</SelectItem>
            <SelectItem value="followers">Most Followers</SelectItem>
            <SelectItem value="winRate">Highest Win Rate</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {onboardingData.riskProfile && (
        <div className="flex items-center gap-2 text-sm">
          <span>Filtered for your {onboardingData.riskProfile} risk profile</span>
          <Badge variant="outline" className="capitalize">
            {onboardingData.riskProfile}
          </Badge>
        </div>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {sortedTraders.map((trader) => (
          <Card
            key={trader.id}
            className={`cursor-pointer transition-all hover:border-primary ${
              selectedTraders.includes(trader.id) ? "border-2 border-primary" : ""
            }`}
            onClick={() => handleToggleTrader(trader.id)}
          >
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={trader.avatar} alt={trader.name} />
                    <AvatarFallback>{trader.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium flex items-center">
                      {trader.name}
                      {trader.verified && <Award className="ml-1 h-4 w-4 text-blue-500" />}
                    </div>
                    <div className="text-xs text-muted-foreground">{trader.trades} trades</div>
                  </div>
                </div>

                {selectedTraders.includes(trader.id) && (
                  <div className="rounded-full bg-primary/10 p-1">
                    <Check className="h-4 w-4 text-primary" />
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2 mt-4">
                <div>
                  <p className="text-xs text-muted-foreground">Monthly Return</p>
                  <p className="text-sm font-medium text-green-600 flex items-center">
                    <TrendingUp className="mr-1 h-3 w-3" />
                    {trader.roi}%
                  </p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Win Rate</p>
                  <p className="text-sm font-medium">{trader.winRate}%</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Followers</p>
                  <p className="text-sm font-medium flex items-center">
                    <Users className="mr-1 h-3 w-3" />
                    {trader.followers}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Button onClick={handleFollowTraders} disabled={selectedTraders.length === 0} className="mt-4">
        Follow Selected Traders ({selectedTraders.length})
      </Button>
    </div>
  )
}

