"use client"

import { Card, CardContent } from "@/components/ui/card"
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"

interface TraderRiskAnalysisProps {
  traderId: number
}

// This would normally come from an API
const riskData = {
  assetAllocation: [
    { name: "Stocks", value: 65 },
    { name: "ETFs", value: 20 },
    { name: "Forex", value: 10 },
    { name: "Crypto", value: 5 },
  ],
  sectorExposure: [
    { name: "Technology", value: 45 },
    { name: "Healthcare", value: 15 },
    { name: "Finance", value: 20 },
    { name: "Consumer", value: 10 },
    { name: "Energy", value: 10 },
  ],
  riskMetrics: {
    sharpeRatio: 1.8,
    sortinoRatio: 2.3,
    maxDrawdown: 12.4,
    volatility: 15.2,
    beta: 1.2,
    alpha: 8.5,
  },
}

const COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--primary) / 0.8)",
  "hsl(var(--primary) / 0.6)",
  "hsl(var(--primary) / 0.4)",
  "hsl(var(--primary) / 0.2)",
]

export function TraderRiskAnalysis({ traderId }: TraderRiskAnalysisProps) {
  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-sm font-medium mb-4">Asset Allocation</h3>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={riskData.assetAllocation}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {riskData.assetAllocation.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value}%`, "Allocation"]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <h3 className="text-sm font-medium mb-4">Sector Exposure</h3>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={riskData.sectorExposure}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {riskData.sectorExposure.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value}%`, "Exposure"]} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="pt-6">
          <h3 className="text-sm font-medium mb-4">Risk Metrics</h3>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-3">
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Sharpe Ratio</p>
              <p className="text-lg font-medium">{riskData.riskMetrics.sharpeRatio}</p>
              <p className="text-xs text-muted-foreground">Higher is better</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Sortino Ratio</p>
              <p className="text-lg font-medium">{riskData.riskMetrics.sortinoRatio}</p>
              <p className="text-xs text-muted-foreground">Higher is better</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Max Drawdown</p>
              <p className="text-lg font-medium">{riskData.riskMetrics.maxDrawdown}%</p>
              <p className="text-xs text-muted-foreground">Lower is better</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Volatility</p>
              <p className="text-lg font-medium">{riskData.riskMetrics.volatility}%</p>
              <p className="text-xs text-muted-foreground">Annualized</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Beta</p>
              <p className="text-lg font-medium">{riskData.riskMetrics.beta}</p>
              <p className="text-xs text-muted-foreground">Market correlation</p>
            </div>
            <div className="space-y-1">
              <p className="text-xs text-muted-foreground">Alpha</p>
              <p className="text-lg font-medium">{riskData.riskMetrics.alpha}%</p>
              <p className="text-xs text-muted-foreground">Excess return</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

