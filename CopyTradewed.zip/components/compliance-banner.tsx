"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { AlertTriangle, X } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export function ComplianceBanner() {
  const [isVisible, setIsVisible] = useState(false)
  const [hasAcknowledged, setHasAcknowledged] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    // Check if user has already acknowledged the disclaimer
    const acknowledged = localStorage.getItem("riskDisclaimerAcknowledged")
    if (acknowledged) {
      setHasAcknowledged(true)
    } else {
      setIsVisible(true)
    }
  }, [])

  const handleAcknowledge = () => {
    localStorage.setItem("riskDisclaimerAcknowledged", "true")
    setHasAcknowledged(true)
    setIsVisible(false)

    toast({
      title: "Disclaimer Acknowledged",
      description: "You have acknowledged the risk disclaimer.",
    })
  }

  const handleDismiss = () => {
    setIsVisible(false)
  }

  if (!isVisible) return null

  return (
    <Card className="fixed bottom-4 left-4 right-4 z-50 max-w-2xl mx-auto">
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          <AlertTriangle className="h-6 w-6 text-amber-500 flex-shrink-0 mt-1" />
          <div className="flex-1">
            <h3 className="font-medium mb-2">Risk Disclaimer</h3>
            <p className="text-sm text-muted-foreground mb-2">
              Copy trading involves substantial risk of loss and is not suitable for all investors. Past performance is
              not indicative of future results. The value of your investments can go down as well as up, and you may not
              get back the amount you invested.
            </p>
            <p className="text-sm text-muted-foreground mb-4">
              By using this platform, you acknowledge that you have read and understood our full risk disclosure and
              terms of service.
            </p>
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={handleDismiss}>
                Dismiss
              </Button>
              <Button size="sm" onClick={handleAcknowledge}>
                I Understand the Risks
              </Button>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={handleDismiss}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

