"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, Settings } from "lucide-react"
import { useTraders } from "@/lib/traders"
import { useRouter } from "next/navigation"

export function FollowedTraders() {
  const router = useRouter()
  const { traders } = useTraders()

  // Get only followed traders
  const followedTraders = traders.filter((trader) => trader.following)

  return (
    <Card>
      <CardHeader className="flex flex-row items-center">
        <div className="flex-1">
          <CardTitle>Followed Traders</CardTitle>
          <CardDescription>Traders you are currently copying</CardDescription>
        </div>
        <Button variant="ghost" size="icon" onClick={() => router.push("/dashboard/settings/copy-settings")}>
          <Settings className="h-4 w-4" />
          <span className="sr-only">Settings</span>
        </Button>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {followedTraders.length > 0 ? (
            followedTraders.map((trader) => (
              <div key={trader.id} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={trader.avatar} alt={trader.name} />
                    <AvatarFallback>{trader.initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{trader.name}</div>
                    <div className="text-xs text-muted-foreground">Last trade: 2 hours ago</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="text-sm font-medium text-green-600">+{trader.roi}%</div>
                  <TrendingUp className="h-4 w-4 text-green-600" />
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">You are not following any traders yet.</p>
            </div>
          )}
        </div>
        <Button variant="outline" className="mt-4 w-full" onClick={() => router.push("/dashboard/traders")}>
          Find Traders to Follow
        </Button>
      </CardContent>
    </Card>
  )
}

