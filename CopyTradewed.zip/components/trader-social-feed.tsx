"use client"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { useTraders } from "@/lib/traders"
import { useAuth } from "@/lib/auth"
import { MessageSquare, ThumbsUp, Share2, MoreHorizontal, TrendingUp, TrendingDown, Clock, Send } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

// Mock data for trader posts
const mockPosts = [
  {
    id: "post-1",
    traderId: 1,
    content: "Just opened a long position on $AAPL. Technical indicators suggest a bullish trend in the coming weeks.",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    likes: 24,
    comments: 8,
    shares: 3,
    tradeDetails: {
      symbol: "AAPL",
      type: "BUY",
      price: 187.42,
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    },
  },
  {
    id: "post-2",
    traderId: 3,
    content:
      "Closed my $TSLA position with a 5.2% profit. The market volatility is increasing, so I'm taking profits where I can.",
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    likes: 42,
    comments: 12,
    shares: 7,
    tradeDetails: {
      symbol: "TSLA",
      type: "SELL",
      price: 215.65,
      profit: 5.2,
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    },
  },
  {
    id: "post-3",
    traderId: 2,
    content:
      "Market analysis: The Fed's recent comments suggest potential rate cuts in the coming months. This could be bullish for growth stocks, especially in the tech sector.",
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    likes: 56,
    comments: 15,
    shares: 11,
  },
  {
    id: "post-4",
    traderId: 5,
    content:
      "Weekly update: +3.2% return this week. My strategy of focusing on undervalued mid-cap stocks is paying off in this market environment.",
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    likes: 38,
    comments: 6,
    shares: 4,
    performanceUpdate: {
      period: "weekly",
      return: 3.2,
      topPerformer: "XYZ Corp",
      topPerformerReturn: 8.7,
    },
  },
]

// Mock data for trader comments
const mockComments = {
  "post-1": [
    {
      id: "comment-1",
      userId: "user-1",
      userName: "John Smith",
      userAvatar: "/placeholder.svg?height=32&width=32",
      content: "Great analysis! I'm also bullish on Apple for the long term.",
      timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
      likes: 5,
    },
    {
      id: "comment-2",
      userId: "user-2",
      userName: "Sarah Johnson",
      userAvatar: "/placeholder.svg?height=32&width=32",
      content: "What's your price target?",
      timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      likes: 2,
    },
  ],
}

export function TraderSocialFeed() {
  const { traders } = useTraders()
  const { user } = useAuth()
  const { toast } = useToast()

  const [activeTab, setActiveTab] = useState("all")
  const [commentText, setCommentText] = useState("")
  const [expandedPost, setExpandedPost] = useState<string | null>(null)
  const [likedPosts, setLikedPosts] = useState<string[]>([])

  // Filter posts based on active tab
  const filteredPosts =
    activeTab === "all"
      ? mockPosts
      : activeTab === "following"
        ? mockPosts.filter((post) => traders.some((trader) => trader.id === post.traderId && trader.following))
        : mockPosts.filter((post) => post.tradeDetails)

  const handleLike = (postId: string) => {
    if (likedPosts.includes(postId)) {
      setLikedPosts(likedPosts.filter((id) => id !== postId))
    } else {
      setLikedPosts([...likedPosts, postId])
    }
  }

  const handleComment = (postId: string) => {
    if (!commentText.trim()) return

    toast({
      title: "Comment Posted",
      description: "Your comment has been posted successfully.",
    })

    setCommentText("")
    setExpandedPost(null)
  }

  const handleShare = (postId: string) => {
    // Copy post link to clipboard
    navigator.clipboard.writeText(`https://tradecopy.com/post/${postId}`)

    toast({
      title: "Link Copied",
      description: "Post link copied to clipboard.",
    })
  }

  const getTraderById = (traderId: number) => {
    return traders.find((trader) => trader.id === traderId)
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Posts</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
          <TabsTrigger value="trades">Trade Updates</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="space-y-4">
        {filteredPosts.map((post) => {
          const trader = getTraderById(post.traderId)

          return (
            <Card key={post.id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar>
                      <AvatarImage src={trader?.avatar} alt={trader?.name} />
                      <AvatarFallback>{trader?.initials}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium flex items-center gap-2">
                        {trader?.name}
                        {trader?.verified && (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            Verified
                          </Badge>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}
                      </div>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="pb-3">
                <p className="whitespace-pre-wrap">{post.content}</p>

                {post.tradeDetails && (
                  <div className="mt-3 p-3 rounded-md bg-muted/50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant={post.tradeDetails.type === "BUY" ? "default" : "destructive"}>
                          {post.tradeDetails.type}
                        </Badge>
                        <span className="font-medium">{post.tradeDetails.symbol}</span>
                      </div>
                      <div className="text-sm">${post.tradeDetails.price.toLocaleString()}</div>
                    </div>
                    {post.tradeDetails.profit !== undefined && (
                      <div className="mt-2 text-sm flex items-center">
                        <span className="text-muted-foreground mr-2">Profit/Loss:</span>
                        <span className={post.tradeDetails.profit >= 0 ? "text-green-600" : "text-red-600"}>
                          {post.tradeDetails.profit >= 0 ? "+" : ""}
                          {post.tradeDetails.profit}%
                          {post.tradeDetails.profit >= 0 ? (
                            <TrendingUp className="ml-1 h-3 w-3 inline" />
                          ) : (
                            <TrendingDown className="ml-1 h-3 w-3 inline" />
                          )}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                {post.performanceUpdate && (
                  <div className="mt-3 p-3 rounded-md bg-muted/50">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="bg-green-50 text-green-700">
                        {post.performanceUpdate.period.charAt(0).toUpperCase() + post.performanceUpdate.period.slice(1)}{" "}
                        Update
                      </Badge>
                      <span className="text-green-600 flex items-center">
                        +{post.performanceUpdate.return}%
                        <TrendingUp className="ml-1 h-3 w-3" />
                      </span>
                    </div>
                    <div className="mt-2 text-sm">
                      <span className="text-muted-foreground">Top performer:</span>{" "}
                      <span className="font-medium">{post.performanceUpdate.topPerformer}</span>{" "}
                      <span className="text-green-600">(+{post.performanceUpdate.topPerformerReturn}%)</span>
                    </div>
                  </div>
                )}
              </CardContent>

              <CardFooter className="border-t pt-3">
                <div className="flex justify-between w-full">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => handleLike(post.id)}
                  >
                    <ThumbsUp
                      className={`h-4 w-4 ${likedPosts.includes(post.id) ? "fill-primary text-primary" : ""}`}
                    />
                    <span>{post.likes + (likedPosts.includes(post.id) ? 1 : 0)}</span>
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
                  >
                    <MessageSquare className="h-4 w-4" />
                    <span>{post.comments}</span>
                  </Button>

                  <Button
                    variant="ghost"
                    size="sm"
                    className="flex items-center gap-1"
                    onClick={() => handleShare(post.id)}
                  >
                    <Share2 className="h-4 w-4" />
                    <span>{post.shares}</span>
                  </Button>
                </div>
              </CardFooter>

              {expandedPost === post.id && (
                <div className="border-t p-3 space-y-3">
                  {mockComments[post.id]?.map((comment) => (
                    <div key={comment.id} className="flex gap-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={comment.userAvatar} alt={comment.userName} />
                        <AvatarFallback>{comment.userName[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="bg-muted rounded-md p-2">
                          <div className="font-medium text-sm">{comment.userName}</div>
                          <p className="text-sm">{comment.content}</p>
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <span>{formatDistanceToNow(new Date(comment.timestamp), { addSuffix: true })}</span>
                          <Button variant="ghost" size="sm" className="h-auto p-0">
                            Like
                          </Button>
                          <Button variant="ghost" size="sm" className="h-auto p-0">
                            Reply
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}

                  <div className="flex gap-3 mt-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user?.avatar} alt={user?.name} />
                      <AvatarFallback>{user?.name?.[0] || "U"}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 flex">
                      <Textarea
                        placeholder="Write a comment..."
                        className="min-h-[40px] flex-1 resize-none"
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                      />
                      <Button
                        size="sm"
                        className="ml-2 self-end"
                        disabled={!commentText.trim()}
                        onClick={() => handleComment(post.id)}
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </Card>
          )
        })}

        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">No posts found</h3>
            <p className="text-muted-foreground">
              {activeTab === "following"
                ? "Follow some traders to see their posts here."
                : activeTab === "trades"
                  ? "No trade updates available."
                  : "No posts available."}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

