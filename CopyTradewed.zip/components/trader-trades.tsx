"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

interface TraderTradesProps {
  traderId: number
}

// This would normally come from an API
const traderTrades = [
  {
    id: 1,
    symbol: "AAPL",
    type: "BUY",
    entryPrice: 187.42,
    exitPrice: 192.65,
    quantity: 100,
    profit: 523,
    profitPercent: 2.79,
    date: "Oct 15, 2023",
    status: "closed",
  },
  {
    id: 2,
    symbol: "MSFT",
    type: "BUY",
    entryPrice: 412.65,
    exitPrice: 425.32,
    quantity: 50,
    profit: 633.5,
    profitPercent: 3.07,
    date: "Oct 12, 2023",
    status: "closed",
  },
  {
    id: 3,
    symbol: "NVDA",
    type: "BUY",
    entryPrice: 824.36,
    exitPrice: null,
    quantity: 25,
    profit: null,
    profitPercent: null,
    date: "Oct 18, 2023",
    status: "open",
  },
  {
    id: 4,
    symbol: "AMZN",
    type: "SELL",
    entryPrice: 178.12,
    exitPrice: 172.45,
    quantity: 75,
    profit: 425.25,
    profitPercent: 3.18,
    date: "Oct 10, 2023",
    status: "closed",
  },
  {
    id: 5,
    symbol: "GOOGL",
    type: "BUY",
    entryPrice: 142.89,
    exitPrice: 140.23,
    quantity: 80,
    profit: -212.8,
    profitPercent: -1.86,
    date: "Oct 8, 2023",
    status: "closed",
  },
]

export function TraderTrades({ traderId }: TraderTradesProps) {
  return (
    <div className="overflow-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Symbol</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Entry Price</TableHead>
            <TableHead>Exit Price</TableHead>
            <TableHead>Quantity</TableHead>
            <TableHead>Profit/Loss</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {traderTrades.map((trade) => (
            <TableRow key={trade.id}>
              <TableCell className="font-medium">{trade.symbol}</TableCell>
              <TableCell>
                <Badge variant={trade.type === "BUY" ? "default" : "destructive"}>{trade.type}</Badge>
              </TableCell>
              <TableCell>${trade.entryPrice.toFixed(2)}</TableCell>
              <TableCell>{trade.exitPrice ? `$${trade.exitPrice.toFixed(2)}` : "-"}</TableCell>
              <TableCell>{trade.quantity}</TableCell>
              <TableCell>
                {trade.profit !== null ? (
                  <span className={trade.profit >= 0 ? "text-green-600" : "text-red-600"}>
                    {trade.profit >= 0 ? "+" : ""}${Math.abs(trade.profit).toFixed(2)} ({trade.profit >= 0 ? "+" : ""}
                    {trade.profitPercent}%)
                  </span>
                ) : (
                  "-"
                )}
              </TableCell>
              <TableCell>{trade.date}</TableCell>
              <TableCell>
                <Badge variant={trade.status === "open" ? "outline" : "secondary"}>
                  {trade.status === "open" ? "Open" : "Closed"}
                </Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

