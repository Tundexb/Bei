"use client"

import { Separator } from "@/components/ui/separator"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useNotifications } from "@/lib/notifications"
import { formatDistanceToNow } from "date-fns"
import { Bell, CheckCircle, AlertCircle, TrendingUp, DollarSign, User, Check, Settings, RefreshCw } from "lucide-react"

export function NotificationCenter() {
  const router = useRouter()
  const { notifications, markAsRead, markAllAsRead, clearNotifications } = useNotifications()
  const [activeTab, setActiveTab] = useState("all")
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [notificationSettings, setNotificationSettings] = useState({
    tradeExecutions: true,
    priceAlerts: true,
    traderUpdates: true,
    systemAlerts: true,
    emailNotifications: true,
    pushNotifications: true,
    soundAlerts: false,
  })

  // Filter notifications based on active tab
  const filteredNotifications =
    activeTab === "all" ? notifications : notifications.filter((notification) => notification.type === activeTab)

  // Group notifications by date
  const groupedNotifications = filteredNotifications.reduce(
    (groups, notification) => {
      const date = new Date(notification.date).toLocaleDateString()
      if (!groups[date]) {
        groups[date] = []
      }
      groups[date].push(notification)
      return groups
    },
    {} as Record<string, typeof notifications>,
  )

  // Sort dates in descending order
  const sortedDates = Object.keys(groupedNotifications).sort((a, b) => {
    return new Date(b).getTime() - new Date(a).getTime()
  })

  const handleRefresh = () => {
    setIsRefreshing(true)
    setTimeout(() => {
      setIsRefreshing(false)
    }, 1000)
  }

  const handleToggleSetting = (setting: string) => {
    setNotificationSettings((prev) => ({
      ...prev,
      [setting]: !prev[setting],
    }))
  }

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "trade":
        return <DollarSign className="h-5 w-5 text-green-500" />
      case "alert":
        return <TrendingUp className="h-5 w-5 text-blue-500" />
      case "trader":
        return <User className="h-5 w-5 text-purple-500" />
      case "system":
        return <AlertCircle className="h-5 w-5 text-amber-500" />
      case "success":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "warning":
        return <AlertCircle className="h-5 w-5 text-amber-500" />
      case "error":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      default:
        return <Bell className="h-5 w-5 text-gray-500" />
    }
  }

  const handleNotificationClick = (id: string, link?: string) => {
    markAsRead(id)
    if (link) {
      router.push(link)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold tracking-tight">Notifications</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
            Refresh
          </Button>

          <Button variant="outline" size="sm" onClick={markAllAsRead}>
            <Check className="mr-2 h-4 w-4" />
            Mark All as Read
          </Button>
        </div>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <div className="flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="all">
              All
              {notifications.filter((n) => !n.read).length > 0 && (
                <Badge className="ml-2 bg-primary text-primary-foreground">
                  {notifications.filter((n) => !n.read).length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="trade">Trades</TabsTrigger>
            <TabsTrigger value="alert">Alerts</TabsTrigger>
            <TabsTrigger value="trader">Traders</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
          </TabsList>

          <Button variant="ghost" size="sm" onClick={() => setActiveTab("settings")}>
            <Settings className="h-4 w-4" />
          </Button>
        </div>

        <TabsContent value="all" className="mt-6">
          {sortedDates.length > 0 ? (
            <div className="space-y-6">
              {sortedDates.map((date) => (
                <div key={date}>
                  <h3 className="text-sm font-medium text-muted-foreground mb-3">
                    {new Date(date).toLocaleDateString("en-US", {
                      weekday: "long",
                      month: "long",
                      day: "numeric",
                    })}
                  </h3>

                  <div className="space-y-3">
                    {groupedNotifications[date].map((notification) => (
                      <div
                        key={notification.id}
                        className={`flex cursor-pointer items-start gap-4 rounded-lg border p-4 transition-colors hover:bg-muted/50 ${!notification.read ? "bg-muted/50" : ""}`}
                        onClick={() => handleNotificationClick(notification.id, notification.link)}
                      >
                        <div className="mt-0.5">{getNotificationIcon(notification.type)}</div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <h3 className="font-medium">{notification.title}</h3>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">
                                {formatDistanceToNow(new Date(notification.date), { addSuffix: true })}
                              </span>
                              {!notification.read && (
                                <Badge variant="default" className="h-1.5 w-1.5 rounded-full p-0" />
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground">{notification.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12">
              <Bell className="mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="text-lg font-medium">No notifications</h3>
              <p className="text-muted-foreground">You don't have any notifications at the moment.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="trade" className="mt-6">
          {/* Similar structure to "all" tab but filtered for trade notifications */}
        </TabsContent>

        <TabsContent value="alert" className="mt-6">
          {/* Similar structure to "all" tab but filtered for alert notifications */}
        </TabsContent>

        <TabsContent value="trader" className="mt-6">
          {/* Similar structure to "all" tab but filtered for trader notifications */}
        </TabsContent>

        <TabsContent value="system" className="mt-6">
          {/* Similar structure to "all" tab but filtered for system notifications */}
        </TabsContent>

        <TabsContent value="settings" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Notification Types</h3>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="trade-executions">Trade Executions</Label>
                    <p className="text-xs text-muted-foreground">Notifications for executed trades</p>
                  </div>
                  <Switch
                    id="trade-executions"
                    checked={notificationSettings.tradeExecutions}
                    onCheckedChange={() => handleToggleSetting("tradeExecutions")}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="price-alerts">Price Alerts</Label>
                    <p className="text-xs text-muted-foreground">Notifications for price alerts</p>
                  </div>
                  <Switch
                    id="price-alerts"
                    checked={notificationSettings.priceAlerts}
                    onCheckedChange={() => handleToggleSetting("priceAlerts")}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="trader-updates">Trader Updates</Label>
                    <p className="text-xs text-muted-foreground">Notifications for trader activities</p>
                  </div>
                  <Switch
                    id="trader-updates"
                    checked={notificationSettings.traderUpdates}
                    onCheckedChange={() => handleToggleSetting("traderUpdates")}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="system-alerts">System Alerts</Label>
                    <p className="text-xs text-muted-foreground">Notifications for system events</p>
                  </div>
                  <Switch
                    id="system-alerts"
                    checked={notificationSettings.systemAlerts}
                    onCheckedChange={() => handleToggleSetting("systemAlerts")}
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Delivery Methods</h3>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="email-notifications">Email Notifications</Label>
                    <p className="text-xs text-muted-foreground">Receive notifications via email</p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={notificationSettings.emailNotifications}
                    onCheckedChange={() => handleToggleSetting("emailNotifications")}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="push-notifications">Push Notifications</Label>
                    <p className="text-xs text-muted-foreground">Receive notifications on your device</p>
                  </div>
                  <Switch
                    id="push-notifications"
                    checked={notificationSettings.pushNotifications}
                    onCheckedChange={() => handleToggleSetting("pushNotifications")}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label htmlFor="sound-alerts">Sound Alerts</Label>
                    <p className="text-xs text-muted-foreground">Play sound when receiving notifications</p>
                  </div>
                  <Switch
                    id="sound-alerts"
                    checked={notificationSettings.soundAlerts}
                    onCheckedChange={() => handleToggleSetting("soundAlerts")}
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button>Save Settings</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

