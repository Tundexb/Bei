"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Plus, Check, X, RefreshCw, Key, Loader2, Briefcase, CreditCard, Bitcoin } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/lib/auth"
import { sendEmail } from "@/lib/email-service"
import { useRouter } from "next/navigation"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useBrokerIntegration } from "@/lib/broker-integration"
import Image from "next/image"

// Initial state for connected brokers
const initialConnectedBrokers = [
  {
    id: 1,
    name: "Schwab",
    category: "stocks",
    status: "connected",
    accountNumber: "****7890",
    lastSync: "2 hours ago",
  },
  {
    id: 2,
    name: "OANDA",
    category: "forex",
    status: "connected",
    accountNumber: "****5678",
    lastSync: "1 hour ago",
  },
  {
    id: 3,
    name: "Binance",
    category: "crypto",
    status: "connected",
    accountNumber: "****9012",
    lastSync: "30 minutes ago",
  },
]

export function BrokerSettings() {
  const router = useRouter()
  const { toast } = useToast()
  const { user } = useAuth()
  const { availableBrokers } = useBrokerIntegration()
  const [connectedBrokers, setConnectedBrokers] = useState(initialConnectedBrokers)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isSyncing, setIsSyncing] = useState(false)
  const [isUpdatingAPI, setIsUpdatingAPI] = useState(false)
  const [isDisconnecting, setIsDisconnecting] = useState(false)
  const [selectedBrokerId, setSelectedBrokerId] = useState<number | null>(null)
  const [connectDialogOpen, setConnectDialogOpen] = useState(false)
  const [apiDialogOpen, setApiDialogOpen] = useState(false)
  const [currentBroker, setCurrentBroker] = useState<any>(null)
  const [activeTab, setActiveTab] = useState("all")

  const [apiSettings, setApiSettings] = useState({
    apiKey: "",
    apiSecret: "",
    apiPassphrase: "",
  })

  const handleOpenConnectDialog = () => {
    setConnectDialogOpen(true)
  }

  const handleOpenAPIDialog = (broker: any) => {
    setCurrentBroker(broker)
    setApiDialogOpen(true)
  }

  const handleConnectBroker = () => {
    // Redirect to the broker connection wizard page
    router.push("/dashboard/connect-broker")
  }

  const handleSyncBroker = (brokerId: number) => {
    setSelectedBrokerId(brokerId)
    setIsSyncing(true)

    // Find the broker to sync
    const brokerToSync = connectedBrokers.find((broker) => broker.id === brokerId)

    if (!brokerToSync) {
      setIsSyncing(false)
      setSelectedBrokerId(null)
      return
    }

    // Simulate API call
    setTimeout(() => {
      try {
        // Update the last sync time
        setConnectedBrokers((prev) =>
          prev.map((broker) => (broker.id === brokerId ? { ...broker, lastSync: "Just now" } : broker)),
        )

        toast({
          title: "Broker synced",
          description: `${brokerToSync.name} has been successfully synced.`,
        })
      } catch (error) {
        toast({
          title: "Sync failed",
          description: "An error occurred while syncing the broker. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsSyncing(false)
        setSelectedBrokerId(null)
      }
    }, 2000)
  }

  const handleDisconnectBroker = async (brokerId: number) => {
    setSelectedBrokerId(brokerId)
    setIsDisconnecting(true)

    // Find the broker to disconnect
    const brokerToDisconnect = connectedBrokers.find((broker) => broker.id === brokerId)

    if (!brokerToDisconnect) {
      setIsDisconnecting(false)
      setSelectedBrokerId(null)
      return
    }

    // Simulate API call
    setTimeout(async () => {
      try {
        // Remove the broker from connected brokers
        setConnectedBrokers((prev) => prev.filter((broker) => broker.id !== brokerId))

        // Send broker disconnected email
        if (user?.email) {
          await sendEmail({
            to: user.email,
            template: "broker-disconnected",
            data: {
              brokerName: brokerToDisconnect.name,
            },
          })
        }

        toast({
          title: "Broker disconnected",
          description: `${brokerToDisconnect.name} has been successfully disconnected from your account.`,
        })
      } catch (error) {
        toast({
          title: "Disconnection failed",
          description: "An error occurred while disconnecting the broker. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsDisconnecting(false)
        setSelectedBrokerId(null)
      }
    }, 1500)
  }

  const handleUpdateAPISettings = () => {
    setIsUpdatingAPI(true)

    // Validate API settings
    if (!apiSettings.apiKey || !apiSettings.apiSecret) {
      toast({
        title: "Missing API credentials",
        description: "Please provide both API key and API secret.",
        variant: "destructive",
      })
      setIsUpdatingAPI(false)
      return
    }

    // Simulate API call
    setTimeout(() => {
      try {
        toast({
          title: "API settings updated",
          description: `API settings for ${currentBroker?.name || "your broker"} have been updated successfully.`,
        })
        setApiDialogOpen(false)
      } catch (error) {
        toast({
          title: "Update failed",
          description: "An error occurred while updating your API settings. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsUpdatingAPI(false)
      }
    }, 1500)
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "stocks":
        return <Briefcase className="mr-2 h-4 w-4" />
      case "forex":
        return <CreditCard className="mr-2 h-4 w-4" />
      case "crypto":
        return <Bitcoin className="mr-2 h-4 w-4" />
      default:
        return null
    }
  }

  const filteredBrokers =
    activeTab === "all" ? connectedBrokers : connectedBrokers.filter((broker) => broker.category === activeTab)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-medium">Connected Brokers</h3>
        <Button onClick={handleConnectBroker}>
          <Plus className="mr-2 h-4 w-4" />
          Connect Broker
        </Button>
      </div>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Brokers</TabsTrigger>
          <TabsTrigger value="stocks" className="flex items-center">
            <Briefcase className="mr-2 h-4 w-4" />
            Stocks
          </TabsTrigger>
          <TabsTrigger value="forex" className="flex items-center">
            <CreditCard className="mr-2 h-4 w-4" />
            Forex
          </TabsTrigger>
          <TabsTrigger value="crypto" className="flex items-center">
            <Bitcoin className="mr-2 h-4 w-4" />
            Crypto
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {filteredBrokers.length > 0 ? (
        <div className="grid gap-4">
          {filteredBrokers.map((broker) => {
            // Find broker details from available brokers
            const brokerDetails = availableBrokers.find(
              (b) =>
                b.name.toLowerCase() === broker.name.toLowerCase() ||
                b.id === broker.name.toLowerCase().replace(" ", "_"),
            )

            return (
              <Card key={broker.id}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-md bg-muted flex items-center justify-center">
                      {brokerDetails?.logo ? (
                        <Image
                          src={brokerDetails.logo || "/placeholder.svg"}
                          alt={broker.name}
                          width={32}
                          height={32}
                          className="h-8 w-8 object-contain"
                        />
                      ) : (
                        getCategoryIcon(broker.category)
                      )}
                    </div>
                    <div>
                      <CardTitle>{broker.name}</CardTitle>
                      <CardDescription>Account {broker.accountNumber}</CardDescription>
                    </div>
                  </div>
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                    <Check className="mr-1 h-3 w-3" />
                    Connected
                  </Badge>
                </CardHeader>
                <CardContent>
                  <div className="text-sm text-muted-foreground">Last synced: {broker.lastSync}</div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleSyncBroker(broker.id)}
                    disabled={isSyncing && selectedBrokerId === broker.id}
                  >
                    {isSyncing && selectedBrokerId === broker.id ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Syncing...
                      </>
                    ) : (
                      <>
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Sync Now
                      </>
                    )}
                  </Button>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleOpenAPIDialog(broker)}>
                      <Key className="mr-2 h-4 w-4" />
                      API Settings
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDisconnectBroker(broker.id)}
                      disabled={isDisconnecting && selectedBrokerId === broker.id}
                    >
                      {isDisconnecting && selectedBrokerId === broker.id ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Disconnecting...
                        </>
                      ) : (
                        <>
                          <X className="mr-2 h-4 w-4" />
                          Disconnect
                        </>
                      )}
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            )
          })}
        </div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>No {activeTab !== "all" ? activeTab : "Brokers"} Connected</CardTitle>
            <CardDescription>
              Connect a {activeTab !== "all" ? activeTab : "broker"} to start copy trading
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              You need to connect at least one {activeTab !== "all" ? activeTab : "broker"} account to start copy
              trading. We support major brokers including Schwab, OANDA, Binance, and more.
            </p>
          </CardContent>
          <CardFooter>
            <Button onClick={handleConnectBroker}>
              <Plus className="mr-2 h-4 w-4" />
              Connect {activeTab !== "all" ? activeTab : "Broker"}
            </Button>
          </CardFooter>
        </Card>
      )}

      <div className="space-y-4">
        <h3 className="text-lg font-medium">API Configuration</h3>
        <Card>
          <CardHeader>
            <CardTitle>API Settings</CardTitle>
            <CardDescription>Configure your broker API settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="api-key">API Key</Label>
              <Input id="api-key" type="password" value="••••••••••••••••••••••••••••••" readOnly />
            </div>
            <div className="space-y-2">
              <Label htmlFor="api-secret">API Secret</Label>
              <Input id="api-secret" type="password" value="••••••••••••••••••••••••••••••" readOnly />
            </div>
            <div className="space-y-2">
              <Label htmlFor="api-passphrase">API Passphrase (if required)</Label>
              <Input id="api-passphrase" type="password" value="••••••••••••••••••••••••••••••" readOnly />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={() => handleOpenAPIDialog(null)}>Update API Settings</Button>
          </CardFooter>
        </Card>
      </div>

      {/* API Settings Dialog */}
      <Dialog open={apiDialogOpen} onOpenChange={setApiDialogOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>
              {currentBroker ? `Update API Settings for ${currentBroker.name}` : "Update API Settings"}
            </DialogTitle>
            <DialogDescription>Enter your API credentials to connect to your trading account</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="dialog-api-key">API Key</Label>
              <Input
                id="dialog-api-key"
                value={apiSettings.apiKey}
                onChange={(e) => setApiSettings({ ...apiSettings, apiKey: e.target.value })}
                placeholder="Enter your API key"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dialog-api-secret">API Secret</Label>
              <Input
                id="dialog-api-secret"
                type="password"
                value={apiSettings.apiSecret}
                onChange={(e) => setApiSettings({ ...apiSettings, apiSecret: e.target.value })}
                placeholder="Enter your API secret"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="dialog-api-passphrase">API Passphrase (if required)</Label>
              <Input
                id="dialog-api-passphrase"
                type="password"
                value={apiSettings.apiPassphrase}
                onChange={(e) => setApiSettings({ ...apiSettings, apiPassphrase: e.target.value })}
                placeholder="Enter API passphrase (optional)"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setApiDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateAPISettings} disabled={isUpdatingAPI}>
              {isUpdatingAPI ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating...
                </>
              ) : (
                "Save API Settings"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

