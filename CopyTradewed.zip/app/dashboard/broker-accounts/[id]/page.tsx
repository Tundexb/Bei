"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { useBrokerIntegration, type BrokerAccount } from "@/lib/broker-integration"
import { useToast } from "@/components/ui/use-toast"
import { ArrowLeft, RefreshCw, Trash2, AlertCircle } from "lucide-react"
import { BrokerSettings } from "@/components/broker-settings"
import { formatDistanceToNow } from "date-fns"
import Image from "next/image"

export default function BrokerAccountDetailsPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const { getBrokerAccounts, getBrokerDetails, disconnectBroker } = useBrokerIntegration()

  const [account, setAccount] = useState<BrokerAccount | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")
  const [refreshing, setRefreshing] = useState(false)

  const accountId = params.id as string

  useEffect(() => {
    loadAccount()
  }, [accountId])

  const loadAccount = async () => {
    setLoading(true)
    try {
      const accounts = await getBrokerAccounts()
      const foundAccount = accounts.find((acc) => acc.id === accountId)

      if (foundAccount) {
        setAccount(foundAccount)
      } else {
        toast({
          title: "Account Not Found",
          description: "The broker account you're looking for doesn't exist.",
          variant: "destructive",
        })
        router.push("/dashboard/broker-accounts")
      }
    } catch (error) {
      console.error("Error loading broker account:", error)
      toast({
        title: "Error",
        description: "Failed to load broker account details. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleRefresh = async () => {
    setRefreshing(true)

    try {
      // In a real app, this would refresh the connection status
      await new Promise((resolve) => setTimeout(resolve, 1000))
      await loadAccount()

      toast({
        title: "Account Refreshed",
        description: "Account information has been updated.",
      })
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh account information. Please try again.",
        variant: "destructive",
      })
    } finally {
      setRefreshing(false)
    }
  }

  const handleDisconnect = async () => {
    if (!account) return

    const brokerDetails = getBrokerDetails(account.brokerType)
    const brokerName = brokerDetails?.name || account.brokerType

    if (!confirm(`Are you sure you want to disconnect your ${brokerName} account?`)) {
      return
    }

    try {
      await disconnectBroker(accountId)
      toast({
        title: "Account Disconnected",
        description: `Your ${brokerName} account has been disconnected.`,
      })
      router.push("/dashboard/broker-accounts")
    } catch (error) {
      console.error("Error disconnecting broker:", error)
      toast({
        title: "Error",
        description: "Failed to disconnect broker. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" onClick={() => router.back()} className="mr-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <h1 className="text-3xl font-bold">Loading Account...</h1>
        </div>
        <Card>
          <CardHeader>
            <CardTitle>Account Details</CardTitle>
            <CardDescription>Loading broker account information...</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-center py-10">
              <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!account) {
    return (
      <div className="space-y-6">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" onClick={() => router.back()} className="mr-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <h1 className="text-3xl font-bold">Account Not Found</h1>
        </div>
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-10 text-center">
            <AlertCircle className="h-10 w-10 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Broker Account Not Found</h3>
            <p className="text-muted-foreground mb-6">
              The broker account you're looking for doesn't exist or has been disconnected.
            </p>
            <Button onClick={() => router.push("/dashboard/broker-accounts")}>View All Accounts</Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const brokerDetails = getBrokerDetails(account.brokerType)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" onClick={() => router.back()} className="mr-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gray-100 rounded-md flex items-center justify-center">
              {brokerDetails?.logo ? (
                <Image
                  src={brokerDetails.logo || "/placeholder.svg"}
                  alt={brokerDetails.name}
                  width={32}
                  height={32}
                  className="object-contain"
                />
              ) : (
                <div className="text-sm font-bold">{brokerDetails?.name.charAt(0) || account.brokerType.charAt(0)}</div>
              )}
            </div>
            <div>
              <h1 className="text-3xl font-bold">{brokerDetails?.name || account.brokerType}</h1>
              <p className="text-muted-foreground">{account.accountName || `Account ${account.accountNumber}`}</p>
            </div>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={handleRefresh} disabled={refreshing}>
            {refreshing ? <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
            Refresh
          </Button>
          <Button variant="destructive" onClick={handleDisconnect}>
            <Trash2 className="mr-2 h-4 w-4" />
            Disconnect
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Account Summary</CardTitle>
          <CardDescription>
            Last updated {formatDistanceToNow(new Date(account.lastSynced), { addSuffix: true })}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div>
              <p className="text-sm text-muted-foreground">Account Number</p>
              <p className="text-xl font-medium">{account.accountNumber}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Account Type</p>
              <p className="text-xl font-medium">{account.accountType}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Balance</p>
              <p className="text-xl font-medium">
                ${account.balance.toLocaleString()} {account.currency}
              </p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Equity</p>
              <p className="text-xl font-medium">
                ${account.equity.toLocaleString()} {account.currency}
              </p>
            </div>
            {account.margin && (
              <div>
                <p className="text-sm text-muted-foreground">Margin Used</p>
                <p className="text-xl font-medium">
                  ${account.margin.toLocaleString()} {account.currency}
                </p>
              </div>
            )}
            {account.marginLevel && (
              <div>
                <p className="text-sm text-muted-foreground">Margin Level</p>
                <p className="text-xl font-medium">{account.marginLevel.toFixed(2)}%</p>
              </div>
            )}
            {account.freeMargin && (
              <div>
                <p className="text-sm text-muted-foreground">Free Margin</p>
                <p className="text-xl font-medium">
                  ${account.freeMargin.toLocaleString()} {account.currency}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Account Overview</CardTitle>
              <CardDescription>Summary of your broker account activity</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Account overview content will be displayed here.</p>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="settings" className="space-y-4 mt-6">
          <BrokerSettings account={account} />
        </TabsContent>
        <TabsContent value="permissions" className="space-y-4 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Account Permissions</CardTitle>
              <CardDescription>Manage what our platform can do with your account</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Current Permissions</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Read Account Data</p>
                        <p className="text-sm text-muted-foreground">View account balances, positions, and history</p>
                      </div>
                      <div className="text-green-600 font-medium">Enabled</div>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Execute Trades</p>
                        <p className="text-sm text-muted-foreground">Place orders and manage positions</p>
                      </div>
                      <div
                        className={
                          account.permissions.trading ? "text-green-600 font-medium" : "text-red-600 font-medium"
                        }
                      >
                        {account.permissions.trading ? "Enabled" : "Disabled"}
                      </div>
                    </div>
                    <Separator />
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">Withdrawals</p>
                        <p className="text-sm text-muted-foreground">Withdraw funds from your account</p>
                      </div>
                      <div
                        className={
                          account.permissions.withdrawals ? "text-green-600 font-medium" : "text-red-600 font-medium"
                        }
                      >
                        {account.permissions.withdrawals ? "Enabled" : "Disabled"}
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Update Permissions</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    To update permissions, you need to reconnect your account with the desired permissions.
                  </p>
                  <Button onClick={() => router.push("/dashboard/connect-broker")}>Reconnect Account</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

