"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, CreditCard, Loader2, Star } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"

interface SubscriptionPlan {
  id: string
  name: string
  price: number
  billingPeriod: "monthly" | "yearly"
  description: string
  features: string[]
  popular?: boolean
  traderLimit: number
  copyLimit: number
  analyticsAccess: "basic" | "advanced" | "premium"
  supportLevel: "standard" | "priority" | "dedicated"
}

const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: "basic",
    name: "Basic",
    price: 9.99,
    billingPeriod: "monthly",
    description: "Perfect for beginners starting with copy trading",
    features: [
      "Follow up to 3 traders",
      "Basic analytics",
      "Standard support",
      "Manual copy trading",
      "1 connected broker",
    ],
    traderLimit: 3,
    copyLimit: 10,
    analyticsAccess: "basic",
    supportLevel: "standard",
  },
  {
    id: "pro",
    name: "Pro",
    price: 29.99,
    billingPeriod: "monthly",
    description: "For serious traders looking to maximize profits",
    features: [
      "Follow up to 10 traders",
      "Advanced analytics",
      "Priority support",
      "Automated copy trading",
      "3 connected brokers",
      "Risk management tools",
      "Performance alerts",
    ],
    popular: true,
    traderLimit: 10,
    copyLimit: 50,
    analyticsAccess: "advanced",
    supportLevel: "priority",
  },
  {
    id: "premium",
    name: "Premium",
    price: 79.99,
    billingPeriod: "monthly",
    description: "Enterprise-grade solution for professional traders",
    features: [
      "Unlimited traders to follow",
      "Premium analytics",
      "Dedicated support",
      "Advanced automation",
      "Unlimited connected brokers",
      "Custom risk profiles",
      "API access",
      "White-label options",
    ],
    traderLimit: 999,
    copyLimit: 999,
    analyticsAccess: "premium",
    supportLevel: "dedicated",
  },
]

export function SubscriptionPlans() {
  const { toast } = useToast()
  const router = useRouter()
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)

  const handleSelectPlan = (planId: string) => {
    setSelectedPlan(planId)
  }

  const handleSubscribe = async (plan: SubscriptionPlan) => {
    setIsProcessing(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: "Subscription successful!",
      description: `You are now subscribed to the ${plan.name} plan.`,
    })

    setIsProcessing(false)
    router.push("/dashboard/copy-trading")
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold">Choose Your Plan</h2>
        <p className="text-muted-foreground mt-2">Select the subscription that best fits your trading needs</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {subscriptionPlans.map((plan) => (
          <Card
            key={plan.id}
            className={`relative overflow-hidden transition-all ${
              selectedPlan === plan.id ? "ring-2 ring-primary" : ""
            } ${plan.popular ? "border-primary" : ""}`}
          >
            {plan.popular && (
              <div className="absolute top-0 right-0">
                <Badge className="rounded-tl-none rounded-br-none rounded-tr-md rounded-bl-md bg-primary text-primary-foreground">
                  <Star className="mr-1 h-3 w-3 fill-current" />
                  Most Popular
                </Badge>
              </div>
            )}

            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
              <div className="mt-2">
                <span className="text-3xl font-bold">${plan.price}</span>
                <span className="text-muted-foreground">/{plan.billingPeriod}</span>
              </div>
            </CardHeader>

            <CardContent>
              <ul className="space-y-2">
                {plan.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="mr-2 h-4 w-4 text-green-500" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>

            <CardFooter>
              <Button
                className="w-full"
                onClick={() => handleSubscribe(plan)}
                disabled={isProcessing && selectedPlan === plan.id}
              >
                {isProcessing && selectedPlan === plan.id ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <CreditCard className="mr-2 h-4 w-4" />
                    Subscribe
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <div className="text-center text-sm text-muted-foreground">
        <p>All plans include a 7-day free trial. Cancel anytime.</p>
        <p className="mt-1">
          Need a custom plan?{" "}
          <a href="#" className="text-primary hover:underline">
            Contact us
          </a>{" "}
          for enterprise solutions.
        </p>
      </div>
    </div>
  )
}

