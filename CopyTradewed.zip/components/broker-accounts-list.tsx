"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { useBrokerIntegration, type BrokerAccount, type BrokerCategory } from "@/lib/broker-integration"
import {
  AlertCircle,
  CheckCircle,
  Clock,
  Settings,
  ExternalLink,
  RefreshCw,
  Trash2,
  Briefcase,
  CreditCard,
  Bitcoin,
  Loader2,
} from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"
import Image from "next/image"

interface BrokerAccountsListProps {
  filter: "all" | BrokerCategory
}

export function BrokerAccountsList({ filter }: BrokerAccountsListProps) {
  const { getBrokerAccounts, disconnectBroker, getBrokerDetails, getAccountSummary } = useBrokerIntegration()
  const { toast } = useToast()
  const router = useRouter()

  const [accounts, setAccounts] = useState<BrokerAccount[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState<Record<string, boolean>>({})
  const [accountSummaries, setAccountSummaries] = useState<Record<string, any>>({})
  const [activeTab, setActiveTab] = useState<"all" | BrokerCategory>("all")
  const [isDisconnecting, setIsDisconnecting] = useState(false)
  const [selectedBrokerId, setSelectedBrokerId] = useState<string | null>(null)

  useEffect(() => {
    loadAccounts()
  }, [filter])

  const loadAccounts = async () => {
    setLoading(true)
    try {
      const allAccounts = await getBrokerAccounts()
      const filteredAccounts =
        filter === "all" ? allAccounts : allAccounts.filter((account) => account.brokerCategory === filter)

      setAccounts(filteredAccounts)

      // Load account summaries
      const summaries: Record<string, any> = {}
      for (const account of filteredAccounts) {
        summaries[account.id] = await getAccountSummary(account.id)
      }
      setAccountSummaries(summaries)
    } catch (error) {
      console.error("Error loading broker accounts:", error)
      toast({
        title: "Error",
        description: "Failed to load broker accounts. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleDisconnectBroker = async (accountId: string, brokerName: string) => {
    if (!confirm(`Are you sure you want to disconnect your ${brokerName} account?`)) {
      return
    }

    setIsDisconnecting(true)
    setSelectedBrokerId(accountId)

    try {
      await disconnectBroker(accountId)
      setAccounts(accounts.filter((account) => account.id !== accountId))
      toast({
        title: "Account Disconnected",
        description: `${brokerName} account disconnected successfully.`,
      })
    } catch (error) {
      console.error("Error disconnecting broker:", error)
      toast({
        title: "Error",
        description: "Failed to disconnect broker. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsDisconnecting(false)
      setSelectedBrokerId(null)
    }
  }

  const handleDisconnect = async (accountId: string, brokerName: string) => {
    if (!confirm(`Are you sure you want to disconnect your ${brokerName} account?`)) {
      return
    }

    try {
      await disconnectBroker(accountId)
      setAccounts(accounts.filter((account) => account.id !== accountId))
    } catch (error) {
      console.error("Error disconnecting broker:", error)
      toast({
        title: "Error",
        description: "Failed to disconnect broker. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleRefresh = async (accountId: string) => {
    setRefreshing((prev) => ({ ...prev, [accountId]: true }))

    try {
      // In a real app, this would refresh the connection status
      await new Promise((resolve) => setTimeout(resolve, 1000))
      await loadAccounts()

      toast({
        title: "Account Refreshed",
        description: "Account information has been updated.",
      })
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh account information. Please try again.",
        variant: "destructive",
      })
    } finally {
      setRefreshing((prev) => ({ ...prev, [accountId]: false }))
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "connected":
        return <Badge className="bg-green-500">Connected</Badge>
      case "connecting":
        return <Badge variant="secondary">Connecting</Badge>
      case "failed":
        return <Badge variant="destructive">Failed</Badge>
      case "disconnected":
        return <Badge variant="outline">Disconnected</Badge>
      case "expired":
        return <Badge className="bg-amber-100 text-amber-800">Expired</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "connected":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "connecting":
        return <Clock className="h-4 w-4 text-amber-500" />
      case "failed":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      case "disconnected":
        return <AlertCircle className="h-4 w-4 text-muted-foreground" />
      case "expired":
        return <AlertCircle className="h-4 w-4 text-amber-500" />
      default:
        return null
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "stocks":
        return <Briefcase className="mr-2 h-4 w-4" />
      case "forex":
        return <CreditCard className="mr-2 h-4 w-4" />
      case "crypto":
        return <Bitcoin className="mr-2 h-4 w-4" />
      default:
        return null
    }
  }

  const filteredAccounts =
    activeTab === "all" ? accounts : accounts.filter((account) => account.brokerCategory === activeTab)

  const brokerCounts = accounts.reduce(
    (acc, account) => {
      acc[account.brokerCategory] = (acc[account.brokerCategory] || 0) + 1
      return acc
    },
    { all: accounts.length, stocks: 0, forex: 0, crypto: 0 } as {
      all: number
      stocks: number
      forex: number
      crypto: number
    },
  )

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2].map((i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <div className="flex justify-between">
                <Skeleton className="h-6 w-40" />
                <Skeleton className="h-6 w-24" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between mb-4">
                <Skeleton className="h-10 w-1/4" />
                <Skeleton className="h-6 w-20" />
              </div>
              <div className="space-y-2">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            </CardContent>
            <CardFooter>
              <Skeleton className="h-9 w-full" />
            </CardFooter>
          </Card>
        ))}
      </div>
    )
  }

  if (accounts.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-10 text-center">
          <AlertCircle className="h-10 w-10 text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium mb-2">No Broker Accounts Connected</h3>
          <p className="text-muted-foreground mb-6">Connect your brokerage accounts to start copy trading.</p>
          <Button onClick={() => router.push("/dashboard/connect-broker")}>Connect Broker</Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Broker Category Counts */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <span className="font-medium">Connected Accounts:</span>
          <Badge variant="secondary">{brokerCounts.all} Total</Badge>
          {brokerCounts.stocks > 0 && <Badge variant="secondary">{brokerCounts.stocks} Stocks</Badge>}
          {brokerCounts.forex > 0 && <Badge variant="secondary">{brokerCounts.forex} Forex</Badge>}
          {brokerCounts.crypto > 0 && <Badge variant="secondary">{brokerCounts.crypto} Crypto</Badge>}
        </div>
      </div>

      {/* Broker Account List */}
      <div className="grid gap-4">
        {filteredAccounts.map((account) => {
          const brokerDetails = getBrokerDetails(account.brokerType)
          const summary = accountSummaries[account.id] || {}

          return (
            <Card key={account.id}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-md bg-muted flex items-center justify-center">
                    {brokerDetails?.logo ? (
                      <Image
                        src={brokerDetails.logo || "/placeholder.svg"}
                        alt={brokerDetails?.name || account.brokerType}
                        width={32}
                        height={32}
                        className="object-contain"
                      />
                    ) : (
                      getCategoryIcon(account.brokerCategory)
                    )}
                  </div>
                  <div>
                    <CardTitle className="text-lg">{brokerDetails?.name || account.brokerType}</CardTitle>
                    <CardDescription>Account {account.accountNumber}</CardDescription>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {getStatusIcon(account.connectionStatus)}
                  {getStatusBadge(account.connectionStatus)}
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Balance</p>
                      {loading ? (
                        <Skeleton className="h-4 w-20" />
                      ) : (
                        <p className="font-medium">
                          ${summary.balance?.toLocaleString() || "0.00"} {account.currency}
                        </p>
                      )}
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Equity</p>
                      {loading ? (
                        <Skeleton className="h-4 w-20" />
                      ) : (
                        <p className="font-medium">
                          ${summary.equity?.toLocaleString() || "0.00"} {account.currency}
                        </p>
                      )}
                    </div>
                    {account.brokerCategory === "forex" && (
                      <div>
                        <p className="text-sm text-muted-foreground">Margin Level</p>
                        <p className="font-medium">{account.marginLevel?.toFixed(2) || "-"}%</p>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                    <p>Last synced: {formatDistanceToNow(new Date(account.lastSynced), { addSuffix: true })}</p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRefresh(account.id)}
                      disabled={refreshing[account.id]}
                    >
                      {refreshing[account.id] ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Syncing...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="mr-2 h-4 w-4" />
                          Refresh
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDisconnectBroker(account.id, brokerDetails?.name || account.brokerType)}
                    disabled={isDisconnecting && selectedBrokerId === account.id}
                  >
                    {isDisconnecting && selectedBrokerId === account.id ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Disconnecting...
                      </>
                    ) : (
                      <>
                        <Trash2 className="mr-1 h-4 w-4" />
                        Disconnect
                      </>
                    )}
                  </Button>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => router.push(`/dashboard/broker-accounts/${account.id}`)}
                  >
                    <Settings className="mr-1 h-4 w-4" />
                    Settings
                  </Button>
                  <Button size="sm">
                    <ExternalLink className="mr-1 h-4 w-4" />
                    View Account
                  </Button>
                </div>
              </CardFooter>
            </Card>
          )
        })}
      </div>
    </div>
  )
}

