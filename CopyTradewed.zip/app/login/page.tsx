"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { TrendingUp, Eye, EyeOff, Loader2, AlertCircle } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { useToast } from "@/components/ui/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { sendEmail, trackLoginActivity } from "@/lib/email-service"

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { login, user } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [rememberMe, setRememberMe] = useState(false)
  const [loginAttempts, setLoginAttempts] = useState(0)
  const [isLocked, setIsLocked] = useState(false)
  const [lockTimer, setLockTimer] = useState(0)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  })
  const [formErrors, setFormErrors] = useState({
    email: "",
    password: "",
  })

  // Check for redirect reason
  const redirectReason = searchParams.get("reason")

  useEffect(() => {
    // Check if account is locked from localStorage
    const lockedUntil = localStorage.getItem("accountLockedUntil")
    if (lockedUntil) {
      const lockTime = Number.parseInt(lockedUntil)
      if (lockTime > Date.now()) {
        setIsLocked(true)
        const remainingTime = Math.ceil((lockTime - Date.now()) / 1000)
        setLockTimer(remainingTime)
      } else {
        localStorage.removeItem("accountLockedUntil")
      }
    }
  }, [])

  useEffect(() => {
    // Countdown timer for account lock
    if (isLocked && lockTimer > 0) {
      const interval = setInterval(() => {
        setLockTimer((prev) => {
          if (prev <= 1) {
            clearInterval(interval)
            setIsLocked(false)
            localStorage.removeItem("accountLockedUntil")
            return 0
          }
          return prev - 1
        })
      }, 1000)

      return () => clearInterval(interval)
    }
  }, [isLocked, lockTimer])

  const validateForm = () => {
    let valid = true
    const errors = {
      email: "",
      password: "",
    }

    // Email validation
    if (!formData.email) {
      errors.email = "Email is required"
      valid = false
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      errors.email = "Email is invalid"
      valid = false
    }

    // Password validation
    if (!formData.password) {
      errors.password = "Password is required"
      valid = false
    } else if (formData.password.length < 8) {
      errors.password = "Password must be at least 8 characters"
      valid = false
    }

    setFormErrors(errors)
    return valid
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))

    // Clear error when user types
    if (formErrors[name as keyof typeof formErrors]) {
      setFormErrors((prev) => ({ ...prev, [name]: "" }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (isLocked) return

    if (!validateForm()) return

    setIsLoading(true)

    try {
      const success = await login(formData.email, formData.password)

      if (success) {
        // Reset login attempts on success
        setLoginAttempts(0)
        localStorage.removeItem("loginAttempts")

        if (rememberMe) {
          localStorage.setItem("rememberedEmail", formData.email)
        } else {
          localStorage.removeItem("rememberedEmail")
        }

        // Get IP address (in a real app, this would be done server-side)
        // For demo purposes, we'll use a placeholder
        const ipAddress = "192.168.1.1" // This would normally come from the server

        // Track login activity and send notification
        if (user) {
          await trackLoginActivity(user, ipAddress, navigator.userAgent)
        }

        toast({
          title: "Login successful",
          description: "Welcome back to TradeCopy!",
        })

        // Also show a toast about the login alert
        toast({
          title: "Login alert sent",
          description: "An email notification about this login has been sent to your email address.",
        })

        router.push("/dashboard")
      } else {
        // Increment login attempts
        const newAttempts = loginAttempts + 1
        setLoginAttempts(newAttempts)
        localStorage.setItem("loginAttempts", newAttempts.toString())

        // Lock account after 5 failed attempts
        if (newAttempts >= 5) {
          const lockDuration = 5 * 60 * 1000 // 5 minutes
          const unlockTime = Date.now() + lockDuration
          localStorage.setItem("accountLockedUntil", unlockTime.toString())
          setIsLocked(true)
          setLockTimer(300) // 5 minutes in seconds

          // Send security alert email about multiple failed attempts
          if (formData.email && /\S+@\S+\.\S+/.test(formData.email)) {
            await sendEmail({
              to: formData.email,
              template: "security-alert",
              subject: "Security Alert: Multiple Failed Login Attempts",
              data: {
                time: new Date().toLocaleString(),
                attempts: newAttempts,
                ipAddress: "192.168.1.1", // This would normally come from the server
                location: "Unknown Location", // This would normally be resolved from the IP
              },
            })
          }

          toast({
            title: "Account temporarily locked",
            description: "Too many failed login attempts. Please try again in 5 minutes.",
            variant: "destructive",
          })
        } else {
          toast({
            title: "Login failed",
            description: "Invalid email or password. Please try again.",
            variant: "destructive",
          })
        }
      }
    } catch (error) {
      toast({
        title: "Login failed",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Load remembered email
  useEffect(() => {
    const rememberedEmail = localStorage.getItem("rememberedEmail")
    if (rememberedEmail) {
      setFormData((prev) => ({ ...prev, email: rememberedEmail }))
      setRememberMe(true)
    }
  }, [])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-muted/40 p-4">
      <Link href="/" className="absolute left-8 top-8 flex items-center gap-2 md:left-12 md:top-12">
        <TrendingUp className="h-6 w-6" />
        <span className="text-xl font-bold">TradeCopy</span>
      </Link>

      <Card className="w-full max-w-md">
        <form onSubmit={handleSubmit}>
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-bold">Log in</CardTitle>
            <CardDescription>Enter your email and password to access your account</CardDescription>
          </CardHeader>

          {redirectReason === "session_expired" && (
            <div className="px-6">
              <Alert variant="warning" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Session expired</AlertTitle>
                <AlertDescription>Your session has expired. Please log in again to continue.</AlertDescription>
              </Alert>
            </div>
          )}

          {isLocked && (
            <div className="px-6">
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Account temporarily locked</AlertTitle>
                <AlertDescription>
                  Too many failed login attempts. Please try again in {Math.floor(lockTimer / 60)}:
                  {(lockTimer % 60).toString().padStart(2, "0")}.
                </AlertDescription>
              </Alert>
            </div>
          )}

          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="name@example.com"
                value={formData.email}
                onChange={handleChange}
                disabled={isLoading || isLocked}
                className={formErrors.email ? "border-red-500" : ""}
              />
              {formErrors.email && <p className="text-xs text-red-500">{formErrors.email}</p>}
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link href="/forgot-password" className="text-xs text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleChange}
                  disabled={isLoading || isLocked}
                  className={formErrors.password ? "border-red-500 pr-10" : "pr-10"}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500"
                  onClick={() => setShowPassword(!showPassword)}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {formErrors.password && <p className="text-xs text-red-500">{formErrors.password}</p>}
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="remember-me"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked === true)}
                disabled={isLoading || isLocked}
              />
              <Label htmlFor="remember-me" className="text-sm">
                Remember me
              </Label>
            </div>

            <Button className="w-full" type="submit" disabled={isLoading || isLocked}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Logging in...
                </>
              ) : (
                "Log in"
              )}
            </Button>
            <div className="relative flex items-center justify-center">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative px-4 text-xs uppercase bg-background text-muted-foreground">
                Or continue with
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline" className="w-full" type="button" disabled={isLoading || isLocked}>
                Google
              </Button>
              <Button variant="outline" className="w-full" type="button" disabled={isLoading || isLocked}>
                Apple
              </Button>
            </div>
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-sm text-center text-muted-foreground">
              Don&apos;t have an account?{" "}
              <Link href="/signup" className="text-primary hover:underline">
                Sign up
              </Link>
            </div>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}

