"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { PortfolioOverview } from "@/components/portfolio-overview"
import { FollowedTraders } from "@/components/followed-traders"
import { RecentTrades } from "@/components/recent-trades"
import { useCopyTrading } from "@/lib/copy-trading"
import { usePortfolio } from "@/lib/portfolio"
import { Menu, TrendingUp, Users, BarChart3, Plus, Settings } from "lucide-react"

export function MobileDashboard() {
  const router = useRouter()
  const { isEnabled, toggleCopyTrading } = useCopyTrading()
  const { balance, positions } = usePortfolio()
  const [activeTab, setActiveTab] = useState("overview")

  const calculateTotalProfitLoss = () => {
    return positions.reduce((total, position) => {
      const positionPL = (position.currentPrice - position.entryPrice) * position.quantity
      return total + positionPL
    }, 0)
  }

  const calculateDailyChange = () => {
    // In a real app, this would calculate the actual daily change
    // For this prototype, we'll return a fixed percentage of the total P&L
    return calculateTotalProfitLoss() * 0.1
  }

  return (
    <div className="space-y-4 p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0">
              <DashboardSidebar />
            </SheetContent>
          </Sheet>

          <h1 className="text-xl font-bold">Dashboard</h1>
        </div>

        <Button variant={isEnabled ? "destructive" : "default"} size="sm" onClick={() => toggleCopyTrading(!isEnabled)}>
          {isEnabled ? "Pause Copying" : "Start Copying"}
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Card>
          <CardHeader className="p-3">
            <CardTitle className="text-sm">Balance</CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            <div className="text-xl font-bold">${balance.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Available for trading</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="p-3">
            <CardTitle className="text-sm">P&L</CardTitle>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            <div className={`text-xl font-bold ${calculateTotalProfitLoss() >= 0 ? "text-green-600" : "text-red-600"}`}>
              {calculateTotalProfitLoss() >= 0 ? "+" : ""}${calculateTotalProfitLoss().toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              {calculateDailyChange() >= 0 ? "+" : ""}
              {((calculateDailyChange() / (balance - calculateDailyChange())) * 100).toFixed(2)}% today
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="traders">Traders</TabsTrigger>
          <TabsTrigger value="trades">Trades</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4 space-y-4">
          <PortfolioOverview />

          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardHeader className="p-3">
                <CardTitle className="text-sm">Active Positions</CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-0">
                <div className="text-xl font-bold">{positions.length}</div>
                <Button
                  variant="link"
                  className="p-0 h-auto text-xs"
                  onClick={() => router.push("/dashboard/portfolio")}
                >
                  View all
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="p-3">
                <CardTitle className="text-sm">Followed Traders</CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-0">
                <div className="text-xl font-bold">3</div>
                <Button variant="link" className="p-0 h-auto text-xs" onClick={() => router.push("/dashboard/traders")}>
                  View all
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <Card>
              <CardHeader className="p-3">
                <CardTitle className="text-sm">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-0 grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="justify-start"
                  onClick={() => router.push("/dashboard/connect-broker")}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Connect Broker
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  className="justify-start"
                  onClick={() => router.push("/dashboard/traders")}
                >
                  <Users className="mr-2 h-4 w-4" />
                  Find Traders
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  className="justify-start"
                  onClick={() => router.push("/dashboard/market")}
                >
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Market Data
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  className="justify-start"
                  onClick={() => router.push("/dashboard/settings/copy-trading")}
                >
                  <Settings className="mr-2 h-4 w-4" />
                  Copy Settings
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="traders" className="mt-4">
          <FollowedTraders />
        </TabsContent>

        <TabsContent value="trades" className="mt-4">
          <RecentTrades />
        </TabsContent>
      </Tabs>

      <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-2 flex justify-around">
        <Button
          variant="ghost"
          size="sm"
          className="flex flex-col items-center gap-1"
          onClick={() => router.push("/dashboard")}
        >
          <BarChart3 className="h-4 w-4" />
          <span className="text-xs">Dashboard</span>
        </Button>

        <Button
          variant="ghost"
          size="sm"
          className="flex flex-col items-center gap-1"
          onClick={() => router.push("/dashboard/traders")}
        >
          <Users className="h-4 w-4" />
          <span className="text-xs">Traders</span>
        </Button>

        <Button
          variant="ghost"
          size="sm"
          className="flex flex-col items-center gap-1"
          onClick={() => router.push("/dashboard/portfolio")}
        >
          <TrendingUp className="h-4 w-4" />
          <span className="text-xs">Portfolio</span>
        </Button>

        <Button
          variant="ghost"
          size="sm"
          className="flex flex-col items-center gap-1"
          onClick={() => router.push("/dashboard/settings")}
        >
          <Settings className="h-4 w-4" />
          <span className="text-xs">Settings</span>
        </Button>
      </div>
    </div>
  )
}

