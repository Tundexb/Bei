"use client"

import { Badge } from "@/components/ui/badge"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Check, CreditCard, Lock } from "lucide-react"

interface SubscriptionPaymentProps {
  traderId: string
  traderName: string
  subscriptionFee: number
  subscriptionPeriod: "monthly" | "quarterly" | "yearly"
  onSuccess?: () => void
  onCancel?: () => void
}

export function SubscriptionPayment({
  traderId,
  traderName,
  subscriptionFee,
  subscriptionPeriod,
  onSuccess,
  onCancel,
}: SubscriptionPaymentProps) {
  const router = useRouter()
  const { toast } = useToast()

  const [paymentMethod, setPaymentMethod] = useState("credit-card")
  const [isProcessing, setIsProcessing] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)

  const [cardDetails, setCardDetails] = useState({
    cardNumber: "",
    cardholderName: "",
    expiryDate: "",
    cvv: "",
  })

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setCardDetails((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false)
      setIsSuccess(true)

      toast({
        title: "Payment Successful",
        description: `You are now subscribed to ${traderName}'s signals.`,
      })

      if (onSuccess) {
        onSuccess()
      }
    }, 2000)
  }

  if (isSuccess) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="rounded-full bg-green-100 p-3">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold">Payment Successful!</h2>
            <p className="text-muted-foreground">
              You are now subscribed to {traderName}'s signals. You can start copying their trades immediately.
            </p>
            <div className="flex flex-col space-y-2 w-full pt-4">
              <Button onClick={() => router.push("/dashboard/copy-trading")}>Go to Copy Trading Dashboard</Button>
              <Button variant="outline" onClick={() => router.push(`/traders/${traderId}`)}>
                Back to Trader Profile
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Subscribe to {traderName}</CardTitle>
        <CardDescription>Complete your payment to start copying trades from {traderName}</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="payment-details">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="payment-details">Payment Details</TabsTrigger>
            <TabsTrigger value="subscription-details">Subscription Details</TabsTrigger>
          </TabsList>

          <TabsContent value="payment-details" className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Payment Method</Label>
              <RadioGroup defaultValue="credit-card" value={paymentMethod} onValueChange={setPaymentMethod}>
                <div className="flex items-center space-x-2 rounded-md border p-3">
                  <RadioGroupItem value="credit-card" id="credit-card" />
                  <Label htmlFor="credit-card" className="flex-1">
                    Credit Card
                  </Label>
                  <div className="flex gap-1">
                    <div className="h-6 w-10 rounded bg-muted"></div>
                    <div className="h-6 w-10 rounded bg-muted"></div>
                    <div className="h-6 w-10 rounded bg-muted"></div>
                  </div>
                </div>

                <div className="flex items-center space-x-2 rounded-md border p-3">
                  <RadioGroupItem value="paypal" id="paypal" />
                  <Label htmlFor="paypal" className="flex-1">
                    PayPal
                  </Label>
                  <div className="h-6 w-10 rounded bg-muted"></div>
                </div>

                <div className="flex items-center space-x-2 rounded-md border p-3">
                  <RadioGroupItem value="crypto" id="crypto" />
                  <Label htmlFor="crypto" className="flex-1">
                    Cryptocurrency
                  </Label>
                  <div className="h-6 w-10 rounded bg-muted"></div>
                </div>
              </RadioGroup>
            </div>

            {paymentMethod === "credit-card" && (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="cardNumber">Card Number</Label>
                  <Input
                    id="cardNumber"
                    name="cardNumber"
                    placeholder="1234 5678 9012 3456"
                    value={cardDetails.cardNumber}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="cardholderName">Cardholder Name</Label>
                  <Input
                    id="cardholderName"
                    name="cardholderName"
                    placeholder="John Doe"
                    value={cardDetails.cardholderName}
                    onChange={handleInputChange}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="expiryDate">Expiry Date</Label>
                    <Input
                      id="expiryDate"
                      name="expiryDate"
                      placeholder="MM/YY"
                      value={cardDetails.expiryDate}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="cvv">CVV</Label>
                    <Input
                      id="cvv"
                      name="cvv"
                      placeholder="123"
                      value={cardDetails.cvv}
                      onChange={handleInputChange}
                      required
                    />
                  </div>
                </div>

                <div className="flex items-center text-sm text-muted-foreground">
                  <Lock className="mr-2 h-4 w-4" />
                  Your payment information is secure and encrypted
                </div>
              </form>
            )}

            {paymentMethod === "paypal" && (
              <div className="flex flex-col items-center justify-center py-6">
                <p className="text-center text-muted-foreground mb-4">
                  You will be redirected to PayPal to complete your payment.
                </p>
                <Button className="w-full">Continue to PayPal</Button>
              </div>
            )}

            {paymentMethod === "crypto" && (
              <div className="flex flex-col items-center justify-center py-6">
                <p className="text-center text-muted-foreground mb-4">
                  You will be redirected to our crypto payment processor to complete your payment.
                </p>
                <Button className="w-full">Continue to Crypto Payment</Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="subscription-details" className="space-y-4 py-4">
            <div className="rounded-md border p-4">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="font-medium">{traderName}</h3>
                  <p className="text-sm text-muted-foreground">Subscription Details</p>
                </div>
                <Badge variant="outline" className="bg-green-50 text-green-700">
                  Active
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Subscription Fee</span>
                  <span className="text-sm font-medium">
                    ${subscriptionFee}/{subscriptionPeriod}
                  </span>
                </div>

                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Platform Fee</span>
                  <span className="text-sm font-medium">${(subscriptionFee * 0.05).toFixed(2)}</span>
                </div>

                <Separator />

                <div className="flex justify-between">
                  <span className="text-sm font-medium">Total</span>
                  <span className="text-sm font-medium">${(subscriptionFee * 1.05).toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Access to all trading signals</span>
                </div>

                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Automatic trade copying</span>
                </div>

                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Performance analytics</span>
                </div>

                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Priority customer support</span>
                </div>
              </div>

              <div className="mt-4 text-xs text-muted-foreground">
                <p>
                  Your subscription will renew automatically every {subscriptionPeriod}. You can cancel anytime from
                  your dashboard.
                </p>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button onClick={handleSubmit} disabled={isProcessing}>
          {isProcessing ? (
            <>Processing...</>
          ) : (
            <>
              <CreditCard className="mr-2 h-4 w-4" />
              Pay ${(subscriptionFee * 1.05).toFixed(2)}
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

