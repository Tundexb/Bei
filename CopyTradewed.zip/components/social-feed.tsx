"use client"

import type React from "react"

import { useState } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  AlertCircle,
  BarChart2,
  BookmarkPlus,
  Copy,
  DollarSign,
  Flag,
  Heart,
  Image,
  Loader2,
  MessageSquare,
  MoreHorizontal,
  PenSquare,
  Share2,
  Shield,
  Star,
  TrendingUp,
  UserCheck,
} from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useAuth } from "@/lib/auth"
import { useToast } from "@/components/ui/use-toast"

// Post type
type Post = {
  id: string
  author: {
    id: string
    name: string
    username: string
    avatar: string
    isVerified: boolean
    badges: string[]
  }
  content: string
  timestamp: string
  likes: number
  comments: number
  isLiked: boolean
  isSaved: boolean
  attachments?: {
    type: "image" | "chart" | "trade"
    url: string
    caption?: string
  }[]
  tradeDetails?: {
    symbol: string
    type: "buy" | "sell"
    entry: number
    target?: number
    stopLoss?: number
    result?: "win" | "loss" | "open"
    profit?: number
    profitPercentage?: number
  }
}

// Sample posts data
const samplePosts: Post[] = [
  {
    id: "post1",
    author: {
      id: "user1",
      name: "Sarah Johnson",
      username: "sarahtrader",
      avatar: "/avatars/sarah.jpg",
      isVerified: true,
      badges: ["professional_trader", "consistent_performer"],
    },
    content:
      "Just spotted a great setup on EUR/USD. Looking for a potential breakout above 1.0950 with targets at 1.1000. Will keep you updated on this trade!",
    timestamp: new Date(Date.now() - 35 * 60 * 1000).toISOString(), // 35 minutes ago
    likes: 42,
    comments: 7,
    isLiked: true,
    isSaved: false,
    attachments: [
      {
        type: "chart",
        url: "/charts/eurusd-chart.jpg",
        caption: "EUR/USD 4H Chart",
      },
    ],
    tradeDetails: {
      symbol: "EUR/USD",
      type: "buy",
      entry: 1.095,
      target: 1.1,
      stopLoss: 1.092,
      result: "open",
    },
  },
  {
    id: "post2",
    author: {
      id: "user2",
      name: "Michael Chen",
      username: "miketrader",
      avatar: "/avatars/michael.jpg",
      isVerified: true,
      badges: ["risk_manager", "market_veteran"],
    },
    content:
      "Closed my AAPL position today with a nice profit. The tech sector is showing strength despite market uncertainties. Looking for new opportunities in the semiconductor space.",
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(), // 3 hours ago
    likes: 78,
    comments: 12,
    isLiked: false,
    isSaved: true,
    tradeDetails: {
      symbol: "AAPL",
      type: "buy",
      entry: 187.5,
      target: 195.0,
      stopLoss: 182.0,
      result: "win",
      profit: 750,
      profitPercentage: 4.0,
    },
  },
  {
    id: "post3",
    author: {
      id: "user3",
      name: "Emma Wilson",
      username: "emmatrader",
      avatar: "/avatars/emma.jpg",
      isVerified: false,
      badges: ["active_trader"],
    },
    content:
      "Market analysis for today: The S&P 500 is testing key resistance levels. Watch for a potential pullback before continuing the uptrend. I'm staying cautious and keeping position sizes small.",
    timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
    likes: 31,
    comments: 5,
    isLiked: false,
    isSaved: false,
    attachments: [
      {
        type: "chart",
        url: "/charts/sp500-chart.jpg",
        caption: "S&P 500 Daily Chart",
      },
    ],
  },
  {
    id: "post4",
    author: {
      id: "user4",
      name: "David Rodriguez",
      username: "davidcrypto",
      avatar: "/avatars/david.jpg",
      isVerified: true,
      badges: ["diversified_trader", "community_contributor"],
    },
    content:
      "Bitcoin showing strength above $60K. The recent institutional adoption is a game-changer. I'm maintaining my long position with a trailing stop. What's your BTC strategy?",
    timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
    likes: 105,
    comments: 23,
    isLiked: true,
    isSaved: true,
    attachments: [
      {
        type: "chart",
        url: "/charts/btc-chart.jpg",
        caption: "BTC/USD Daily Chart",
      },
    ],
    tradeDetails: {
      symbol: "BTC/USD",
      type: "buy",
      entry: 58750,
      target: 65000,
      stopLoss: 55000,
      result: "open",
    },
  },
  {
    id: "post5",
    author: {
      id: "user5",
      name: "Sophia Lee",
      username: "sophiaforex",
      avatar: "/avatars/sophia.jpg",
      isVerified: true,
      badges: ["professional_trader", "winning_streak"],
    },
    content:
      "Just closed my GBP/JPY trade with a 120 pip profit! The strategy of trading the London-Tokyo session overlap continues to work well for me. Will share more setups tomorrow.",
    timestamp: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(), // 4 days ago
    likes: 67,
    comments: 9,
    isLiked: false,
    isSaved: false,
    tradeDetails: {
      symbol: "GBP/JPY",
      type: "buy",
      entry: 186.5,
      target: 188.0,
      stopLoss: 185.8,
      result: "win",
      profit: 450,
      profitPercentage: 0.8,
    },
  },
]

// Badge mapping
const badgeInfo: Record<string, { icon: React.ReactNode; color: string }> = {
  professional_trader: { icon: <Shield className="h-3 w-3" />, color: "bg-purple-500" },
  consistent_performer: { icon: <TrendingUp className="h-3 w-3" />, color: "bg-green-500" },
  risk_manager: { icon: <Shield className="h-3 w-3" />, color: "bg-blue-500" },
  market_veteran: { icon: <Star className="h-3 w-3" />, color: "bg-orange-500" },
  active_trader: { icon: <BarChart2 className="h-3 w-3" />, color: "bg-purple-500" },
  diversified_trader: { icon: <Copy className="h-3 w-3" />, color: "bg-indigo-500" },
  community_contributor: { icon: <MessageSquare className="h-3 w-3" />, color: "bg-pink-500" },
  winning_streak: { icon: <TrendingUp className="h-3 w-3" />, color: "bg-yellow-500" },
}

export function SocialFeed() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [posts, setPosts] = useState<Post[]>(samplePosts)
  const [newPostContent, setNewPostContent] = useState("")
  const [isPosting, setIsPosting] = useState(false)
  const [activeTab, setActiveTab] = useState("all")

  const handleLikePost = (postId: string) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          const newIsLiked = !post.isLiked
          return {
            ...post,
            isLiked: newIsLiked,
            likes: newIsLiked ? post.likes + 1 : post.likes - 1,
          }
        }
        return post
      }),
    )
  }

  const handleSavePost = (postId: string) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          const newIsSaved = !post.isSaved

          if (newIsSaved) {
            toast({
              title: "Post saved",
              description: "This post has been added to your saved items.",
            })
          }

          return {
            ...post,
            isSaved: newIsSaved,
          }
        }
        return post
      }),
    )
  }

  const handleSubmitPost = () => {
    if (!newPostContent.trim()) return

    setIsPosting(true)

    // Simulate API call
    setTimeout(() => {
      const newPost: Post = {
        id: `post${Date.now()}`,
        author: {
          id: user?.id || "current-user",
          name: user?.name || "Current User",
          username: user?.username || "currentuser",
          avatar: user?.avatar || "/avatars/default.jpg",
          isVerified: false,
          badges: [],
        },
        content: newPostContent,
        timestamp: new Date().toISOString(),
        likes: 0,
        comments: 0,
        isLiked: false,
        isSaved: false,
      }

      setPosts([newPost, ...posts])
      setNewPostContent("")
      setIsPosting(false)

      toast({
        title: "Post published",
        description: "Your post has been published to the feed.",
      })
    }, 1500)
  }

  const filteredPosts =
    activeTab === "all"
      ? posts
      : activeTab === "trades"
        ? posts.filter((post) => post.tradeDetails)
        : activeTab === "analysis"
          ? posts.filter((post) => post.attachments?.some((a) => a.type === "chart"))
          : posts

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Social Feed</h2>
        <p className="text-muted-foreground">Connect with traders and share insights</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-start gap-4">
            <Avatar>
              <AvatarImage src={user?.avatar || "/avatars/default.jpg"} alt={user?.name || "User"} />
              <AvatarFallback>{user?.name?.charAt(0) || "U"}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <Textarea
                placeholder="Share your trading insights or analysis..."
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                className="min-h-[100px] resize-none"
              />
            </div>
          </div>
        </CardHeader>
        <CardFooter className="flex justify-between">
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Image className="mr-2 h-4 w-4" />
              Add Image
            </Button>
            <Button variant="outline" size="sm">
              <BarChart2 className="mr-2 h-4 w-4" />
              Add Chart
            </Button>
            <Button variant="outline" size="sm">
              <DollarSign className="mr-2 h-4 w-4" />
              Add Trade
            </Button>
          </div>
          <Button onClick={handleSubmitPost} disabled={!newPostContent.trim() || isPosting}>
            {isPosting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Posting...
              </>
            ) : (
              <>
                <PenSquare className="mr-2 h-4 w-4" />
                Post
              </>
            )}
          </Button>
        </CardFooter>
      </Card>

      <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="all">All Posts</TabsTrigger>
          <TabsTrigger value="trades">Trades</TabsTrigger>
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6 space-y-4">
          {filteredPosts.map((post) => (
            <PostCard key={post.id} post={post} onLike={handleLikePost} onSave={handleSavePost} />
          ))}
        </TabsContent>

        <TabsContent value="trades" className="mt-6 space-y-4">
          {filteredPosts.length > 0 ? (
            filteredPosts.map((post) => (
              <PostCard key={post.id} post={post} onLike={handleLikePost} onSave={handleSavePost} />
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-8 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No trade posts found</h3>
                <p className="text-sm text-muted-foreground mb-6 max-w-md">
                  There are no trade posts in this category yet. Be the first to share a trade!
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="analysis" className="mt-6 space-y-4">
          {filteredPosts.length > 0 ? (
            filteredPosts.map((post) => (
              <PostCard key={post.id} post={post} onLike={handleLikePost} onSave={handleSavePost} />
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-8 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No analysis posts found</h3>
                <p className="text-sm text-muted-foreground mb-6 max-w-md">
                  There are no market analysis posts in this category yet. Share your insights!
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="following" className="mt-6 space-y-4">
          {filteredPosts.length > 0 ? (
            filteredPosts.map((post) => (
              <PostCard key={post.id} post={post} onLike={handleLikePost} onSave={handleSavePost} />
            ))
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-8 text-center">
                <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No posts from followed traders</h3>
                <p className="text-sm text-muted-foreground mb-6 max-w-md">
                  You're not following any traders yet, or they haven't posted recently.
                </p>
                <Button>Discover Traders</Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

function PostCard({
  post,
  onLike,
  onSave,
}: { post: Post; onLike: (id: string) => void; onSave: (id: string) => void }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src={post.author.avatar || "/avatars/default.jpg"} alt={post.author.name} />
              <AvatarFallback>{post.author.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center">
                <span className="font-medium">{post.author.name}</span>
                {post.author.isVerified && (
                  <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700 hover:bg-blue-50">
                    <UserCheck className="mr-1 h-3 w-3" />
                    Verified
                  </Badge>
                )}
              </div>
              <div className="flex items-center text-sm text-muted-foreground">
                <span>@{post.author.username}</span>
                <span className="mx-1">•</span>
                <span>{formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}</span>
              </div>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => onSave(post.id)}>
                {post.isSaved ? "Unsave Post" : "Save Post"}
              </DropdownMenuItem>
              <DropdownMenuItem>Copy Link</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600">
                <Flag className="mr-2 h-4 w-4" />
                Report Post
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Author badges */}
        {post.author.badges.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {post.author.badges.map((badgeId) => {
              const badge = badgeInfo[badgeId]
              if (!badge) return null

              return (
                <Badge key={badgeId} variant="outline" className={`${badge.color} bg-opacity-10 text-xs`}>
                  {badge.icon}
                  <span className="ml-1">
                    {badgeId
                      .split("_")
                      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                      .join(" ")}
                  </span>
                </Badge>
              )
            })}
          </div>
        )}
      </CardHeader>

      <CardContent className="pb-3">
        <p className="whitespace-pre-line">{post.content}</p>

        {/* Trade details */}
        {post.tradeDetails && (
          <div className="mt-4 p-3 bg-muted rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <span className="font-medium">{post.tradeDetails.symbol}</span>
                <Badge
                  className={
                    post.tradeDetails.type === "buy"
                      ? "ml-2 bg-green-100 text-green-800"
                      : "ml-2 bg-red-100 text-red-800"
                  }
                >
                  {post.tradeDetails.type.toUpperCase()}
                </Badge>
              </div>

              {post.tradeDetails.result && (
                <Badge
                  className={
                    post.tradeDetails.result === "win"
                      ? "bg-green-100 text-green-800"
                      : post.tradeDetails.result === "loss"
                        ? "bg-red-100 text-red-800"
                        : "bg-blue-100 text-blue-800"
                  }
                >
                  {post.tradeDetails.result === "open" ? "OPEN" : post.tradeDetails.result === "win" ? "WIN" : "LOSS"}
                </Badge>
              )}
            </div>

            <div className="grid grid-cols-3 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Entry:</span> {post.tradeDetails.entry}
              </div>
              {post.tradeDetails.target && (
                <div>
                  <span className="text-muted-foreground">Target:</span> {post.tradeDetails.target}
                </div>
              )}
              {post.tradeDetails.stopLoss && (
                <div>
                  <span className="text-muted-foreground">Stop:</span> {post.tradeDetails.stopLoss}
                </div>
              )}
            </div>

            {post.tradeDetails.profit !== undefined && (
              <div className="mt-2 flex items-center text-sm">
                <span className="text-muted-foreground mr-2">Result:</span>
                <span className={post.tradeDetails.profit >= 0 ? "text-green-600" : "text-red-600"}>
                  {post.tradeDetails.profit >= 0 ? "+" : ""}
                  {post.tradeDetails.profit} ({post.tradeDetails.profitPercentage}%)
                </span>
              </div>
            )}
          </div>
        )}

        {/* Attachments */}
        {post.attachments && post.attachments.length > 0 && (
          <div className="mt-4">
            {post.attachments.map((attachment, index) => (
              <div key={index} className="rounded-lg overflow-hidden">
                <img
                  src={attachment.url || "/placeholder.svg?height=300&width=500"}
                  alt={attachment.caption || "Post attachment"}
                  className="w-full h-auto object-cover"
                />
                {attachment.caption && <p className="text-sm text-muted-foreground mt-1">{attachment.caption}</p>}
              </div>
            ))}
          </div>
        )}
      </CardContent>

      <CardFooter>
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            className={post.isLiked ? "text-red-500" : ""}
            onClick={() => onLike(post.id)}
          >
            <Heart className={`mr-1 h-4 w-4 ${post.isLiked ? "fill-red-500" : ""}`} />
            {post.likes}
          </Button>
          <Button variant="ghost" size="sm">
            <MessageSquare className="mr-1 h-4 w-4" />
            {post.comments}
          </Button>
          <Button variant="ghost" size="sm" onClick={() => onSave(post.id)}>
            <BookmarkPlus className={`mr-1 h-4 w-4 ${post.isSaved ? "fill-current" : ""}`} />
            {post.isSaved ? "Saved" : "Save"}
          </Button>
          <Button variant="ghost" size="sm">
            <Share2 className="mr-1 h-4 w-4" />
            Share
          </Button>
        </div>
      </CardFooter>
    </Card>
  )
}

