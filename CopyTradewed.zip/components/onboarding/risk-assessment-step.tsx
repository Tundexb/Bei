"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface RiskAssessmentStepProps {
  onboardingData: any
  updateOnboardingData: (data: any) => void
}

export function RiskAssessmentStep({ onboardingData, updateOnboardingData }: RiskAssessmentStepProps) {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)

  const [answers, setAnswers] = useState({
    investmentGoal: "",
    timeHorizon: "",
    riskTolerance: "",
    lossReaction: "",
    investmentAmount: 5000,
    maxDrawdown: 10,
  })

  const handleChange = (question: string, answer: string | number) => {
    setAnswers((prev) => ({ ...prev, [question]: answer }))
  }

  const handleSubmit = () => {
    setIsLoading(true)

    // Calculate risk profile based on answers
    let riskScore = 0

    // Investment goal scoring
    if (answers.investmentGoal === "preservation") riskScore += 1
    if (answers.investmentGoal === "income") riskScore += 2
    if (answers.investmentGoal === "growth") riskScore += 3
    if (answers.investmentGoal === "aggressive") riskScore += 4

    // Time horizon scoring
    if (answers.timeHorizon === "short") riskScore += 1
    if (answers.timeHorizon === "medium") riskScore += 2
    if (answers.timeHorizon === "long") riskScore += 3

    // Risk tolerance scoring
    if (answers.riskTolerance === "low") riskScore += 1
    if (answers.riskTolerance === "moderate") riskScore += 2
    if (answers.riskTolerance === "high") riskScore += 3

    // Loss reaction scoring
    if (answers.lossReaction === "sell") riskScore += 1
    if (answers.lossReaction === "wait") riskScore += 2
    if (answers.lossReaction === "buy") riskScore += 3

    // Determine risk profile
    let riskProfile
    if (riskScore <= 4) riskProfile = "conservative"
    else if (riskScore <= 8) riskProfile = "moderate"
    else riskProfile = "aggressive"

    // Simulate API call
    setTimeout(() => {
      // Update onboarding data with risk profile
      updateOnboardingData({
        riskProfile,
        investmentAmount: answers.investmentAmount,
        maxDrawdown: answers.maxDrawdown,
      })

      toast({
        title: "Risk assessment complete",
        description: `Your risk profile has been determined as ${riskProfile.charAt(0).toUpperCase() + riskProfile.slice(1)}.`,
      })

      setIsLoading(false)
    }, 1000)
  }

  const isComplete = answers.investmentGoal && answers.timeHorizon && answers.riskTolerance && answers.lossReaction

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold">Risk Assessment</h2>
        <p className="text-muted-foreground">
          Let's determine your risk profile to help you find suitable traders to follow
        </p>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Important</AlertTitle>
        <AlertDescription>
          This assessment helps us understand your risk tolerance, but all investments carry risk. Only invest what you
          can afford to lose.
        </AlertDescription>
      </Alert>

      <div className="space-y-6">
        <div className="space-y-3">
          <Label>What is your primary investment goal?</Label>
          <RadioGroup value={answers.investmentGoal} onValueChange={(value) => handleChange("investmentGoal", value)}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="preservation" id="goal-1" />
              <Label htmlFor="goal-1">Capital preservation (minimize risk)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="income" id="goal-2" />
              <Label htmlFor="goal-2">Income generation</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="growth" id="goal-3" />
              <Label htmlFor="goal-3">Growth and income</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="aggressive" id="goal-4" />
              <Label htmlFor="goal-4">Aggressive growth</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-3">
          <Label>What is your investment time horizon?</Label>
          <RadioGroup value={answers.timeHorizon} onValueChange={(value) => handleChange("timeHorizon", value)}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="short" id="time-1" />
              <Label htmlFor="time-1">Short-term (less than 1 year)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="medium" id="time-2" />
              <Label htmlFor="time-2">Medium-term (1-3 years)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="long" id="time-3" />
              <Label htmlFor="time-3">Long-term (3+ years)</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-3">
          <Label>How would you describe your risk tolerance?</Label>
          <RadioGroup value={answers.riskTolerance} onValueChange={(value) => handleChange("riskTolerance", value)}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="low" id="risk-1" />
              <Label htmlFor="risk-1">Low (prefer stability over growth)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="moderate" id="risk-2" />
              <Label htmlFor="risk-2">Moderate (balance between stability and growth)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="high" id="risk-3" />
              <Label htmlFor="risk-3">High (willing to accept volatility for growth)</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-3">
          <Label>If your investment dropped 20% in value, what would you do?</Label>
          <RadioGroup value={answers.lossReaction} onValueChange={(value) => handleChange("lossReaction", value)}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="sell" id="reaction-1" />
              <Label htmlFor="reaction-1">Sell to prevent further losses</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="wait" id="reaction-2" />
              <Label htmlFor="reaction-2">Wait and see if it recovers</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="buy" id="reaction-3" />
              <Label htmlFor="reaction-3">Buy more at the lower price</Label>
            </div>
          </RadioGroup>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label>How much do you plan to invest in copy trading?</Label>
            <span className="text-sm font-medium">${answers.investmentAmount.toLocaleString()}</span>
          </div>
          <Slider
            value={[answers.investmentAmount]}
            min={1000}
            max={50000}
            step={1000}
            onValueChange={(values) => handleChange("investmentAmount", values[0])}
          />
          <p className="text-xs text-muted-foreground">
            This helps us recommend appropriate position sizes and risk levels.
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label>Maximum acceptable drawdown (%)</Label>
            <span className="text-sm font-medium">{answers.maxDrawdown}%</span>
          </div>
          <Slider
            value={[answers.maxDrawdown]}
            min={5}
            max={50}
            step={5}
            onValueChange={(values) => handleChange("maxDrawdown", values[0])}
          />
          <p className="text-xs text-muted-foreground">
            The maximum percentage loss you're willing to accept before stopping trading.
          </p>
        </div>
      </div>

      <Button onClick={handleSubmit} disabled={!isComplete || isLoading} className="mt-4">
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Analyzing...
          </>
        ) : (
          "Complete Assessment"
        )}
      </Button>
    </div>
  )
}

