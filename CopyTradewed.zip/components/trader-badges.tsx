"use client"

import type React from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import {
  Award,
  BarChart2,
  CheckCircle2,
  Clock,
  HelpCircle,
  Lock,
  Shield,
  Star,
  TrendingUp,
  Trophy,
  UserCheck,
  Zap,
} from "lucide-react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

// Badge types
type BadgeType = {
  id: string
  name: string
  description: string
  icon: React.ReactNode
  category: "verification" | "performance" | "activity" | "achievement"
  unlocked: boolean
  progress?: number
  level?: number
  maxLevel?: number
  color?: string
}

// Sample badges data
const badges: BadgeType[] = [
  // Verification badges
  {
    id: "verified_trader",
    name: "Verified Trader",
    description: "Completed basic identity verification",
    icon: <UserCheck className="h-5 w-5" />,
    category: "verification",
    unlocked: true,
    color: "bg-blue-500",
  },
  {
    id: "professional_trader",
    name: "Professional Trader",
    description: "Verified trading experience and expertise",
    icon: <Shield className="h-5 w-5" />,
    category: "verification",
    unlocked: false,
    progress: 60,
    color: "bg-purple-500",
  },
  {
    id: "kyc_verified",
    name: "KYC Verified",
    description: "Completed full KYC verification process",
    icon: <CheckCircle2 className="h-5 w-5" />,
    category: "verification",
    unlocked: true,
    color: "bg-green-500",
  },

  // Performance badges
  {
    id: "consistent_performer",
    name: "Consistent Performer",
    description: "Maintained positive returns for 3+ consecutive months",
    icon: <TrendingUp className="h-5 w-5" />,
    category: "performance",
    unlocked: true,
    level: 2,
    maxLevel: 3,
    color: "bg-green-500",
  },
  {
    id: "profitable_trader",
    name: "Profitable Trader",
    description: "Achieved over 20% annual return",
    icon: <BarChart2 className="h-5 w-5" />,
    category: "performance",
    unlocked: false,
    progress: 75,
    color: "bg-yellow-500",
  },
  {
    id: "risk_manager",
    name: "Risk Manager",
    description: "Maintained low drawdown relative to returns",
    icon: <Shield className="h-5 w-5" />,
    category: "performance",
    unlocked: true,
    level: 1,
    maxLevel: 3,
    color: "bg-blue-500",
  },

  // Activity badges
  {
    id: "active_trader",
    name: "Active Trader",
    description: "Regularly active on the platform",
    icon: <Zap className="h-5 w-5" />,
    category: "activity",
    unlocked: true,
    level: 3,
    maxLevel: 5,
    color: "bg-purple-500",
  },
  {
    id: "community_contributor",
    name: "Community Contributor",
    description: "Actively contributes to the trading community",
    icon: <Award className="h-5 w-5" />,
    category: "activity",
    unlocked: true,
    level: 2,
    maxLevel: 3,
    color: "bg-pink-500",
  },
  {
    id: "mentor",
    name: "Mentor",
    description: "Helps other traders with insights and advice",
    icon: <Trophy className="h-5 w-5" />,
    category: "activity",
    unlocked: false,
    progress: 40,
    color: "bg-amber-500",
  },

  // Achievement badges
  {
    id: "winning_streak",
    name: "Winning Streak",
    description: "Achieved 10+ consecutive profitable trades",
    icon: <Star className="h-5 w-5" />,
    category: "achievement",
    unlocked: false,
    progress: 80,
    color: "bg-yellow-500",
  },
  {
    id: "diversified_trader",
    name: "Diversified Trader",
    description: "Successfully traded across multiple asset classes",
    icon: <Award className="h-5 w-5" />,
    category: "achievement",
    unlocked: true,
    color: "bg-indigo-500",
  },
  {
    id: "market_veteran",
    name: "Market Veteran",
    description: "Active trader for over 1 year",
    icon: <Trophy className="h-5 w-5" />,
    category: "achievement",
    unlocked: true,
    level: 1,
    maxLevel: 5,
    color: "bg-orange-500",
  },
]

export function TraderBadges() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Trader Badges</h2>
        <p className="text-muted-foreground">Showcase your achievements and build credibility</p>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Badges</TabsTrigger>
          <TabsTrigger value="verification">Verification</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
          <TabsTrigger value="achievement">Achievement</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {badges.map((badge) => (
              <BadgeCard key={badge.id} badge={badge} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="verification" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {badges
              .filter((badge) => badge.category === "verification")
              .map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="performance" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {badges
              .filter((badge) => badge.category === "performance")
              .map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="activity" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {badges
              .filter((badge) => badge.category === "activity")
              .map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="achievement" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {badges
              .filter((badge) => badge.category === "achievement")
              .map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function BadgeCard({ badge }: { badge: BadgeType }) {
  return (
    <Card className={`overflow-hidden ${!badge.unlocked ? "opacity-75" : ""}`}>
      <div className={`h-2 w-full ${badge.color || "bg-primary"}`} />
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className={`p-2 rounded-full ${badge.color || "bg-primary"} bg-opacity-10`}>{badge.icon}</div>
            <div>
              <CardTitle className="text-lg flex items-center">
                {badge.name}
                {badge.level && badge.maxLevel && (
                  <span className="ml-2 text-sm font-normal text-muted-foreground">
                    Level {badge.level}/{badge.maxLevel}
                  </span>
                )}
              </CardTitle>
              <CardDescription>{badge.description}</CardDescription>
            </div>
          </div>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-6 w-6">
                  <HelpCircle className="h-4 w-4 text-muted-foreground" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p className="max-w-xs">
                  {badge.unlocked
                    ? `You've earned this badge${badge.level ? ` (Level ${badge.level}/${badge.maxLevel})` : ""}!`
                    : `Complete the requirements to unlock this badge.`}
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </CardHeader>
      <CardContent>
        {!badge.unlocked && badge.progress !== undefined && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center">
                <Clock className="mr-1 h-3 w-3" />
                In progress
              </span>
              <span>{badge.progress}%</span>
            </div>
            <Progress value={badge.progress} className="h-2" />
          </div>
        )}

        {!badge.unlocked && badge.progress === undefined && (
          <div className="flex items-center text-sm text-muted-foreground">
            <Lock className="mr-2 h-4 w-4" />
            Complete requirements to unlock
          </div>
        )}

        {badge.unlocked && badge.level && badge.maxLevel && badge.level < badge.maxLevel && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Progress to next level</span>
              <span>{Math.round((badge.level / badge.maxLevel) * 100)}%</span>
            </div>
            <Progress value={(badge.level / badge.maxLevel) * 100} className="h-2" />
          </div>
        )}

        {badge.unlocked && (!badge.level || badge.level === badge.maxLevel) && (
          <div className="flex items-center text-sm text-green-600">
            <CheckCircle2 className="mr-2 h-4 w-4" />
            Unlocked
          </div>
        )}
      </CardContent>
    </Card>
  )
}

