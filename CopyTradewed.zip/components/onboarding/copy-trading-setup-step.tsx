"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { useCopyTrading } from "@/lib/copy-trading"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface CopyTradingSetupStepProps {
  onboardingData: any
  updateOnboardingData: (data: any) => void
}

export function CopyTradingSetupStep({ onboardingData, updateOnboardingData }: CopyTradingSetupStepProps) {
  const { updateSettings, toggleCopyTrading } = useCopyTrading()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)

  const [settings, setSettings] = useState({
    copyTradingEnabled: true,
    copyMode: "automatic",
    copyRatio: 1.0,
    maxRiskPerTrade:
      onboardingData.riskProfile === "conservative" ? 2 : onboardingData.riskProfile === "moderate" ? 5 : 10,
    stopLossEnabled: true,
    stopLossPercentage:
      onboardingData.riskProfile === "conservative" ? 5 : onboardingData.riskProfile === "moderate" ? 10 : 15,
    takeProfitEnabled: true,
    takeProfitPercentage:
      onboardingData.riskProfile === "conservative" ? 10 : onboardingData.riskProfile === "moderate" ? 20 : 30,
  })

  const handleToggle = (setting: string) => {
    setSettings((prev) => ({ ...prev, [setting]: !prev[setting] }))
  }

  const handleChange = (setting: string, value: any) => {
    setSettings((prev) => ({ ...prev, [setting]: value }))
  }

  const handleSaveSettings = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      try {
        // Update copy trading settings
        updateSettings({
          maxDailyLoss: settings.maxRiskPerTrade * 2, // Set daily loss limit to 2x max risk per trade
          maxPositionSize: settings.maxRiskPerTrade,
          stopLossEnabled: settings.stopLossEnabled,
          stopLossPercentage: settings.stopLossPercentage,
          takeProfitEnabled: settings.takeProfitEnabled,
          takeProfitPercentage: settings.takeProfitPercentage,
        })

        // Enable/disable copy trading
        toggleCopyTrading(settings.copyTradingEnabled)

        // Update onboarding data
        updateOnboardingData({ copyTradingEnabled: settings.copyTradingEnabled })

        toast({
          title: "Settings saved",
          description: "Your copy trading settings have been saved successfully.",
        })
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to save settings. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold">Copy Trading Setup</h2>
        <p className="text-muted-foreground">Configure your copy trading settings and risk management parameters</p>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Recommended Settings</AlertTitle>
        <AlertDescription>
          We've pre-configured these settings based on your risk profile ({onboardingData.riskProfile}). You can adjust
          them to your preference.
        </AlertDescription>
      </Alert>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="copy-trading">Enable Copy Trading</Label>
            <p className="text-sm text-muted-foreground">
              When enabled, trades from traders you follow will be automatically copied
            </p>
          </div>
          <Switch
            id="copy-trading"
            checked={settings.copyTradingEnabled}
            onCheckedChange={() => handleToggle("copyTradingEnabled")}
          />
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label>Copy Ratio: {settings.copyRatio}x</Label>
            <span className="text-sm text-muted-foreground">Multiplier for position sizes</span>
          </div>
          <Slider
            value={[settings.copyRatio]}
            min={0.1}
            max={2}
            step={0.1}
            onValueChange={(values) => handleChange("copyRatio", values[0])}
            disabled={!settings.copyTradingEnabled}
          />
          <p className="text-xs text-muted-foreground">
            A value of 1.0 means you'll copy the exact position size (adjusted for your capital). Lower values reduce
            risk, higher values increase it.
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between">
            <Label>Max Risk Per Trade: {settings.maxRiskPerTrade}%</Label>
            <span className="text-sm text-muted-foreground">Maximum capital at risk per trade</span>
          </div>
          <Slider
            value={[settings.maxRiskPerTrade]}
            min={1}
            max={20}
            step={1}
            onValueChange={(values) => handleChange("maxRiskPerTrade", values[0])}
            disabled={!settings.copyTradingEnabled}
          />
          <p className="text-xs text-muted-foreground">
            Limits the maximum percentage of your capital that can be risked on a single trade.
          </p>
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="stop-loss">Automatic Stop Loss</Label>
            <p className="text-sm text-muted-foreground">Automatically set stop losses for all copied trades</p>
          </div>
          <Switch
            id="stop-loss"
            checked={settings.stopLossEnabled}
            onCheckedChange={() => handleToggle("stopLossEnabled")}
            disabled={!settings.copyTradingEnabled}
          />
        </div>

        {settings.stopLossEnabled && (
          <div className="space-y-3">
            <div className="flex justify-between">
              <Label>Stop Loss Percentage: {settings.stopLossPercentage}%</Label>
            </div>
            <Slider
              id="stop-loss-percentage"
              min={1}
              max={20}
              step={1}
              value={[settings.stopLossPercentage]}
              onValueChange={(values) => handleChange("stopLossPercentage", values[0])}
              disabled={!settings.copyTradingEnabled}
            />
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="take-profit">Automatic Take Profit</Label>
            <p className="text-sm text-muted-foreground">Automatically set take profits for all copied trades</p>
          </div>
          <Switch
            id="take-profit"
            checked={settings.takeProfitEnabled}
            onCheckedChange={() => handleToggle("takeProfitEnabled")}
            disabled={!settings.copyTradingEnabled}
          />
        </div>

        {settings.takeProfitEnabled && (
          <div className="space-y-3">
            <div className="flex justify-between">
              <Label>Take Profit Percentage: {settings.takeProfitPercentage}%</Label>
            </div>
            <Slider
              id="take-profit-percentage"
              min={5}
              max={50}
              step={5}
              value={[settings.takeProfitPercentage]}
              onValueChange={(values) => handleChange("takeProfitPercentage", values[0])}
              disabled={!settings.copyTradingEnabled}
            />
          </div>
        )}
      </div>

      <Button onClick={handleSaveSettings} disabled={isLoading} className="mt-4">
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Saving...
          </>
        ) : (
          "Save Settings"
        )}
      </Button>
    </div>
  )
}

