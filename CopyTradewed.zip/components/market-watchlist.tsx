"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, TrendingDown, Bell, Trash2, Plus } from "lucide-react"
import { useMarket } from "@/lib/market"
import { useToast } from "@/components/ui/use-toast"

export function MarketWatchlist() {
  const { watchlist, removeFromWatchlist, setAlert } = useMarket()
  const { toast } = useToast()

  const [selectedAsset, setSelectedAsset] = useState<any>(null)
  const [alertDialogOpen, setAlertDialogOpen] = useState(false)
  const [alertSettings, setAlertSettings] = useState({
    priceAbove: "",
    priceBelow: "",
    percentChange: "",
    notificationMethod: "email",
  })
  const [isProcessing, setIsProcessing] = useState(false)

  const handleSetAlert = (asset: any) => {
    setSelectedAsset(asset)
    setAlertSettings({
      priceAbove: "",
      priceBelow: "",
      percentChange: "",
      notificationMethod: "email",
    })
    setAlertDialogOpen(true)
  }

  const handleRemoveFromWatchlist = (symbol: string) => {
    removeFromWatchlist(symbol)
    toast({
      title: "Removed from watchlist",
      description: `${symbol} has been removed from your watchlist.`,
    })
  }

  const handleSaveAlert = () => {
    if (!selectedAsset) return

    if (!alertSettings.priceAbove && !alertSettings.priceBelow && !alertSettings.percentChange) {
      toast({
        title: "Alert settings required",
        description: "Please set at least one alert condition.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    // Simulate API call
    setTimeout(() => {
      try {
        // Count how many alerts are set
        let alertCount = 0
        if (alertSettings.priceAbove) alertCount++
        if (alertSettings.priceBelow) alertCount++
        if (alertSettings.percentChange) alertCount++

        setAlert(selectedAsset.symbol, alertCount)

        toast({
          title: "Alert saved",
          description: `Price alert for ${selectedAsset.symbol} has been set successfully.`,
        })

        setAlertDialogOpen(false)
      } catch (error) {
        toast({
          title: "Failed to save alert",
          description: "An error occurred while saving your alert. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsProcessing(false)
      }
    }, 1000)
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <Button variant="outline" size="sm" className="gap-1">
          <Plus className="h-4 w-4" />
          Add Asset
        </Button>
        <p className="text-sm text-muted-foreground">{watchlist.length} assets in watchlist</p>
      </div>

      <div className="overflow-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Symbol</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Change</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Alerts</TableHead>
              <TableHead className="text-right">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {watchlist.map((asset) => (
              <TableRow key={asset.symbol}>
                <TableCell className="font-medium">{asset.symbol}</TableCell>
                <TableCell>{asset.name}</TableCell>
                <TableCell>
                  {asset.type === "forex"
                    ? asset.price.toFixed(4)
                    : asset.type === "crypto" && asset.price < 1
                      ? `$${asset.price.toFixed(4)}`
                      : `$${asset.price.toLocaleString()}`}
                </TableCell>
                <TableCell>
                  <div className={`flex items-center gap-1 ${asset.change >= 0 ? "text-green-600" : "text-red-600"}`}>
                    {asset.change >= 0 ? (
                      <>
                        +{asset.type === "forex" ? asset.change.toFixed(4) : asset.change.toLocaleString()} (
                        {asset.changePercent.toFixed(2)}%)
                        <TrendingUp className="h-4 w-4" />
                      </>
                    ) : (
                      <>
                        {asset.type === "forex" ? asset.change.toFixed(4) : asset.change.toLocaleString()} (
                        {asset.changePercent.toFixed(2)}%)
                        <TrendingDown className="h-4 w-4" />
                      </>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{asset.type.charAt(0).toUpperCase() + asset.type.slice(1)}</Badge>
                </TableCell>
                <TableCell>
                  {asset.alerts > 0 ? (
                    <Badge>{asset.alerts}</Badge>
                  ) : (
                    <span className="text-muted-foreground">None</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-2">
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleSetAlert(asset)}>
                      <Bell className="h-4 w-4" />
                      <span className="sr-only">Set alert</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive"
                      onClick={() => handleRemoveFromWatchlist(asset.symbol)}
                    >
                      <Trash2 className="h-4 w-4" />
                      <span className="sr-only">Remove from watchlist</span>
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={alertDialogOpen} onOpenChange={setAlertDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Set Price Alert for {selectedAsset?.symbol}</DialogTitle>
            <DialogDescription>
              Current price:{" "}
              {selectedAsset?.type === "forex"
                ? selectedAsset?.price?.toFixed(4)
                : selectedAsset?.type === "crypto" && selectedAsset?.price < 1
                  ? `$${selectedAsset?.price?.toFixed(4)}`
                  : `$${selectedAsset?.price?.toLocaleString()}`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="price-above">Alert when price above</Label>
              <Input
                id="price-above"
                placeholder="Enter price"
                value={alertSettings.priceAbove}
                onChange={(e) => setAlertSettings({ ...alertSettings, priceAbove: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="price-below">Alert when price below</Label>
              <Input
                id="price-below"
                placeholder="Enter price"
                value={alertSettings.priceBelow}
                onChange={(e) => setAlertSettings({ ...alertSettings, priceBelow: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="percent-change">Alert on percent change</Label>
              <Input
                id="percent-change"
                placeholder="Enter percentage"
                value={alertSettings.percentChange}
                onChange={(e) => setAlertSettings({ ...alertSettings, percentChange: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Notification method</Label>
              <div className="flex gap-2">
                <Button
                  variant={alertSettings.notificationMethod === "email" ? "default" : "outline"}
                  className="w-full"
                  onClick={() => setAlertSettings({ ...alertSettings, notificationMethod: "email" })}
                >
                  Email
                </Button>
                <Button
                  variant={alertSettings.notificationMethod === "push" ? "default" : "outline"}
                  className="w-full"
                  onClick={() => setAlertSettings({ ...alertSettings, notificationMethod: "push" })}
                >
                  Push
                </Button>
                <Button
                  variant={alertSettings.notificationMethod === "sms" ? "default" : "outline"}
                  className="w-full"
                  onClick={() => setAlertSettings({ ...alertSettings, notificationMethod: "sms" })}
                >
                  SMS
                </Button>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setAlertDialogOpen(false)} disabled={isProcessing}>
              Cancel
            </Button>
            <Button onClick={handleSaveAlert} disabled={isProcessing}>
              {isProcessing ? "Saving..." : "Save Alert"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

