"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { CheckCircle, ChevronDown, ChevronRight, Clock, PlayCircle, RefreshCw, XCircle } from "lucide-react"
import { useCopyTrading } from "@/lib/copy-trading"
import { useBrokerIntegration } from "@/lib/broker-integration"
import { useTraders } from "@/lib/traders"
import { useNotifications } from "@/lib/notifications"
import { usePortfolio } from "@/lib/portfolio"
import { sendEmail } from "@/lib/email-service"

export function IntegrationTestSuite() {
  const { toast } = useToast()
  const [isRunning, setIsRunning] = useState(false)
  const [expandedTests, setExpandedTests] = useState<string[]>([])
  const [testResults, setTestResults] = useState<
    Record<string, { status: "pending" | "success" | "error"; message?: string }>
  >({
    "copy-trading": { status: "pending" },
    "broker-integration": { status: "pending" },
    "trader-discovery": { status: "pending" },
    notifications: { status: "pending" },
    portfolio: { status: "pending" },
    email: { status: "pending" },
    "risk-management": { status: "pending" },
  })

  // Access all the necessary hooks
  const copyTrading = useCopyTrading()
  const brokerIntegration = useBrokerIntegration()
  const traders = useTraders()
  const notifications = useNotifications()
  const portfolio = usePortfolio()

  const toggleExpand = (testId: string) => {
    if (expandedTests.includes(testId)) {
      setExpandedTests(expandedTests.filter((id) => id !== testId))
    } else {
      setExpandedTests([...expandedTests, testId])
    }
  }

  const runAllTests = async () => {
    try {
      setIsRunning(true)
      setTestResults(
        Object.keys(testResults).reduce(
          (acc, key) => {
            acc[key] = { status: "pending" }
            return acc
          },
          {} as Record<string, { status: "pending" | "success" | "error"; message?: string }>,
        ),
      )

      // Run tests sequentially
      await testCopyTrading()
      await testBrokerIntegration()
      await testTraderDiscovery()
      await testNotifications()
      await testPortfolio()
      await testEmail()
      await testRiskManagement()

      toast({
        title: "Integration tests completed",
        description: "All tests have been executed. Check results for details.",
      })
    } catch (error) {
      toast({
        title: "Test execution error",
        description: "There was a problem running the integration tests.",
        variant: "destructive",
      })
    } finally {
      setIsRunning(false)
    }
  }

  const testCopyTrading = async () => {
    try {
      // Test copy trading functionality
      setTestResults((prev) => ({
        ...prev,
        "copy-trading": { status: "pending" },
      }))

      // Check if copy trading is initialized
      if (!copyTrading) {
        throw new Error("Copy trading hook not initialized")
      }

      // Test adding a copied trade
      const testTrade = {
        originalTradeId: "test-trade-id",
        symbol: "TEST",
        name: "Test Stock",
        type: "BUY" as const,
        price: 100,
        quantity: 1,
        total: 100,
        date: new Date().toISOString(),
        traderId: "test-trader-id",
        traderName: "Test Trader",
      }

      copyTrading.addCopiedTrade(testTrade)

      // Verify the trade was added
      const trades = copyTrading.copiedTrades
      const tradeAdded = trades.some((trade) => trade.originalTradeId === testTrade.originalTradeId)

      if (!tradeAdded) {
        throw new Error("Failed to add copied trade")
      }

      setTestResults((prev) => ({
        ...prev,
        "copy-trading": {
          status: "success",
          message: "Copy trading functionality is working correctly",
        },
      }))
    } catch (error) {
      setTestResults((prev) => ({
        ...prev,
        "copy-trading": {
          status: "error",
          message: error instanceof Error ? error.message : "Unknown error in copy trading test",
        },
      }))
    }
  }

  const testBrokerIntegration = async () => {
    try {
      // Test broker integration functionality
      setTestResults((prev) => ({
        ...prev,
        "broker-integration": { status: "pending" },
      }))

      // Check if broker integration is initialized
      if (!brokerIntegration) {
        throw new Error("Broker integration hook not initialized")
      }

      // Get broker accounts
      const accounts = await brokerIntegration.getBrokerAccounts()

      // Test a mock trade (this should not actually execute a real trade)
      const result = await brokerIntegration.copyTrade(
        {
          symbol: "TEST",
          side: "buy",
          quantity: 1,
          type: "market",
          price: 100,
          traderId: "test-trader-id",
          traderName: "Test Trader",
        },
        {
          applyRiskManagement: true,
          maxPositionSize: 5,
          sizeMultiplier: 1,
          useStopLoss: true,
          useTakeProfit: true,
        },
      )

      if (!result.success) {
        throw new Error("Failed to execute mock trade")
      }

      setTestResults((prev) => ({
        ...prev,
        "broker-integration": {
          status: "success",
          message: `Broker integration is working correctly. Found ${accounts.length} connected accounts.`,
        },
      }))
    } catch (error) {
      setTestResults((prev) => ({
        ...prev,
        "broker-integration": {
          status: "error",
          message: error instanceof Error ? error.message : "Unknown error in broker integration test",
        },
      }))
    }
  }

  const testTraderDiscovery = async () => {
    try {
      // Test trader discovery functionality
      setTestResults((prev) => ({
        ...prev,
        "trader-discovery": { status: "pending" },
      }))

      // Check if traders hook is initialized
      if (!traders) {
        throw new Error("Traders hook not initialized")
      }

      // Get traders
      const tradersList = traders.traders

      if (!Array.isArray(tradersList)) {
        throw new Error("Traders list is not an array")
      }

      setTestResults((prev) => ({
        ...prev,
        "trader-discovery": {
          status: "success",
          message: `Trader discovery is working correctly. Found ${tradersList.length} traders.`,
        },
      }))
    } catch (error) {
      setTestResults((prev) => ({
        ...prev,
        "trader-discovery": {
          status: "error",
          message: error instanceof Error ? error.message : "Unknown error in trader discovery test",
        },
      }))
    }
  }

  const testNotifications = async () => {
    try {
      // Test notifications functionality
      setTestResults((prev) => ({
        ...prev,
        notifications: { status: "pending" },
      }))

      // Check if notifications hook is initialized
      if (!notifications) {
        throw new Error("Notifications hook not initialized")
      }

      // Add a test notification
      const testNotification = {
        id: `test-${Date.now()}`,
        title: "Test Notification",
        message: "This is a test notification",
        type: "info" as const,
        read: false,
        date: new Date().toISOString(),
      }

      notifications.addNotification(testNotification)

      // Verify the notification was added
      const notificationsList = notifications.notifications
      const notificationAdded = notificationsList.some((notification) => notification.id === testNotification.id)

      if (!notificationAdded) {
        throw new Error("Failed to add notification")
      }

      setTestResults((prev) => ({
        ...prev,
        notifications: {
          status: "success",
          message: "Notifications system is working correctly",
        },
      }))
    } catch (error) {
      setTestResults((prev) => ({
        ...prev,
        notifications: {
          status: "error",
          message: error instanceof Error ? error.message : "Unknown error in notifications test",
        },
      }))
    }
  }

  const testPortfolio = async () => {
    try {
      // Test portfolio functionality
      setTestResults((prev) => ({
        ...prev,
        portfolio: { status: "pending" },
      }))

      // Check if portfolio hook is initialized
      if (!portfolio) {
        throw new Error("Portfolio hook not initialized")
      }

      // Add a test trade
      const testTrade = {
        id: `test-${Date.now()}`,
        symbol: "TEST",
        type: "buy" as const,
        price: 100,
        quantity: 1,
        total: 100,
        date: new Date().toISOString(),
      }

      portfolio.addTrade(testTrade)

      // Verify the trade was added
      const trades = portfolio.trades
      const tradeAdded = trades.some((trade) => trade.id === testTrade.id)

      if (!tradeAdded) {
        throw new Error("Failed to add trade to portfolio")
      }

      setTestResults((prev) => ({
        ...prev,
        portfolio: {
          status: "success",
          message: "Portfolio system is working correctly",
        },
      }))
    } catch (error) {
      setTestResults((prev) => ({
        ...prev,
        portfolio: {
          status: "error",
          message: error instanceof Error ? error.message : "Unknown error in portfolio test",
        },
      }))
    }
  }

  const testEmail = async () => {
    try {
      // Test email functionality
      setTestResults((prev) => ({
        ...prev,
        email: { status: "pending" },
      }))

      // Send a test email (this will be logged to console in development)
      const result = await sendEmail({
        to: "test@example.com",
        subject: "Test Email",
        html: "<p>This is a test email</p>",
      })

      if (!result.success) {
        throw new Error(result.error || "Failed to send test email")
      }

      setTestResults((prev) => ({
        ...prev,
        email: {
          status: "success",
          message: "Email system is working correctly",
        },
      }))
    } catch (error) {
      setTestResults((prev) => ({
        ...prev,
        email: {
          status: "error",
          message: error instanceof Error ? error.message : "Unknown error in email test",
        },
      }))
    }
  }

  const testRiskManagement = async () => {
    try {
      // Test risk management functionality
      setTestResults((prev) => ({
        ...prev,
        "risk-management": { status: "pending" },
      }))

      // Check if copy trading hook is initialized (for risk settings)
      if (!copyTrading) {
        throw new Error("Copy trading hook not initialized")
      }

      // Verify risk management settings are accessible
      const maxPositionSize = copyTrading.maxPositionSize
      const stopLossEnabled = copyTrading.stopLossEnabled
      const takeProfitEnabled = copyTrading.takeProfitEnabled

      if (maxPositionSize === undefined || stopLossEnabled === undefined || takeProfitEnabled === undefined) {
        throw new Error("Risk management settings not accessible")
      }

      setTestResults((prev) => ({
        ...prev,
        "risk-management": {
          status: "success",
          message: "Risk management system is working correctly",
        },
      }))
    } catch (error) {
      setTestResults((prev) => ({
        ...prev,
        "risk-management": {
          status: "error",
          message: error instanceof Error ? error.message : "Unknown error in risk management test",
        },
      }))
    }
  }

  const getStatusBadge = (status: "pending" | "success" | "error") => {
    switch (status) {
      case "success":
        return (
          <Badge className="bg-green-500">
            <CheckCircle className="mr-1 h-3 w-3" />
            Success
          </Badge>
        )
      case "error":
        return (
          <Badge variant="destructive">
            <XCircle className="mr-1 h-3 w-3" />
            Failed
          </Badge>
        )
      case "pending":
      default:
        return (
          <Badge variant="outline">
            <Clock className="mr-1 h-3 w-3" />
            Pending
          </Badge>
        )
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Integration Test Suite</CardTitle>
        <CardDescription>Verify all platform components are working correctly</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-end">
          <Button onClick={runAllTests} disabled={isRunning}>
            {isRunning ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Running Tests...
              </>
            ) : (
              <>
                <PlayCircle className="mr-2 h-4 w-4" />
                Run All Tests
              </>
            )}
          </Button>
        </div>

        <Separator />

        <div className="space-y-2">
          {Object.entries(testResults).map(([testId, result]) => (
            <div key={testId} className="border rounded-md">
              <div
                className="flex items-center justify-between p-3 cursor-pointer"
                onClick={() => toggleExpand(testId)}
              >
                <div className="flex items-center">
                  {expandedTests.includes(testId) ? (
                    <ChevronDown className="h-4 w-4 mr-2" />
                  ) : (
                    <ChevronRight className="h-4 w-4 mr-2" />
                  )}
                  <span className="font-medium capitalize">{testId.replace(/-/g, " ")}</span>
                </div>
                {getStatusBadge(result.status)}
              </div>

              {expandedTests.includes(testId) && result.message && (
                <div className="p-3 pt-0 text-sm text-muted-foreground">{result.message}</div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
      <CardFooter className="text-sm text-muted-foreground">
        Run these tests after making changes to verify platform integrity
      </CardFooter>
    </Card>
  )
}

