"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { AlertTriangle, CheckCircle, ExternalLink, FileText, Info, Shield } from "lucide-react"

export function RegulatoryDisclosures() {
  const [hasAcknowledged, setHasAcknowledged] = useState(false)

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold">Regulatory Information</h2>
        <p className="text-muted-foreground mt-2">Important disclosures and compliance information</p>
      </div>

      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Risk Warning</AlertTitle>
        <AlertDescription>
          Copy trading involves substantial risk of loss and is not suitable for all investors. Past performance is not
          indicative of future results.
        </AlertDescription>
      </Alert>

      <Tabs defaultValue="disclosures">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="disclosures">Disclosures</TabsTrigger>
          <TabsTrigger value="terms">Terms of Service</TabsTrigger>
          <TabsTrigger value="privacy">Privacy Policy</TabsTrigger>
          <TabsTrigger value="licenses">Licenses</TabsTrigger>
        </TabsList>

        <TabsContent value="disclosures" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Risk Disclosures</CardTitle>
              <CardDescription>Important information about the risks of copy trading</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>Risk of Loss</AccordionTrigger>
                  <AccordionContent>
                    <p className="text-sm text-muted-foreground">
                      Copy trading involves substantial risk of loss. You should only invest money that you can afford
                      to lose. The performance of the traders you follow is not guaranteed, and past performance is not
                      indicative of future results.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger>Leverage Risk</AccordionTrigger>
                  <AccordionContent>
                    <p className="text-sm text-muted-foreground">
                      Some traders may use leverage in their trading strategies. Leverage can significantly increase the
                      potential for both profits and losses. You should understand the implications of leverage before
                      following traders who use it.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger>Market Risk</AccordionTrigger>
                  <AccordionContent>
                    <p className="text-sm text-muted-foreground">
                      Financial markets can be volatile and prices can fluctuate rapidly. These market movements can
                      affect the performance of the traders you follow and, consequently, your investments.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger>Technical Risk</AccordionTrigger>
                  <AccordionContent>
                    <p className="text-sm text-muted-foreground">
                      Copy trading relies on technology to execute trades. Technical issues, delays, or failures in the
                      platform, internet connection, or broker systems may affect the execution of trades and could
                      result in losses.
                    </p>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger>Trader Risk</AccordionTrigger>
                  <AccordionContent>
                    <p className="text-sm text-muted-foreground">
                      The traders you follow may change their trading strategies, take excessive risks, or experience
                      periods of poor performance. There is no guarantee that a trader's past success will continue in
                      the future.
                    </p>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="terms" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Terms of Service</CardTitle>
              <CardDescription>Our platform's terms and conditions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none">
                <h3>1. Acceptance of Terms</h3>
                <p>By accessing or using our copy trading platform, you agree to be bound by these Terms of Service.</p>

                <h3>2. Eligibility</h3>
                <p>You must be at least 18 years old and legally able to enter into contracts to use our services.</p>

                <h3>3. Account Registration</h3>
                <p>
                  You are responsible for maintaining the confidentiality of your account credentials and for all
                  activities that occur under your account.
                </p>

                <h3>4. Copy Trading Services</h3>
                <p>
                  Our platform allows you to automatically copy the trades of other traders. You acknowledge the risks
                  involved in copy trading and agree that we are not responsible for any losses you may incur.
                </p>

                <h3>5. Fees and Payments</h3>
                <p>You agree to pay all applicable fees for using our services as described on our platform.</p>

                <h3>6. Termination</h3>
                <p>
                  We reserve the right to suspend or terminate your account at our discretion, with or without notice.
                </p>

                <h3>7. Limitation of Liability</h3>
                <p>
                  To the maximum extent permitted by law, we shall not be liable for any indirect, incidental, special,
                  consequential, or punitive damages.
                </p>

                <h3>8. Governing Law</h3>
                <p>These Terms shall be governed by and construed in accordance with the laws of [Jurisdiction].</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => window.open("/terms-of-service", "_blank")}>
                <FileText className="mr-2 h-4 w-4" />
                View Full Terms of Service
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Privacy Policy</CardTitle>
              <CardDescription>How we collect, use, and protect your data</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm max-w-none">
                <h3>1. Information We Collect</h3>
                <p>
                  We collect personal information that you provide to us, such as your name, email address, and
                  financial information necessary for copy trading.
                </p>

                <h3>2. How We Use Your Information</h3>
                <p>
                  We use your information to provide and improve our services, process transactions, communicate with
                  you, and comply with legal obligations.
                </p>

                <h3>3. Information Sharing</h3>
                <p>
                  We may share your information with third-party service providers, such as brokers, to facilitate copy
                  trading. We do not sell your personal information.
                </p>

                <h3>4. Data Security</h3>
                <p>
                  We implement appropriate security measures to protect your personal information from unauthorized
                  access, alteration, or disclosure.
                </p>

                <h3>5. Your Rights</h3>
                <p>
                  You have the right to access, correct, or delete your personal information. You may also have
                  additional rights depending on your jurisdiction.
                </p>

                <h3>6. Cookies</h3>
                <p>We use cookies and similar technologies to enhance your experience on our platform.</p>

                <h3>7. Changes to This Policy</h3>
                <p>
                  We may update this Privacy Policy from time to time. We will notify you of any significant changes.
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" onClick={() => window.open("/privacy-policy", "_blank")}>
                <FileText className="mr-2 h-4 w-4" />
                View Full Privacy Policy
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="licenses" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Regulatory Licenses</CardTitle>
              <CardDescription>Our platform's regulatory authorizations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <Shield className="h-10 w-10 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-medium">Financial Conduct Authority (FCA)</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Authorized and regulated by the Financial Conduct Authority in the United Kingdom.
                    </p>
                    <p className="text-sm">
                      <strong>License Number:</strong> FRN 123456
                    </p>
                    <a
                      href="https://register.fca.org.uk/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary flex items-center mt-1"
                    >
                      Verify on FCA Register
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4">
                  <Shield className="h-10 w-10 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-medium">Cyprus Securities and Exchange Commission (CySEC)</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Authorized and regulated by the Cyprus Securities and Exchange Commission.
                    </p>
                    <p className="text-sm">
                      <strong>License Number:</strong> CIF 123/45
                    </p>
                    <a
                      href="https://www.cysec.gov.cy/en-GB/entities/investment-firms/cypriot/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary flex items-center mt-1"
                    >
                      Verify on CySEC Register
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </div>
                </div>

                <Separator />

                <div className="flex items-start gap-4">
                  <Shield className="h-10 w-10 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="text-lg font-medium">Australian Securities and Investments Commission (ASIC)</h3>
                    <p className="text-sm text-muted-foreground mb-2">
                      Authorized and regulated by the Australian Securities and Investments Commission.
                    </p>
                    <p className="text-sm">
                      <strong>License Number:</strong> AFSL 123456
                    </p>
                    <a
                      href="https://asic.gov.au/online-services/search-asic-s-registers/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary flex items-center mt-1"
                    >
                      Verify on ASIC Register
                      <ExternalLink className="ml-1 h-3 w-3" />
                    </a>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Acknowledgment of Risks</CardTitle>
          <CardDescription>Please review and acknowledge the following before using our platform</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="mb-4">
            <Info className="h-4 w-4" />
            <AlertTitle>Important Notice</AlertTitle>
            <AlertDescription>
              By using our copy trading platform, you acknowledge that you have read and understood the risks involved
              in copy trading.
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <p className="text-sm">I acknowledge and agree that:</p>

            <ul className="space-y-2 text-sm">
              <li className="flex items-start">
                <CheckCircle className="mr-2 h-4 w-4 text-green-500 mt-0.5" />
                <span>Copy trading involves substantial risk of loss and is not suitable for all investors.</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="mr-2 h-4 w-4 text-green-500 mt-0.5" />
                <span>Past performance is not indicative of future results.</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="mr-2 h-4 w-4 text-green-500 mt-0.5" />
                <span>I should only invest money that I can afford to lose.</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="mr-2 h-4 w-4 text-green-500 mt-0.5" />
                <span>I am responsible for monitoring my copy trading activities and managing my risk.</span>
              </li>
              <li className="flex items-start">
                <CheckCircle className="mr-2 h-4 w-4 text-green-500 mt-0.5" />
                <span>I have read and understood the Terms of Service and Privacy Policy.</span>
              </li>
            </ul>
          </div>
        </CardContent>
        <CardFooter>
          <Button className="w-full" onClick={() => setHasAcknowledged(true)} disabled={hasAcknowledged}>
            {hasAcknowledged ? (
              <>
                <CheckCircle className="mr-2 h-4 w-4" />
                Acknowledged
              </>
            ) : (
              "I Acknowledge and Accept"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

