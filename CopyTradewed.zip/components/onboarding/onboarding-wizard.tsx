"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { WelcomeStep } from "@/components/onboarding/welcome-step"
import { ProfileSetupStep } from "@/components/onboarding/profile-setup-step"
import { RiskAssessmentStep } from "@/components/onboarding/risk-assessment-step"
import { BrokerConnectionStep } from "@/components/onboarding/broker-connection-step"
import { TraderDiscoveryStep } from "@/components/onboarding/trader-discovery-step"
import { CopyTradingSetupStep } from "@/components/onboarding/copy-trading-setup-step"
import { CompletionStep } from "@/components/onboarding/completion-step"
import { ArrowLeft, ArrowRight, Check } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/lib/auth"

export function OnboardingWizard() {
  const router = useRouter()
  const { toast } = useToast()
  const { user, updateUser } = useAuth()

  const [currentStep, setCurrentStep] = useState(0)
  const [onboardingData, setOnboardingData] = useState({
    profileComplete: false,
    riskProfile: null,
    brokerConnected: false,
    followedTraders: [],
    copyTradingEnabled: false,
  })

  const totalSteps = 7
  const progress = ((currentStep + 1) / totalSteps) * 100

  const steps = [
    { id: "welcome", title: "Welcome", component: WelcomeStep },
    { id: "profile", title: "Profile Setup", component: ProfileSetupStep },
    { id: "risk", title: "Risk Assessment", component: RiskAssessmentStep },
    { id: "broker", title: "Connect Broker", component: BrokerConnectionStep },
    { id: "traders", title: "Discover Traders", component: TraderDiscoveryStep },
    { id: "setup", title: "Copy Trading Setup", component: CopyTradingSetupStep },
    { id: "complete", title: "Completion", component: CompletionStep },
  ]

  const CurrentStepComponent = steps[currentStep].component

  const handleNext = () => {
    if (currentStep < totalSteps - 1) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSkip = () => {
    // Mark user as onboarded even if they skip
    if (user) {
      updateUser({ onboardingComplete: true })
    }

    toast({
      title: "Onboarding skipped",
      description: "You can complete your setup later from your profile settings.",
    })

    router.push("/dashboard")
  }

  const handleComplete = () => {
    // Mark user as onboarded
    if (user) {
      updateUser({ onboardingComplete: true })
    }

    toast({
      title: "Onboarding complete!",
      description: "Your copy trading account is now set up and ready to use.",
    })

    router.push("/dashboard")
  }

  const updateOnboardingData = (data: Partial<typeof onboardingData>) => {
    setOnboardingData({ ...onboardingData, ...data })
  }

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-2xl font-bold mb-2">Getting Started with AlgoForex</h1>
        <p className="text-muted-foreground">Complete these steps to set up your copy trading account</p>

        <div className="mt-4">
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between mt-2 text-sm text-muted-foreground">
            <span>
              Step {currentStep + 1} of {totalSteps}
            </span>
            <span>{steps[currentStep].title}</span>
          </div>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <CurrentStepComponent onboardingData={onboardingData} updateOnboardingData={updateOnboardingData} />

          <div className="flex justify-between mt-8">
            <div>
              {currentStep > 0 && (
                <Button variant="outline" onClick={handlePrevious}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Previous
                </Button>
              )}
            </div>

            <div className="flex gap-2">
              {currentStep < totalSteps - 1 && (
                <Button variant="outline" onClick={handleSkip}>
                  Skip for now
                </Button>
              )}

              {currentStep < totalSteps - 1 ? (
                <Button onClick={handleNext}>
                  Next
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button onClick={handleComplete}>
                  Complete Setup
                  <Check className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

