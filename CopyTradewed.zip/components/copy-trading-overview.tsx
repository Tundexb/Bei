"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { ArrowUpRight, TrendingUp, Settings, AlertCircle, Clock, BarChart3, DollarSign } from "lucide-react"
import { useRouter } from "next/navigation"
import { useCopyTrading, useCopyTradingStats, simulateTraderTrade } from "@/lib/copy-trading"
import { useTraders } from "@/lib/traders"
import { useToast } from "@/components/ui/use-toast"

export function CopyTradingOverview() {
  const router = useRouter()
  const { toast } = useToast()
  const { isEnabled, toggleCopyTrading } = useCopyTrading()
  const { traders } = useTraders()
  const { totalCopiedTrades, executedTrades, pendingTrades, failedTrades, successRate, totalVolume, recentActivities } =
    useCopyTradingStats()

  // Get followed traders
  const followedTraders = traders.filter((trader) => trader.following)

  const handleSimulateTrade = () => {
    const result = simulateTraderTrade()

    if (result) {
      toast({
        title: "Trade Simulated",
        description: `Simulated a ${result.trade.type} trade for ${result.trade.quantity} ${result.trade.symbol} from ${result.trader.name}.`,
      })
    } else {
      toast({
        title: "Simulation Failed",
        description: "You need to follow at least one trader to simulate a trade.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h2 className="text-2xl font-bold tracking-tight">Copy Trading Overview</h2>
          <p className="text-muted-foreground">Monitor your copy trading performance and followed traders</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant={isEnabled ? "destructive" : "default"} onClick={() => toggleCopyTrading(!isEnabled)}>
            {isEnabled ? "Pause Copy Trading" : "Enable Copy Trading"}
          </Button>
          <Button variant="outline" onClick={handleSimulateTrade}>
            Simulate Trade
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Copied Trades</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalCopiedTrades}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              <div className="flex items-center">
                <span className="text-green-600">{executedTrades} executed</span>
                <span className="mx-1">•</span>
                <span className="text-amber-600">{pendingTrades} pending</span>
                <span className="mx-1">•</span>
                <span className="text-red-600">{failedTrades} failed</span>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{successRate.toFixed(1)}%</div>
            <Progress value={successRate} className="mt-2" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Trading Volume</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalVolume.toLocaleString()}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              <ArrowUpRight className="mr-1 h-4 w-4 text-green-500" />
              <span className="text-green-500">+12.5%</span>
              <span className="ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Followed Traders</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{followedTraders.length}</div>
            <Button
              variant="link"
              className="p-0 h-auto text-xs text-muted-foreground"
              onClick={() => router.push("/dashboard/traders")}
            >
              Find more traders to follow
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Followed Traders</CardTitle>
            <CardDescription>Traders whose trades you are copying</CardDescription>
          </CardHeader>
          <CardContent>
            {followedTraders.length > 0 ? (
              <div className="space-y-4">
                {followedTraders.map((trader) => (
                  <div key={trader.id} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarImage src={trader.avatar} alt={trader.name} />
                        <AvatarFallback>{trader.initials}</AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium">{trader.name}</div>
                        <div className="text-xs text-muted-foreground">
                          {trader.trades} trades • {trader.winRate}% win rate
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-sm font-medium text-green-600">+{trader.roi}%</div>
                      <Button variant="ghost" size="sm" onClick={() => router.push(`/dashboard/traders/${trader.id}`)}>
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-6">
                <AlertCircle className="h-10 w-10 text-muted-foreground mb-2" />
                <p className="text-muted-foreground">You are not following any traders yet.</p>
                <Button variant="outline" className="mt-4" onClick={() => router.push("/dashboard/traders")}>
                  Find Traders to Follow
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest copy trading activities</CardDescription>
          </CardHeader>
          <CardContent>
            {recentActivities.length > 0 ? (
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3">
                    <div className="mt-0.5">
                      {activity.type === "trade_copied" && <TrendingUp className="h-5 w-5 text-blue-500" />}
                      {activity.type === "trade_executed" && <DollarSign className="h-5 w-5 text-green-500" />}
                      {activity.type === "trade_failed" && <AlertCircle className="h-5 w-5 text-red-500" />}
                      {activity.type === "settings_changed" && <Settings className="h-5 w-5 text-purple-500" />}
                      {activity.type === "copy_trading_enabled" && <TrendingUp className="h-5 w-5 text-green-500" />}
                      {activity.type === "copy_trading_disabled" && <TrendingUp className="h-5 w-5 text-red-500" />}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">{activity.description}</p>
                        <div className="flex items-center text-xs text-muted-foreground">
                          <Clock className="mr-1 h-3 w-3" />
                          {new Date(activity.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                      {activity.metadata?.symbol && (
                        <div className="mt-1 text-xs text-muted-foreground">
                          {activity.metadata.type} {activity.metadata.symbol}
                          {activity.metadata.price && ` @ $${activity.metadata.price}`}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-6">
                <Clock className="h-10 w-10 text-muted-foreground mb-2" />
                <p className="text-muted-foreground">No recent activities to display.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

