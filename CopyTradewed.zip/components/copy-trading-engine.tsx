"use client"

import { useEffect, useRef, useState } from "react"
import { useCopyTrading } from "@/lib/copy-trading"
import { useTraders } from "@/lib/traders"
import { useBrokerIntegration } from "@/lib/broker-integration"
import { usePortfolio } from "@/lib/portfolio"
import { useNotifications } from "@/lib/notifications"
import { useToast } from "@/components/ui/use-toast"
import { sendTradeNotificationEmail } from "@/lib/email-service"
import { useAuth } from "@/lib/auth"

export function CopyTradingEngine() {
  const {
    isEnabled,
    copiedTrades,
    traderAllocations,
    addCopiedTrade,
    maxDailyLoss,
    maxPositionSize,
    stopLossEnabled,
    stopLossPercentage,
    takeProfitEnabled,
    takeProfitPercentage,
    autoCloseEnabled,
    autoCloseThreshold,
    volatilityProtection,
    volatilityThreshold,
    correlationProtection,
    correlationThreshold,
  } = useCopyTrading()

  const { user } = useAuth()
  const { traders } = useTraders()
  const { copyTrade, getBrokerAccounts } = useBrokerIntegration()
  const { addTrade, positions } = usePortfolio()
  const { addNotification } = useNotifications()
  const { toast } = useToast()

  // Track daily P&L to enforce maxDailyLoss
  const dailyPnLRef = useRef(0)
  const lastResetDateRef = useRef(new Date().toDateString())
  const [isConnecting, setIsConnecting] = useState(false)
  const [connectionError, setConnectionError] = useState<string | null>(null)

  // Reset daily P&L at the start of each day
  useEffect(() => {
    const checkDate = () => {
      const currentDate = new Date().toDateString()
      if (currentDate !== lastResetDateRef.current) {
        dailyPnLRef.current = 0
        lastResetDateRef.current = currentDate
      }
    }

    const interval = setInterval(checkDate, 60000) // Check every minute
    return () => clearInterval(interval)
  }, [])

  // WebSocket connection for real-time trade signals
  useEffect(() => {
    if (!isEnabled) return

    // In a real implementation, this would be a WebSocket connection
    // to receive real-time trade signals from followed traders
    const connectToTradeStream = async () => {
      try {
        setIsConnecting(true)
        setConnectionError(null)

        // Get connected broker accounts
        const accounts = await getBrokerAccounts()

        if (accounts.length === 0) {
          setConnectionError("No broker accounts connected")
          toast({
            title: "No broker accounts connected",
            description: "Please connect a broker account to start copy trading",
            variant: "destructive",
          })
          return () => {}
        }

        // Mock WebSocket connection
        console.log("Connected to trade stream")
        setIsConnecting(false)

        // Simulate receiving trade signals
        const tradeSignalInterval = setInterval(() => {
          processTrade()
        }, 30000) // Simulate a trade every 30 seconds

        return () => {
          clearInterval(tradeSignalInterval)
          console.log("Disconnected from trade stream")
        }
      } catch (error) {
        console.error("Failed to connect to trade stream:", error)
        setConnectionError("Failed to connect to trade stream")
        setIsConnecting(false)

        toast({
          title: "Connection Error",
          description: "Failed to connect to trade stream. Please try again.",
          variant: "destructive",
        })

        return () => {}
      }
    }

    const cleanup = connectToTradeStream()
    return () => {
      if (cleanup) cleanup()
    }
  }, [isEnabled, getBrokerAccounts, toast])

  // Process incoming trade
  const processTrade = async () => {
    // Get followed traders
    const followedTraders = traders.filter((trader) => trader.following)

    if (followedTraders.length === 0) return

    try {
      // Simulate a trade signal from a random followed trader
      const randomTrader = followedTraders[Math.floor(Math.random() * followedTraders.length)]

      // Random trade details
      const symbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA"]
      const randomSymbol = symbols[Math.floor(Math.random() * symbols.length)]
      const isBuy = Math.random() > 0.3 // 70% chance of buy
      const price = Math.floor(Math.random() * 500) + 100 // Random price between 100 and 600
      const quantity = Math.floor(Math.random() * 5) + 1 // Random quantity between 1 and 5

      const trade = {
        symbol: randomSymbol,
        name: getCompanyName(randomSymbol),
        type: isBuy ? ("BUY" as const) : ("SELL" as const),
        price: price,
        quantity: quantity,
        total: price * quantity,
      }

      // Check if daily loss limit would be exceeded
      if (checkDailyLossLimit(trade)) {
        console.log("Daily loss limit would be exceeded, skipping trade")
        addNotification({
          id: `daily_limit_${Date.now()}`,
          title: "Daily Loss Limit",
          message: `Trade for ${trade.symbol} skipped due to daily loss limit`,
          type: "warning",
          read: false,
          date: new Date().toISOString(),
        })
        return
      }

      // Get trader allocation
      const traderAllocation = traderAllocations.find((allocation) => allocation.traderId === randomTrader.id)

      if (!traderAllocation) return

      // Apply position size limits
      const maxTradeAmount = (maxPositionSize / 100) * 10000 // Mock portfolio value of $10,000
      const adjustedQuantity = Math.min(trade.quantity, Math.floor(maxTradeAmount / trade.price))

      if (adjustedQuantity <= 0) {
        console.log("Trade size too small after adjustment, skipping")
        return
      }

      const adjustedTotal = adjustedQuantity * trade.price

      // Apply advanced risk management settings
      let riskAdjustedQuantity = adjustedQuantity
      let appliedRiskManagement = false

      // Apply volatility protection if enabled
      if (volatilityProtection) {
        // In a real app, you would check actual market volatility
        const mockVolatility = Math.random() * 50 // Random volatility between 0 and 50

        if (mockVolatility > volatilityThreshold) {
          // Reduce position size based on volatility
          const reductionFactor = 1 - (mockVolatility - volatilityThreshold) / 100
          riskAdjustedQuantity = Math.max(1, Math.floor(riskAdjustedQuantity * reductionFactor))
          appliedRiskManagement = true

          console.log(`Applied volatility protection: ${adjustedQuantity} -> ${riskAdjustedQuantity}`)
        }
      }

      // Apply correlation protection if enabled
      if (correlationProtection) {
        // In a real app, you would check actual asset correlation
        const mockCorrelation = Math.random() * 100 // Random correlation between 0 and 100

        if (mockCorrelation > correlationThreshold) {
          // Reduce position size based on correlation
          const reductionFactor = 1 - (mockCorrelation - correlationThreshold) / 200
          riskAdjustedQuantity = Math.max(1, Math.floor(riskAdjustedQuantity * reductionFactor))
          appliedRiskManagement = true

          console.log(`Applied correlation protection: ${adjustedQuantity} -> ${riskAdjustedQuantity}`)
        }
      }

      // Execute the copy trade through broker integration
      const result = await copyTrade(
        {
          symbol: trade.symbol,
          side: trade.type === "BUY" ? "buy" : "sell",
          quantity: riskAdjustedQuantity,
          type: "market",
          price: trade.price,
          traderId: randomTrader.id,
          traderName: randomTrader.name,
          stopLoss: stopLossEnabled ? trade.price * (1 - stopLossPercentage / 100) : undefined,
          takeProfit: takeProfitEnabled ? trade.price * (1 + takeProfitPercentage / 100) : undefined,
        },
        {
          applyRiskManagement: true,
          maxPositionSize: maxPositionSize,
          sizeMultiplier: traderAllocation.allocation / 100,
          useStopLoss: stopLossEnabled,
          useTakeProfit: takeProfitEnabled,
        },
      )

      if (result.success) {
        // Add to copied trades history
        const copiedTrade = {
          originalTradeId: Date.now().toString(),
          symbol: trade.symbol,
          name: trade.name,
          type: trade.type,
          price: trade.price,
          quantity: riskAdjustedQuantity,
          total: riskAdjustedQuantity * trade.price,
          date: new Date().toISOString(),
          traderId: randomTrader.id,
          traderName: randomTrader.name,
        }

        addCopiedTrade(copiedTrade)

        // Add notification
        addNotification({
          id: `trade_${Date.now()}`,
          title: "Trade Copied",
          message: `Successfully copied ${trade.type} trade for ${riskAdjustedQuantity} ${trade.symbol} from ${randomTrader.name}`,
          type: "success",
          read: false,
          date: new Date().toISOString(),
          link: "/dashboard/copy-trading",
        })

        // Update daily P&L for tracking
        if (trade.type === "SELL") {
          // For simplicity, assume a 2% loss on sells
          dailyPnLRef.current -= copiedTrade.total * 0.02
        }

        // Show toast notification
        toast({
          title: "Trade Copied",
          description: `Successfully copied ${trade.type} trade for ${riskAdjustedQuantity} ${trade.symbol}`,
        })

        // Send email notification if user has email
        if (user?.email) {
          sendTradeNotificationEmail(
            user.email,
            randomTrader.name,
            trade.symbol,
            trade.type === "BUY" ? "buy" : "sell",
            riskAdjustedQuantity,
            trade.price,
          )
        }

        // Log risk management if applied
        if (appliedRiskManagement) {
          addNotification({
            id: `risk_mgmt_${Date.now()}`,
            title: "Risk Management Applied",
            message: `Position size was adjusted from ${adjustedQuantity} to ${riskAdjustedQuantity} due to risk factors`,
            type: "info",
            read: false,
            date: new Date().toISOString(),
          })
        }
      } else {
        console.error("Failed to copy trade:", result)

        // Add notification for failed trade
        addNotification({
          id: `trade_failed_${Date.now()}`,
          title: "Trade Failed",
          message: `Failed to copy ${trade.type} trade for ${trade.symbol} from ${randomTrader.name}`,
          type: "error",
          read: false,
          date: new Date().toISOString(),
        })

        toast({
          title: "Trade Failed",
          description: "Failed to execute the copy trade. Please check your broker connection.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Error processing trade:", error)
      toast({
        title: "Error",
        description: "An error occurred while processing the trade",
        variant: "destructive",
      })
    }
  }

  // Check if a trade would exceed the daily loss limit
  const checkDailyLossLimit = (trade: any) => {
    if (trade.type === "SELL") {
      // For simplicity, assume a 2% loss on sells
      const potentialLoss = trade.total * 0.02
      const newDailyLoss = dailyPnLRef.current + potentialLoss

      // Check if this would exceed the max daily loss
      const maxLossAmount = (maxDailyLoss / 100) * 10000 // Mock portfolio value
      return newDailyLoss > maxLossAmount
    }
    return false
  }

  // Helper function to get company name from symbol
  const getCompanyName = (symbol: string) => {
    const companies: Record<string, string> = {
      AAPL: "Apple Inc.",
      MSFT: "Microsoft Corp.",
      GOOGL: "Alphabet Inc.",
      AMZN: "Amazon.com Inc.",
      TSLA: "Tesla Inc.",
    }
    return companies[symbol] || symbol
  }

  // The component doesn't render anything visible
  return null
}

