"use client"

import { Separator } from "@/components/ui/separator"

import { TableCell } from "@/components/ui/table"

import { TableBody } from "@/components/ui/table"

import { TableHead } from "@/components/ui/table"

import { TableRow } from "@/components/ui/table"

import { TableHeader } from "@/components/ui/table"

import { Table } from "@/components/ui/table"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { useCopyTrading } from "@/lib/copy-trading"

export function CopyTradingPerformance() {
  const { getPerformanceData } = useCopyTrading()
  const performanceData = getPerformanceData()

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"]

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Profit/Loss</CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${performanceData.netProfitLoss >= 0 ? "text-green-600" : "text-red-600"}`}
            >
              {performanceData.netProfitLoss >= 0 ? "+" : ""}${performanceData.netProfitLoss.toFixed(2)}
            </div>
            <div className="text-xs text-muted-foreground">From {performanceData.totalCopiedTrades} copied trades</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{performanceData.winRate.toFixed(1)}%</div>
            <div className="text-xs text-muted-foreground">
              {performanceData.successfulTrades} wins / {performanceData.failedTrades} losses
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{performanceData.profitFactor.toFixed(2)}</div>
            <div className="text-xs text-muted-foreground">Ratio of gross profit to gross loss</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Max Drawdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{performanceData.largestDrawdown.toFixed(1)}%</div>
            <div className="text-xs text-muted-foreground">Largest drop from peak to trough</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="daily" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="daily">Daily Performance</TabsTrigger>
          <TabsTrigger value="traders">Trader Performance</TabsTrigger>
          <TabsTrigger value="metrics">Key Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="daily" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Daily Performance</CardTitle>
              <CardDescription>Profit/loss over the last 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={performanceData.dailyPerformance}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="date" />
                    <YAxis tickFormatter={(value) => `$${value}`} />
                    <Tooltip formatter={(value) => [`$${value}`, "Profit/Loss"]} />
                    <Bar
                      dataKey="profit"
                      name="Profit/Loss"
                      fill={(entry) => (entry.profit >= 0 ? "hsl(var(--primary))" : "hsl(var(--destructive))")}
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="traders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Trader Performance</CardTitle>
              <CardDescription>Performance breakdown by trader</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={performanceData.traderPerformance}
                      layout="vertical"
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" tickFormatter={(value) => `$${value}`} />
                      <YAxis type="category" dataKey="traderName" width={100} />
                      <Tooltip formatter={(value) => [`$${value}`, "Profit"]} />
                      <Bar
                        dataKey="profit"
                        name="Profit"
                        fill={(entry) => (entry.profit >= 0 ? "hsl(var(--primary))" : "hsl(var(--destructive))")}
                        radius={[0, 4, 4, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={performanceData.traderPerformance}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="trades"
                        nameKey="traderName"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {performanceData.traderPerformance.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} trades`, ""]} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="mt-6 space-y-4">
                <h3 className="text-lg font-medium">Trader Performance Details</h3>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Trader</TableHead>
                        <TableHead>Trades</TableHead>
                        <TableHead>Win Rate</TableHead>
                        <TableHead>Profit/Loss</TableHead>
                        <TableHead>Contribution</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {performanceData.traderPerformance.map((trader) => (
                        <TableRow key={trader.traderId}>
                          <TableCell className="font-medium">{trader.traderName}</TableCell>
                          <TableCell>{trader.trades}</TableCell>
                          <TableCell>{trader.winRate.toFixed(1)}%</TableCell>
                          <TableCell className={trader.profit >= 0 ? "text-green-600" : "text-red-600"}>
                            {trader.profit >= 0 ? "+" : ""}${trader.profit.toFixed(2)}
                          </TableCell>
                          <TableCell>{((trader.profit / performanceData.netProfitLoss) * 100).toFixed(1)}%</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Key Performance Metrics</CardTitle>
              <CardDescription>Detailed metrics about your copy trading performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Total Profit</span>
                      <span className="text-sm font-medium text-green-600">
                        ${performanceData.totalProfit.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Total Loss</span>
                      <span className="text-sm font-medium text-red-600">${performanceData.totalLoss.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Net Profit/Loss</span>
                      <span
                        className={`text-sm font-medium ${performanceData.netProfitLoss >= 0 ? "text-green-600" : "text-red-600"}`}
                      >
                        {performanceData.netProfitLoss >= 0 ? "+" : ""}${performanceData.netProfitLoss.toFixed(2)}
                      </span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Total Trades</span>
                      <span className="text-sm font-medium">{performanceData.totalCopiedTrades}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Winning Trades</span>
                      <span className="text-sm font-medium text-green-600">{performanceData.successfulTrades}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Losing Trades</span>
                      <span className="text-sm font-medium text-red-600">{performanceData.failedTrades}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Win Rate</span>
                      <span className="text-sm font-medium">{performanceData.winRate.toFixed(1)}%</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Average Profit</span>
                      <span className="text-sm font-medium text-green-600">
                        ${performanceData.averageProfit.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Average Loss</span>
                      <span className="text-sm font-medium text-red-600">
                        ${performanceData.averageLoss.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Profit Factor</span>
                      <span className="text-sm font-medium">{performanceData.profitFactor.toFixed(2)}</span>
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Best Trade</span>
                      <span className="text-sm font-medium text-green-600">
                        ${performanceData.bestTrade.toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Worst Trade</span>
                      <span className="text-sm font-medium text-red-600">${performanceData.worstTrade.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">Largest Drawdown</span>
                      <span className="text-sm font-medium text-red-600">
                        {performanceData.largestDrawdown.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

