"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { TrendingUp, TrendingDown, Plus, AlertCircle } from "lucide-react"
import { usePortfolio, type Position } from "@/lib/portfolio"
import { useToast } from "@/components/ui/use-toast"
import { useNotifications } from "@/lib/notifications"
import { formatDistanceToNow } from "date-fns"

export default function PortfolioPage() {
  const { positions, trades, balance, removePosition, updateBalance, addTrade } = usePortfolio()
  const { addNotification } = useNotifications()
  const { toast } = useToast()

  const [selectedPosition, setSelectedPosition] = useState<Position | null>(null)
  const [closePositionDialog, setClosePositionDialog] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)

  const calculateTotalValue = () => {
    return positions.reduce((total, position) => {
      return total + position.currentPrice * position.quantity
    }, 0)
  }

  const calculateTotalProfitLoss = () => {
    return positions.reduce((total, position) => {
      const positionPL = (position.currentPrice - position.entryPrice) * position.quantity
      return total + positionPL
    }, 0)
  }

  const calculateProfitLossPercent = () => {
    const totalInvested = positions.reduce((total, position) => {
      return total + position.entryPrice * position.quantity
    }, 0)

    if (totalInvested === 0) return 0

    const totalPL = calculateTotalProfitLoss()
    return (totalPL / totalInvested) * 100
  }

  const handleClosePosition = (position: Position) => {
    setSelectedPosition(position)
    setClosePositionDialog(true)
  }

  const executeClosePosition = () => {
    if (!selectedPosition) return

    setIsProcessing(true)

    // Simulate API call
    setTimeout(() => {
      try {
        const proceeds = selectedPosition.currentPrice * selectedPosition.quantity
        const profitLoss = (selectedPosition.currentPrice - selectedPosition.entryPrice) * selectedPosition.quantity
        const profitLossPercent = (profitLoss / (selectedPosition.entryPrice * selectedPosition.quantity)) * 100

        // Add to trade history
        addTrade({
          id: Date.now().toString(),
          symbol: selectedPosition.symbol,
          name: selectedPosition.name,
          type: "SELL",
          price: selectedPosition.currentPrice,
          quantity: selectedPosition.quantity,
          total: proceeds,
          date: new Date().toISOString(),
          status: "executed",
          traderId: selectedPosition.traderId,
          traderName: selectedPosition.traderName,
        })

        // Remove position and update balance
        removePosition(selectedPosition.id)

        // Add notification
        addNotification({
          title: "Position Closed",
          message: `Your position in ${selectedPosition.symbol} has been closed with a ${profitLoss >= 0 ? "profit" : "loss"} of ${Math.abs(profitLoss).toLocaleString()} (${profitLossPercent.toFixed(2)}%).`,
          type: "trade",
          link: "/dashboard/portfolio",
        })

        toast({
          title: "Position closed",
          description: `Your position in ${selectedPosition.symbol} has been closed successfully.`,
        })

        setClosePositionDialog(false)
      } catch (error) {
        toast({
          title: "Failed to close position",
          description: "An error occurred while closing your position. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsProcessing(false)
      }
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Portfolio</h1>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          New Position
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${balance.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Available for trading</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Portfolio Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${calculateTotalValue().toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">{positions.length} active positions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total P&L</CardTitle>
          </CardHeader>
          <CardContent>
            <div
              className={`text-2xl font-bold ${calculateTotalProfitLoss() >= 0 ? "text-green-600" : "text-red-600"}`}
            >
              {calculateTotalProfitLoss() >= 0 ? "+" : ""}${calculateTotalProfitLoss().toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              {calculateTotalProfitLoss() >= 0 ? "+" : ""}
              {calculateProfitLossPercent().toFixed(2)}% overall
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="positions" className="space-y-4">
        <TabsList>
          <TabsTrigger value="positions">Positions</TabsTrigger>
          <TabsTrigger value="history">Trade History</TabsTrigger>
        </TabsList>
        <TabsContent value="positions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Active Positions</CardTitle>
              <CardDescription>Your currently open positions</CardDescription>
            </CardHeader>
            <CardContent>
              {positions.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Symbol</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Entry Price</TableHead>
                      <TableHead>Current Price</TableHead>
                      <TableHead>P&L</TableHead>
                      <TableHead>Open Date</TableHead>
                      <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {positions.map((position) => {
                      const profitLoss = (position.currentPrice - position.entryPrice) * position.quantity
                      const profitLossPercent = (profitLoss / (position.entryPrice * position.quantity)) * 100

                      return (
                        <TableRow key={position.id}>
                          <TableCell className="font-medium">{position.symbol}</TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {position.type.charAt(0).toUpperCase() + position.type.slice(1)}
                            </Badge>
                          </TableCell>
                          <TableCell>{position.quantity}</TableCell>
                          <TableCell>
                            {position.type === "forex"
                              ? position.entryPrice.toFixed(4)
                              : `$${position.entryPrice.toLocaleString()}`}
                          </TableCell>
                          <TableCell>
                            {position.type === "forex"
                              ? position.currentPrice.toFixed(4)
                              : `$${position.currentPrice.toLocaleString()}`}
                          </TableCell>
                          <TableCell>
                            <div
                              className={`flex items-center gap-1 ${profitLoss >= 0 ? "text-green-600" : "text-red-600"}`}
                            >
                              {profitLoss >= 0 ? (
                                <>
                                  +${profitLoss.toLocaleString()} ({profitLossPercent.toFixed(2)}%)
                                  <TrendingUp className="h-4 w-4" />
                                </>
                              ) : (
                                <>
                                  -${Math.abs(profitLoss).toLocaleString()} ({profitLossPercent.toFixed(2)}%)
                                  <TrendingDown className="h-4 w-4" />
                                </>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>{formatDistanceToNow(new Date(position.openDate), { addSuffix: true })}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="outline" size="sm" onClick={() => handleClosePosition(position)}>
                              Close
                            </Button>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center py-6">
                  <p className="text-sm text-muted-foreground">You don't have any open positions.</p>
                  <Button className="mt-4" size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Open Position
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Trade History</CardTitle>
              <CardDescription>Your historical trades</CardDescription>
            </CardHeader>
            <CardContent>
              {trades.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Symbol</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Quantity</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Source</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {trades.map((trade) => (
                      <TableRow key={trade.id}>
                        <TableCell className="font-medium">{trade.symbol}</TableCell>
                        <TableCell>
                          <Badge variant={trade.type === "BUY" ? "default" : "destructive"}>{trade.type}</Badge>
                        </TableCell>
                        <TableCell>${trade.price.toLocaleString()}</TableCell>
                        <TableCell>{trade.quantity}</TableCell>
                        <TableCell>${trade.total.toLocaleString()}</TableCell>
                        <TableCell>{formatDistanceToNow(new Date(trade.date), { addSuffix: true })}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              trade.status === "executed"
                                ? "outline"
                                : trade.status === "pending"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {trade.status.charAt(0).toUpperCase() + trade.status.slice(1)}
                          </Badge>
                        </TableCell>
                        <TableCell>{trade.traderName ? `via ${trade.traderName}` : "Manual"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center py-6">
                  <p className="text-sm text-muted-foreground">You don't have any trade history yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={closePositionDialog} onOpenChange={setClosePositionDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Close Position</DialogTitle>
            <DialogDescription>
              Are you sure you want to close your position in {selectedPosition?.symbol}?
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium">Symbol</p>
                <p className="text-sm">{selectedPosition?.symbol}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Quantity</p>
                <p className="text-sm">{selectedPosition?.quantity}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Entry Price</p>
                <p className="text-sm">
                  {selectedPosition?.type === "forex"
                    ? selectedPosition?.entryPrice.toFixed(4)
                    : `$${selectedPosition?.entryPrice.toLocaleString()}`}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium">Current Price</p>
                <p className="text-sm">
                  {selectedPosition?.type === "forex"
                    ? selectedPosition?.currentPrice.toFixed(4)
                    : `$${selectedPosition?.currentPrice.toLocaleString()}`}
                </p>
              </div>
            </div>

            {selectedPosition && (
              <div className="rounded-md bg-muted p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium">Estimated Proceeds</p>
                  <p className="text-sm font-medium">
                    ${(selectedPosition.currentPrice * selectedPosition.quantity).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <p className="text-sm font-medium">Profit/Loss</p>
                  <p
                    className={`text-sm font-medium ${
                      (selectedPosition.currentPrice - selectedPosition.entryPrice) * selectedPosition.quantity >= 0
                        ? "text-green-600"
                        : "text-red-600"
                    }`}
                  >
                    {(selectedPosition.currentPrice - selectedPosition.entryPrice) * selectedPosition.quantity >= 0
                      ? "+"
                      : "-"}
                    $
                    {Math.abs(
                      (selectedPosition.currentPrice - selectedPosition.entryPrice) * selectedPosition.quantity,
                    ).toLocaleString()}
                    (
                    {Math.abs(
                      ((selectedPosition.currentPrice - selectedPosition.entryPrice) / selectedPosition.entryPrice) *
                        100,
                    ).toFixed(2)}
                    %)
                  </p>
                </div>
              </div>
            )}

            <div className="flex items-center gap-2 rounded-md bg-amber-50 p-3 text-sm">
              <AlertCircle className="h-4 w-4 text-amber-500" />
              <p className="text-amber-700">
                This action cannot be undone. The position will be closed at the current market price.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setClosePositionDialog(false)} disabled={isProcessing}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={executeClosePosition} disabled={isProcessing}>
              {isProcessing ? "Processing..." : "Close Position"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

