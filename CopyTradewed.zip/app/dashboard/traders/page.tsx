import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TraderLeaderboard } from "@/components/trader-leaderboard"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

export default function TradersPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Traders</h1>
        <div className="relative w-64">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search traders..." className="pl-8" />
        </div>
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Traders</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Trader Leaderboard</CardTitle>
              <CardDescription>Top-performing traders ranked by ROI, success rate, and risk level</CardDescription>
            </CardHeader>
            <CardContent>
              <TraderLeaderboard />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="following" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Traders You Follow</CardTitle>
              <CardDescription>Traders whose trades you are currently copying</CardDescription>
            </CardHeader>
            <CardContent>
              <TraderLeaderboard followingOnly={true} />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="recommended" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recommended Traders</CardTitle>
              <CardDescription>Traders that match your risk profile and trading preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="mb-4 rounded-lg bg-muted p-4">
                <p className="text-sm">Complete your risk profile to get personalized trader recommendations.</p>
                <Button size="sm" className="mt-2">
                  Complete Profile
                </Button>
              </div>
              <TraderLeaderboard recommended={true} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

