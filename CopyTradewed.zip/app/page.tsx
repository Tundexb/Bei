"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUpRight, BarChart3, ChevronRight, LineChart, TrendingUp, Users, Shield } from "lucide-react"
import { TopTraders } from "@/components/top-traders"
import { MarketInsights } from "@/components/market-insights"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/app/api/auth/[...nextauth]/route"
import { signOut } from "next-auth/react"

export default async function HomePage() {
  const session = await getServerSession(authOptions)

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-6 w-6" />
            <span className="text-xl font-bold">TradeCopy</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="#features" className="text-sm font-medium">
              Features
            </Link>
            <Link href="#traders" className="text-sm font-medium">
              Top Traders
            </Link>
            <Link href="#insights" className="text-sm font-medium">
              Market Insights
            </Link>
            <Link href="/discover" className="text-sm font-medium">
              Discover
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            {session ? (
              <Button variant="outline" onClick={() => signOut()}>
                Log out
              </Button>
            ) : (
              <>
                <Link href="/auth/login">
                  <Button variant="outline">Log in</Button>
                </Link>
                <Link href="/auth/register">
                  <Button>Sign up</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-background to-muted">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Copy Trades from Top Performers
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Automatically replicate trades from expert traders in real-time. Start growing your portfolio with
                    proven strategies.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/auth/register">
                    <Button size="lg" className="gap-1">
                      Get Started <ArrowUpRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="#features">
                    <Button size="lg" variant="outline">
                      Learn More
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex justify-center lg:justify-end">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="flex flex-col gap-1 rounded-lg bg-primary-foreground/10 p-4 backdrop-blur">
                    <div className="text-3xl font-bold">10,000+</div>
                    <div className="text-sm">Active Users</div>
                  </div>
                  <div className="flex flex-col gap-1 rounded-lg bg-primary-foreground/10 p-4 backdrop-blur">
                    <div className="text-3xl font-bold">500+</div>
                    <div className="text-sm">Expert Traders</div>
                  </div>
                  <div className="flex flex-col gap-1 rounded-lg bg-primary-foreground/10 p-4 backdrop-blur">
                    <div className="text-3xl font-bold">$50M+</div>
                    <div className="text-sm">Monthly Volume</div>
                  </div>
                  <div className="flex flex-col gap-1 rounded-lg bg-primary-foreground/10 p-4 backdrop-blur">
                    <div className="text-3xl font-bold">24/7</div>
                    <div className="text-sm">Support</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="features" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Platform Features</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Everything you need to start copy trading with confidence
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
              {features.map((feature, index) => (
                <Card key={index} className="flex flex-col">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      {feature.icon}
                      <CardTitle>{feature.title}</CardTitle>
                    </div>
                    <CardDescription>{feature.description}</CardDescription>
                  </CardHeader>
                  <CardFooter className="mt-auto pt-4">
                    <Link href={feature.link} className="text-sm font-medium flex items-center">
                      Learn more <ChevronRight className="ml-1 h-4 w-4" />
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section id="traders" className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Top Traders</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Follow and copy trades from our top-performing traders
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl mt-8">
              <TopTraders />
            </div>
            <div className="flex justify-center mt-8">
              <Link href="/traders">
                <Button variant="outline" size="lg">
                  View All Traders
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <section id="insights" className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Market Insights</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Stay updated with the latest market trends and analysis
                </p>
              </div>
            </div>
            <div className="mx-auto max-w-5xl mt-8">
              <MarketInsights />
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-primary text-primary-foreground">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                    Ready to Start Copy Trading?
                  </h2>
                  <p className="max-w-[600px] md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                    Join thousands of traders who are already growing their portfolios with TradeCopy.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/auth/register">
                    <Button size="lg" className="gap-1">
                      Get Started <ArrowUpRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex justify-center lg:justify-end">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="flex flex-col gap-1 rounded-lg bg-primary-foreground/10 p-4 backdrop-blur">
                    <div className="text-3xl font-bold">10,000+</div>
                    <div className="text-sm">Active Users</div>
                  </div>
                  <div className="flex flex-col gap-1 rounded-lg bg-primary-foreground/10 p-4 backdrop-blur">
                    <div className="text-3xl font-bold">500+</div>
                    <div className="text-sm">Expert Traders</div>
                  </div>
                  <div className="flex flex-col gap-1 rounded-lg bg-primary-foreground/10 p-4 backdrop-blur">
                    <div className="text-3xl font-bold">$50M+</div>
                    <div className="text-sm">Monthly Volume</div>
                  </div>
                  <div className="flex flex-col gap-1 rounded-lg bg-primary-foreground/10 p-4 backdrop-blur">
                    <div className="text-3xl font-bold">24/7</div>
                    <div className="text-sm">Support</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            <p className="text-sm font-medium">TradeCopy &copy; {new Date().getFullYear()}</p>
          </div>
          <nav className="flex gap-4 md:gap-6">
            <Link href="#" className="text-sm font-medium">
              Terms
            </Link>
            <Link href="#" className="text-sm font-medium">
              Privacy
            </Link>
            <Link href="#" className="text-sm font-medium">
              Contact
            </Link>
          </nav>
        </div>
      </footer>
    </div>
  )
}

const features = [
  {
    title: "Real-Time Copying",
    description: "Automatically copy trades from expert traders in real-time with customizable risk settings.",
    icon: <BarChart3 className="h-5 w-5" />,
    link: "/education/copy-trading",
  },
  {
    title: "Multi-Asset Support",
    description: "Trade stocks, ETFs, cryptocurrencies, and forex all from a single platform.",
    icon: <LineChart className="h-5 w-5" />,
    link: "/education/markets",
  },
  {
    title: "Trader Leaderboard",
    description: "Find and follow top-performing traders based on ROI, success rate, and risk level.",
    icon: <Users className="h-5 w-5" />,
    link: "/discover",
  },
  {
    title: "Advanced Analytics",
    description: "Track your performance with detailed analytics and insights on your trading activity.",
    icon: <BarChart3 className="h-5 w-5" />,
    link: "/dashboard/analytics",
  },
  {
    title: "Multi-Broker Support",
    description: "Connect with major brokers including Schwab, Tastytrade, and more.",
    icon: <TrendingUp className="h-5 w-5" />,
    link: "/help/brokers",
  },
  {
    title: "Secure Platform",
    description: "Enterprise-grade security with 2FA, encryption, and regular security audits.",
    icon: <Shield className="h-5 w-5" />,
    link: "/help/security",
  },
]

