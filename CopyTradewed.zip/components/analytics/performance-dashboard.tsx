"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/components/ui/use-toast"
import {
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Calendar,
  Download,
  FileText,
  LineChart,
  PieChart,
  RefreshCw,
  TrendingDown,
  TrendingUp,
  Users,
} from "lucide-react"

export function PerformanceDashboard() {
  const [timeframe, setTimeframe] = useState("1m")
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  // Simulate loading data
  useEffect(() => {
    const loadData = async () => {
      try {
        // In a real app, this would be an API call
        await new Promise((resolve) => setTimeout(resolve, 1000))
      } catch (error) {
        toast({
          title: "Error loading data",
          description: "There was a problem loading performance data. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [timeframe, toast])

  const handleRefresh = async () => {
    try {
      setIsLoading(true)
      // In a real app, this would be an API call
      await new Promise((resolve) => setTimeout(resolve, 1000))
      toast({
        title: "Data refreshed",
        description: "Performance data has been updated.",
      })
    } catch (error) {
      toast({
        title: "Error refreshing data",
        description: "There was a problem refreshing the data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleExport = () => {
    try {
      toast({
        title: "Export started",
        description: "Your performance report is being generated and will download shortly.",
      })

      // In a real app, this would trigger a file download
      setTimeout(() => {
        toast({
          title: "Export complete",
          description: "Your performance report has been downloaded.",
        })
      }, 2000)
    } catch (error) {
      toast({
        title: "Export failed",
        description: "There was a problem exporting your data. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Performance Dashboard</h2>
          <p className="text-muted-foreground">Comprehensive analysis of your copy trading performance</p>
        </div>

        <div className="flex items-center gap-2">
          <Select defaultValue={timeframe} onValueChange={setTimeframe}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select timeframe" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1w">1 Week</SelectItem>
              <SelectItem value="1m">1 Month</SelectItem>
              <SelectItem value="3m">3 Months</SelectItem>
              <SelectItem value="6m">6 Months</SelectItem>
              <SelectItem value="1y">1 Year</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon" onClick={handleRefresh} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
          </Button>

          <Button variant="outline" onClick={handleExport} disabled={isLoading}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className={isLoading ? "opacity-60" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Return</CardTitle>
            <LineChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-2">
                <div className="h-6 w-24 bg-muted rounded"></div>
                <div className="h-4 w-16 bg-muted rounded"></div>
              </div>
            ) : (
              <>
                <div className="flex items-baseline space-x-2">
                  <div className="text-2xl font-bold">+18.34%</div>
                  <div className="text-xs text-green-500 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +2.5%
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">vs. previous period</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className={isLoading ? "opacity-60" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-2">
                <div className="h-6 w-24 bg-muted rounded"></div>
                <div className="h-4 w-16 bg-muted rounded"></div>
              </div>
            ) : (
              <>
                <div className="flex items-baseline space-x-2">
                  <div className="text-2xl font-bold">68.5%</div>
                  <div className="text-xs text-green-500 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +3.2%
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">137 wins / 63 losses</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className={isLoading ? "opacity-60" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-2">
                <div className="h-6 w-24 bg-muted rounded"></div>
                <div className="h-4 w-16 bg-muted rounded"></div>
              </div>
            ) : (
              <>
                <div className="flex items-baseline space-x-2">
                  <div className="text-2xl font-bold">2.14</div>
                  <div className="text-xs text-red-500 flex items-center">
                    <ArrowDownRight className="h-3 w-3 mr-1" />
                    -0.3
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Gross profit / Gross loss</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card className={isLoading ? "opacity-60" : ""}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Max Drawdown</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="animate-pulse space-y-2">
                <div className="h-6 w-24 bg-muted rounded"></div>
                <div className="h-4 w-16 bg-muted rounded"></div>
              </div>
            ) : (
              <>
                <div className="flex items-baseline space-x-2">
                  <div className="text-2xl font-bold">-12.7%</div>
                  <div className="text-xs text-green-500 flex items-center">
                    <ArrowUpRight className="h-3 w-3 mr-1" />
                    +1.8%
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Improved from previous period</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="grid grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="traders">Traders</TabsTrigger>
          <TabsTrigger value="trades">Trades</TabsTrigger>
          <TabsTrigger value="assets">Assets</TabsTrigger>
          <TabsTrigger value="advanced">Advanced</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4 pt-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Performance Chart</CardTitle>
                <CardDescription>Cumulative return over time</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px] flex items-center justify-center bg-muted/20">
                {isLoading ? (
                  <div className="animate-pulse w-full h-full bg-muted/40 rounded-md"></div>
                ) : (
                  <div className="text-center">
                    <LineChart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Performance chart visualization</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      (This would be an actual chart in the real implementation)
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className={isLoading ? "opacity-60" : ""}>
              <CardHeader>
                <CardTitle>Monthly Returns (%)</CardTitle>
                <CardDescription>Performance breakdown by month</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <div key={i} className="flex items-center justify-between">
                        <div className="h-4 w-24 bg-muted rounded animate-pulse"></div>
                        <div className="h-4 w-16 bg-muted rounded animate-pulse"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {[
                      { month: "November", year: "2023", return: 3.2, positive: true },
                      { month: "October", year: "2023", return: 5.7, positive: true },
                      { month: "September", year: "2023", return: -2.1, positive: false },
                      { month: "August", year: "2023", return: 4.5, positive: true },
                      { month: "July", year: "2023", return: 6.8, positive: true },
                      { month: "June", year: "2023", return: -1.3, positive: false },
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 text-muted-foreground mr-2" />
                          <span>
                            {item.month} {item.year}
                          </span>
                        </div>
                        <div className={`flex items-center ${item.positive ? "text-green-500" : "text-red-500"}`}>
                          {item.positive ? (
                            <TrendingUp className="h-4 w-4 mr-1" />
                          ) : (
                            <TrendingDown className="h-4 w-4 mr-1" />
                          )}
                          {item.positive ? "+" : ""}
                          {item.return}%
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" disabled={isLoading}>
                  <FileText className="mr-2 h-4 w-4" />
                  View Full History
                </Button>
              </CardFooter>
            </Card>

            <Card className={isLoading ? "opacity-60" : ""}>
              <CardHeader>
                <CardTitle>Performance Metrics</CardTitle>
                <CardDescription>Key trading statistics</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                      <div key={i} className="flex items-center justify-between">
                        <div className="space-y-1">
                          <div className="h-4 w-24 bg-muted rounded animate-pulse"></div>
                          <div className="h-3 w-16 bg-muted rounded animate-pulse"></div>
                        </div>
                        <div className="h-4 w-12 bg-muted rounded animate-pulse"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {[
                      { metric: "Sharpe Ratio", value: "1.87", info: "Risk-adjusted return" },
                      { metric: "Average Win", value: "+2.34%", info: "Average winning trade" },
                      { metric: "Average Loss", value: "-1.12%", info: "Average losing trade" },
                      { metric: "Win/Loss Ratio", value: "2.09", info: "Avg win / Avg loss" },
                      { metric: "Expectancy", value: "1.28%", info: "Expected return per trade" },
                      { metric: "Recovery Factor", value: "3.42", info: "Net profit / Max drawdown" },
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{item.metric}</div>
                          <div className="text-xs text-muted-foreground">{item.info}</div>
                        </div>
                        <div className="font-bold">{item.value}</div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="traders" className="space-y-4 pt-4">
          <Card className={isLoading ? "opacity-60" : ""}>
            <CardHeader>
              <CardTitle>Trader Performance</CardTitle>
              <CardDescription>Performance breakdown by trader</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-6">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                          <div className="h-10 w-10 bg-muted rounded-full animate-pulse mr-2"></div>
                          <div className="space-y-1">
                            <div className="h-4 w-24 bg-muted rounded animate-pulse"></div>
                            <div className="h-3 w-16 bg-muted rounded animate-pulse"></div>
                          </div>
                        </div>
                        <div className="h-4 w-16 bg-muted rounded animate-pulse"></div>
                      </div>

                      <div className="flex items-center text-xs text-muted-foreground mb-2">
                        <div className="h-3 w-20 bg-muted rounded animate-pulse mr-4"></div>
                        <div className="h-3 w-20 bg-muted rounded animate-pulse"></div>
                      </div>

                      <div className="w-full bg-muted h-2 rounded-full overflow-hidden mb-4">
                        <div className="h-full rounded-full bg-muted/60 animate-pulse" style={{ width: "50%" }}></div>
                      </div>

                      {i < 4 && <Separator className="my-4" />}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  {[
                    {
                      name: "Sarah Johnson",
                      return: 24.7,
                      allocation: 35,
                      trades: 87,
                      winRate: 72.4,
                      profitable: true,
                    },
                    {
                      name: "Michael Chen",
                      return: 18.3,
                      allocation: 25,
                      trades: 63,
                      winRate: 68.2,
                      profitable: true,
                    },
                    {
                      name: "Alex Rodriguez",
                      return: -5.2,
                      allocation: 15,
                      trades: 42,
                      winRate: 45.2,
                      profitable: false,
                    },
                    {
                      name: "David Park",
                      return: 12.8,
                      allocation: 25,
                      trades: 56,
                      winRate: 64.3,
                      profitable: true,
                    },
                  ].map((trader, index) => (
                    <div key={index}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                          <Users className="h-5 w-5 text-muted-foreground mr-2" />
                          <div>
                            <div className="font-medium">{trader.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {trader.trades} trades • {trader.winRate}% win rate
                            </div>
                          </div>
                        </div>
                        <div className={`flex items-center ${trader.profitable ? "text-green-500" : "text-red-500"}`}>
                          {trader.profitable ? (
                            <TrendingUp className="h-4 w-4 mr-1" />
                          ) : (
                            <TrendingDown className="h-4 w-4 mr-1" />
                          )}
                          {trader.profitable ? "+" : ""}
                          {trader.return}%
                        </div>
                      </div>

                      <div className="flex items-center text-xs text-muted-foreground mb-2">
                        <div className="mr-4">Allocation: {trader.allocation}%</div>
                        <div>Contribution: {((trader.return * trader.allocation) / 100).toFixed(1)}%</div>
                      </div>

                      <div className="w-full bg-muted h-2 rounded-full overflow-hidden mb-4">
                        <div
                          className={`h-full rounded-full ${trader.profitable ? "bg-green-500" : "bg-red-500"}`}
                          style={{ width: `${Math.min(Math.abs(trader.return) * 2, 100)}%` }}
                        />
                      </div>

                      {index < 3 && <Separator className="my-4" />}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" disabled={isLoading}>
                <Users className="mr-2 h-4 w-4" />
                View All Traders
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="trades" className="space-y-4 pt-4">
          <Card className={isLoading ? "opacity-60" : ""}>
            <CardHeader>
              <CardTitle>Recent Trades</CardTitle>
              <CardDescription>Your most recent copy trading activity</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center">
                          <div className="h-6 w-16 bg-muted rounded animate-pulse mr-2"></div>
                          <div className="h-4 w-16 bg-muted rounded animate-pulse"></div>
                        </div>
                        <div className="h-3 w-24 bg-muted rounded animate-pulse mt-1"></div>
                      </div>

                      <div>
                        <div className="h-4 w-16 bg-muted rounded animate-pulse text-right"></div>
                        <div className="h-3 w-20 bg-muted rounded animate-pulse mt-1 ml-auto"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {[
                    {
                      symbol: "AAPL",
                      type: "buy",
                      entry: 175.5,
                      exit: 189.25,
                      profit: 7.8,
                      date: "2023-11-20",
                      trader: "Sarah Johnson",
                      result: "win",
                    },
                    {
                      symbol: "EUR/USD",
                      type: "sell",
                      entry: 1.095,
                      exit: 1.085,
                      profit: 0.91,
                      date: "2023-11-19",
                      trader: "Alex Rodriguez",
                      result: "win",
                    },
                    {
                      symbol: "TSLA",
                      type: "buy",
                      entry: 240.5,
                      exit: 232.75,
                      profit: -3.2,
                      date: "2023-11-18",
                      trader: "Michael Chen",
                      result: "loss",
                    },
                    {
                      symbol: "BTC/USD",
                      type: "buy",
                      entry: 36500,
                      exit: 38200,
                      profit: 4.7,
                      date: "2023-11-17",
                      trader: "David Park",
                      result: "win",
                    },
                    {
                      symbol: "AMZN",
                      type: "sell",
                      entry: 145.75,
                      exit: 148.5,
                      profit: -1.9,
                      date: "2023-11-16",
                      trader: "Sarah Johnson",
                      result: "loss",
                    },
                  ].map((trade, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center">
                          <Badge className={trade.type === "buy" ? "bg-green-500" : "bg-red-500"}>
                            {trade.type === "buy" ? (
                              <TrendingUp className="mr-1 h-3 w-3" />
                            ) : (
                              <TrendingDown className="mr-1 h-3 w-3" />
                            )}
                            {trade.type.toUpperCase()}
                          </Badge>
                          <span className="ml-2 font-medium">{trade.symbol}</span>
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">
                          {trade.date} • {trade.trader}
                        </div>
                      </div>

                      <div>
                        <div className={`text-right ${trade.result === "win" ? "text-green-500" : "text-red-500"}`}>
                          {trade.result === "win" ? "+" : ""}
                          {trade.profit}%
                        </div>
                        <div className="text-xs text-muted-foreground text-right mt-1">
                          {trade.entry} → {trade.exit}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" disabled={isLoading}>
                <FileText className="mr-2 h-4 w-4" />
                View Trade History
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="assets" className="space-y-4 pt-4">
          <Card className={isLoading ? "opacity-60" : ""}>
            <CardHeader>
              <CardTitle>Asset Allocation</CardTitle>
              <CardDescription>Distribution of your portfolio by asset class</CardDescription>
            </CardHeader>
            <CardContent className="h-[300px] flex items-center justify-center bg-muted/20">
              {isLoading ? (
                <div className="animate-pulse w-full h-full bg-muted/40 rounded-md"></div>
              ) : (
                <div className="text-center">
                  <PieChart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Asset allocation chart</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    (This would be an actual chart in the real implementation)
                  </p>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <div className="w-full grid grid-cols-2 gap-4">
                {isLoading
                  ? [1, 2, 3, 4].map((i) => (
                      <div key={i} className="flex items-center">
                        <div className="w-3 h-3 rounded-full bg-muted animate-pulse mr-2"></div>
                        <div className="h-4 w-24 bg-muted rounded animate-pulse"></div>
                      </div>
                    ))
                  : [
                      { asset: "Stocks", allocation: 45, color: "bg-blue-500" },
                      { asset: "Forex", allocation: 30, color: "bg-green-500" },
                      { asset: "Crypto", allocation: 15, color: "bg-purple-500" },
                      { asset: "Commodities", allocation: 10, color: "bg-yellow-500" },
                    ].map((item, index) => (
                      <div key={index} className="flex items-center">
                        <div className={`w-3 h-3 rounded-full ${item.color} mr-2`} />
                        <div className="text-sm">
                          {item.asset}: {item.allocation}%
                        </div>
                      </div>
                    ))}
              </div>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="advanced" className="space-y-4 pt-4">
          <Card className={isLoading ? "opacity-60" : ""}>
            <CardHeader>
              <CardTitle>Advanced Analytics</CardTitle>
              <CardDescription>Detailed performance metrics and analysis</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="space-y-6">
                  {[1, 2, 3].map((i) => (
                    <div key={i}>
                      <div className="h-6 w-32 bg-muted rounded animate-pulse mb-2"></div>
                      <div className="grid grid-cols-2 gap-4">
                        {[1, 2, 3, 4].map((j) => (
                          <div key={j}>
                            <div className="h-4 w-24 bg-muted rounded animate-pulse"></div>
                            <div className="h-6 w-16 bg-muted rounded animate-pulse my-1"></div>
                            <div className="h-3 w-20 bg-muted rounded animate-pulse"></div>
                          </div>
                        ))}
                      </div>
                      {i < 3 && <div className="h-px w-full bg-muted my-6"></div>}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium mb-2">Risk Analysis</h3>
                    <div className="grid grid-cols-2 gap-4">
                      {[
                        { metric: "Value at Risk (VaR)", value: "$1,250", info: "95% confidence" },
                        { metric: "Beta", value: "0.85", info: "vs. S&P 500" },
                        { metric: "Standard Deviation", value: "12.4%", info: "Annualized" },
                        { metric: "Sortino Ratio", value: "2.15", info: "Downside risk-adjusted" },
                      ].map((item, index) => (
                        <div key={index}>
                          <div className="font-medium">{item.metric}</div>
                          <div className="text-lg">{item.value}</div>
                          <div className="text-xs text-muted-foreground">{item.info}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-medium mb-2">Trading Patterns</h3>
                    <div className="grid grid-cols-2 gap-4">
                      {[
                        { metric: "Best Day", value: "Monday", info: "+2.3% avg return" },
                        { metric: "Worst Day", value: "Friday", info: "-0.8% avg return" },
                        { metric: "Best Hour", value: "10:00 AM", info: "+0.7% avg return" },
                        { metric: "Worst Hour", value: "3:00 PM", info: "-0.5% avg return" },
                      ].map((item, index) => (
                        <div key={index}>
                          <div className="font-medium">{item.metric}</div>
                          <div className="text-lg">{item.value}</div>
                          <div className="text-xs text-muted-foreground">{item.info}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-medium mb-2">Performance Attribution</h3>
                    <div className="space-y-2">
                      {[
                        { factor: "Asset Selection", contribution: 65, positive: true },
                        { factor: "Market Timing", contribution: 20, positive: true },
                        { factor: "Risk Management", contribution: 10, positive: true },
                        { factor: "Fees & Slippage", contribution: 5, positive: false },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div>{item.factor}</div>
                          <div className={item.positive ? "text-green-500" : "text-red-500"}>
                            {item.positive ? "+" : "-"}
                            {item.contribution}%
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full" disabled={isLoading}>
                <Download className="mr-2 h-4 w-4" />
                Export Detailed Report
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

