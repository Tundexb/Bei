import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { TrendingUp, TrendingDown, Award, Users, ExternalLink } from "lucide-react"
import Link from "next/link"

interface TraderCardProps {
  trader: {
    id: string
    name: string
    image?: string
    verified: boolean
    performance: {
      monthly: number
      total: number
    }
    followers: number
    winRate: number
    tradingStyle: string
    markets: string[]
  }
}

export function TraderCard({ trader }: TraderCardProps) {
  const isPositiveMonthly = trader.performance.monthly >= 0
  const isPositiveTotal = trader.performance.total >= 0

  return (
    <Card className="overflow-hidden transition-all hover:shadow-md">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Avatar>
              <AvatarImage src={trader.image} alt={trader.name} />
              <AvatarFallback>{trader.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center">
                <h3 className="font-semibold">{trader.name}</h3>
                {trader.verified && (
                  <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700">
                    <Award className="mr-1 h-3 w-3" />
                    Verified
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground">{trader.tradingStyle}</p>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-muted-foreground">Monthly Return</p>
            <p
              className={`text-sm font-medium flex items-center ${isPositiveMonthly ? "text-green-600" : "text-red-600"}`}
            >
              {isPositiveMonthly ? <TrendingUp className="mr-1 h-3 w-3" /> : <TrendingDown className="mr-1 h-3 w-3" />}
              {isPositiveMonthly ? "+" : ""}
              {trader.performance.monthly.toFixed(2)}%
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Total Return</p>
            <p
              className={`text-sm font-medium flex items-center ${isPositiveTotal ? "text-green-600" : "text-red-600"}`}
            >
              {isPositiveTotal ? <TrendingUp className="mr-1 h-3 w-3" /> : <TrendingDown className="mr-1 h-3 w-3" />}
              {isPositiveTotal ? "+" : ""}
              {trader.performance.total.toFixed(2)}%
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Win Rate</p>
            <p className="text-sm font-medium">{trader.winRate}%</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground">Followers</p>
            <p className="text-sm font-medium flex items-center">
              <Users className="mr-1 h-3 w-3" />
              {trader.followers}
            </p>
          </div>
        </div>
        <div className="mt-3">
          <p className="text-xs text-muted-foreground mb-1">Markets</p>
          <div className="flex flex-wrap gap-1">
            {trader.markets.map((market) => (
              <Badge key={market} variant="secondary" className="text-xs">
                {market}
              </Badge>
            ))}
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-2">
        <Button asChild className="w-full" size="sm">
          <Link href={`/traders/${trader.id}`}>
            View Profile
            <ExternalLink className="ml-2 h-3 w-3" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}

