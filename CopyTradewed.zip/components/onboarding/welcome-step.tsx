import { TrendingUp, Shield, Users, BarChart3 } from "lucide-react"

interface WelcomeStepProps {
  onboardingData: any
  updateOnboardingData: (data: any) => void
}

export function WelcomeStep({ onboardingData, updateOnboardingData }: WelcomeStepProps) {
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <TrendingUp className="h-12 w-12 mx-auto mb-4 text-primary" />
        <h2 className="text-2xl font-bold">Welcome to AlgoForex Copy Trading</h2>
        <p className="text-muted-foreground mt-2">
          We'll guide you through setting up your account to start copy trading in just a few minutes
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="flex items-start gap-3 p-4 rounded-lg border">
          <Shield className="h-6 w-6 text-primary mt-0.5" />
          <div>
            <h3 className="font-medium">Risk Assessment</h3>
            <p className="text-sm text-muted-foreground">
              We'll help you determine your risk tolerance and trading preferences
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3 p-4 rounded-lg border">
          <Users className="h-6 w-6 text-primary mt-0.5" />
          <div>
            <h3 className="font-medium">Discover Traders</h3>
            <p className="text-sm text-muted-foreground">
              Find and follow top-performing traders that match your strategy
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3 p-4 rounded-lg border">
          <TrendingUp className="h-6 w-6 text-primary mt-0.5" />
          <div>
            <h3 className="font-medium">Connect Broker</h3>
            <p className="text-sm text-muted-foreground">
              Link your brokerage account to enable automatic trade copying
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3 p-4 rounded-lg border">
          <BarChart3 className="h-6 w-6 text-primary mt-0.5" />
          <div>
            <h3 className="font-medium">Configure Settings</h3>
            <p className="text-sm text-muted-foreground">
              Set up your copy trading parameters and risk management rules
            </p>
          </div>
        </div>
      </div>

      <div className="bg-muted p-4 rounded-lg mt-6">
        <p className="text-sm">
          <strong>Note:</strong> You can skip any step and come back to it later from your account settings.
        </p>
      </div>
    </div>
  )
}

