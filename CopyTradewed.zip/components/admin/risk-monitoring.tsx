"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatCurrency } from "@/lib/utils"
import { AlertTriangle, Ban, Eye, RefreshCw, ShieldAlert } from "lucide-react"

type RiskLevel = "low" | "medium" | "high" | "critical"

interface RiskAlert {
  id: string
  timestamp: string
  traderId: string
  traderName: string
  type: string
  description: string
  level: RiskLevel
  status: "active" | "resolved" | "ignored"
}

interface ExposureData {
  symbol: string
  totalExposure: number
  percentOfCapital: number
  numTraders: number
  direction: "long" | "short" | "mixed"
}

export function RiskMonitoring() {
  const [selectedAlert, setSelectedAlert] = useState<RiskAlert | null>(null)
  const [alertDialogOpen, setAlertDialogOpen] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)

  const [riskAlerts, setRiskAlerts] = useState<RiskAlert[]>([
    {
      id: "alert-001",
      timestamp: "2023-11-15 09:23:45",
      traderId: "trader-123",
      traderName: "Alex Johnson",
      type: "Unusual Trading Volume",
      description: "Trading volume increased by 500% in the last hour",
      level: "high",
      status: "active",
    },
    {
      id: "alert-002",
      timestamp: "2023-11-15 08:12:30",
      traderId: "trader-456",
      traderName: "Sarah Williams",
      type: "Drawdown Threshold",
      description: "Account drawdown exceeded 15% in the last 24 hours",
      level: "critical",
      status: "active",
    },
    {
      id: "alert-003",
      timestamp: "2023-11-14 16:45:22",
      traderId: "trader-789",
      traderName: "Michael Chen",
      type: "Concentration Risk",
      description: "80% of portfolio allocated to a single asset (BTC/USD)",
      level: "medium",
      status: "resolved",
    },
    {
      id: "alert-004",
      timestamp: "2023-11-14 14:30:15",
      traderId: "trader-101",
      traderName: "Emma Davis",
      type: "Unusual Trading Hours",
      description: "Trading activity detected outside normal trading hours",
      level: "low",
      status: "ignored",
    },
  ])

  const exposureData: ExposureData[] = [
    {
      symbol: "EUR/USD",
      totalExposure: 1250000,
      percentOfCapital: 12.5,
      numTraders: 24,
      direction: "long",
    },
    {
      symbol: "BTC/USD",
      totalExposure: 980000,
      percentOfCapital: 9.8,
      numTraders: 18,
      direction: "mixed",
    },
    {
      symbol: "Gold",
      totalExposure: 750000,
      percentOfCapital: 7.5,
      numTraders: 15,
      direction: "long",
    },
    {
      symbol: "S&P 500",
      totalExposure: 620000,
      percentOfCapital: 6.2,
      numTraders: 12,
      direction: "short",
    },
    {
      symbol: "USD/JPY",
      totalExposure: 580000,
      percentOfCapital: 5.8,
      numTraders: 10,
      direction: "short",
    },
  ]

  const handleAlertStatusChange = (id: string, newStatus: "resolved" | "ignored") => {
    setRiskAlerts((prev) => prev.map((alert) => (alert.id === id ? { ...alert, status: newStatus } : alert)))
    setAlertDialogOpen(false)
  }

  const handleRefresh = async () => {
    setIsRefreshing(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsRefreshing(false)
  }

  const getRiskLevelBadge = (level: RiskLevel) => {
    switch (level) {
      case "low":
        return (
          <Badge variant="outline" className="bg-blue-100 text-blue-800">
            Low
          </Badge>
        )
      case "medium":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
            Medium
          </Badge>
        )
      case "high":
        return (
          <Badge variant="outline" className="bg-orange-100 text-orange-800">
            High
          </Badge>
        )
      case "critical":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800">
            Critical
          </Badge>
        )
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800">
            Active
          </Badge>
        )
      case "resolved":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800">
            Resolved
          </Badge>
        )
      case "ignored":
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800">
            Ignored
          </Badge>
        )
    }
  }

  const getDirectionBadge = (direction: string) => {
    switch (direction) {
      case "long":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800">
            Long
          </Badge>
        )
      case "short":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800">
            Short
          </Badge>
        )
      case "mixed":
        return (
          <Badge variant="outline" className="bg-purple-100 text-purple-800">
            Mixed
          </Badge>
        )
    }
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-xl font-bold">Risk Monitoring</CardTitle>
          <CardDescription>Monitor platform risk exposure and alerts</CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
          {isRefreshing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          <span className="ml-2">Refresh</span>
        </Button>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="alerts">
          <TabsList className="mb-4">
            <TabsTrigger value="alerts">Risk Alerts</TabsTrigger>
            <TabsTrigger value="exposure">Market Exposure</TabsTrigger>
          </TabsList>

          <TabsContent value="alerts">
            <div className="flex justify-between mb-4">
              <Select defaultValue="all">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Alerts</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="resolved">Resolved</SelectItem>
                  <SelectItem value="ignored">Ignored</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all">
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter by level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Trader</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Level</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {riskAlerts.map((alert) => (
                  <TableRow key={alert.id}>
                    <TableCell>{alert.timestamp}</TableCell>
                    <TableCell className="font-medium">{alert.traderName}</TableCell>
                    <TableCell>{alert.type}</TableCell>
                    <TableCell>{getRiskLevelBadge(alert.level)}</TableCell>
                    <TableCell>{getStatusBadge(alert.status)}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setSelectedAlert(alert)
                          setAlertDialogOpen(true)
                        }}
                        disabled={alert.status !== "active"}
                      >
                        <Eye className="h-4 w-4" />
                        <span className="sr-only">View details</span>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>

          <TabsContent value="exposure">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Symbol</TableHead>
                  <TableHead>Total Exposure</TableHead>
                  <TableHead>% of Capital</TableHead>
                  <TableHead>Direction</TableHead>
                  <TableHead>Traders</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {exposureData.map((exposure) => (
                  <TableRow key={exposure.symbol}>
                    <TableCell className="font-medium">{exposure.symbol}</TableCell>
                    <TableCell>{formatCurrency(exposure.totalExposure)}</TableCell>
                    <TableCell>{exposure.percentOfCapital}%</TableCell>
                    <TableCell>{getDirectionBadge(exposure.direction)}</TableCell>
                    <TableCell>{exposure.numTraders}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
        </Tabs>
      </CardContent>

      <Dialog open={alertDialogOpen} onOpenChange={setAlertDialogOpen}>
        {selectedAlert && (
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle className="flex items-center">
                <AlertTriangle className="mr-2 h-5 w-5 text-amber-500" />
                Risk Alert: {selectedAlert.type}
              </DialogTitle>
              <DialogDescription>Detected on {selectedAlert.timestamp}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div>
                <h3 className="font-medium mb-2">Trader</h3>
                <p>{selectedAlert.traderName}</p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Risk Level</h3>
                <p>{getRiskLevelBadge(selectedAlert.level)}</p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Description</h3>
                <p>{selectedAlert.description}</p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Status</h3>
                <p>{getStatusBadge(selectedAlert.status)}</p>
              </div>
            </div>
            <DialogFooter className="flex justify-between">
              {selectedAlert.status === "active" && (
                <>
                  <Button variant="outline" onClick={() => handleAlertStatusChange(selectedAlert.id, "ignored")}>
                    <Ban className="mr-2 h-4 w-4" />
                    Ignore Alert
                  </Button>
                  <Button onClick={() => handleAlertStatusChange(selectedAlert.id, "resolved")}>
                    <ShieldAlert className="mr-2 h-4 w-4" />
                    Mark Resolved
                  </Button>
                </>
              )}
              {selectedAlert.status !== "active" && <Button onClick={() => setAlertDialogOpen(false)}>Close</Button>}
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </Card>
  )
}

