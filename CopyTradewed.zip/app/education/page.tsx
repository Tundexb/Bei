import { EducationCenter } from "@/components/education-center"

export default function EducationPage() {
  return (
    <div className="container mx-auto py-6">
      <EducationCenter />
    </div>
  )
}

