import { create } from "zustand"
import { persist } from "zustand/middleware"

export type Notification = {
  id: string
  title: string
  message: string
  type: "trade" | "alert" | "system" | "trader"
  read: boolean
  date: string
  link?: string
}

type NotificationsState = {
  notifications: Notification[]
  unreadCount: number
  addNotification: (notification: Omit<Notification, "id" | "date" | "read">) => void
  markAsRead: (id: string) => void
  markAllAsRead: () => void
  clearNotifications: () => void
}

// Mock notifications
const initialNotifications: Notification[] = [
  {
    id: "1",
    title: "Trade Executed",
    message: "Your order to buy 10 shares of AAPL at $187.42 has been executed.",
    type: "trade",
    read: false,
    date: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    link: "/dashboard/portfolio",
  },
  {
    id: "2",
    title: "Price Alert",
    message: "BTC has reached your target price of $62,000.",
    type: "alert",
    read: false,
    date: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    link: "/dashboard/market",
  },
  {
    id: "3",
    title: "New Trader Position",
    message: "Alex Morgan has opened a new position in NVDA.",
    type: "trader",
    read: false,
    date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    link: "/dashboard/traders/1",
  },
]

export const useNotifications = create<NotificationsState>()(
  persist(
    (set, get) => ({
      notifications: initialNotifications,
      unreadCount: initialNotifications.filter((n) => !n.read).length,
      addNotification: (notification) => {
        const newNotification: Notification = {
          ...notification,
          id: Date.now().toString(),
          date: new Date().toISOString(),
          read: false,
        }

        set((state) => ({
          notifications: [newNotification, ...state.notifications],
          unreadCount: state.unreadCount + 1,
        }))
      },
      markAsRead: (id) => {
        set((state) => {
          const notification = state.notifications.find((n) => n.id === id)
          if (!notification || notification.read) return state

          return {
            notifications: state.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
            unreadCount: state.unreadCount - 1,
          }
        })
      },
      markAllAsRead: () => {
        set((state) => ({
          notifications: state.notifications.map((n) => ({ ...n, read: true })),
          unreadCount: 0,
        }))
      },
      clearNotifications: () => {
        set({
          notifications: [],
          unreadCount: 0,
        })
      },
    }),
    {
      name: "notifications-storage",
    },
  ),
)

