"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, ShieldAlert, ShieldCheck, Smartphone, Laptop, Tablet, Globe, Clock, MapPin } from "lucide-react"
import { useAuth } from "@/lib/auth"
import { sendEmail } from "@/lib/email-service"

// Mock login sessions for demo
const mockSessions = [
  {
    id: "current",
    device: "Chrome on Windows",
    deviceType: "desktop",
    location: "New York, NY, USA",
    ip: "192.168.1.1",
    lastActive: "Just now",
    isCurrent: true,
  },
  {
    id: "s1",
    device: "Safari on iPhone",
    deviceType: "mobile",
    location: "Boston, MA, USA",
    ip: "192.168.1.2",
    lastActive: "2 hours ago",
    isCurrent: false,
  },
  {
    id: "s2",
    device: "Firefox on macOS",
    deviceType: "desktop",
    location: "San Francisco, CA, USA",
    ip: "192.168.1.3",
    lastActive: "Yesterday",
    isCurrent: false,
  },
  {
    id: "s3",
    device: "Chrome on Android",
    deviceType: "mobile",
    location: "Chicago, IL, USA",
    ip: "192.168.1.4",
    lastActive: "3 days ago",
    isCurrent: false,
  },
]

// Mock login history for demo
const mockLoginHistory = [
  {
    id: "l1",
    device: "Chrome on Windows",
    deviceType: "desktop",
    location: "New York, NY, USA",
    ip: "192.168.1.1",
    time: "Just now",
    status: "success",
  },
  {
    id: "l2",
    device: "Safari on iPhone",
    deviceType: "mobile",
    location: "Boston, MA, USA",
    ip: "192.168.1.2",
    time: "2 hours ago",
    status: "success",
  },
  {
    id: "l3",
    device: "Unknown Device",
    deviceType: "unknown",
    location: "Los Angeles, CA, USA",
    ip: "192.168.1.5",
    time: "Yesterday",
    status: "failed",
  },
  {
    id: "l4",
    device: "Firefox on macOS",
    deviceType: "desktop",
    location: "San Francisco, CA, USA",
    ip: "192.168.1.3",
    time: "3 days ago",
    status: "success",
  },
  {
    id: "l5",
    device: "Chrome on Android",
    deviceType: "mobile",
    location: "Chicago, IL, USA",
    ip: "192.168.1.4",
    time: "5 days ago",
    status: "success",
  },
]

export function SecuritySettings() {
  const { toast } = useToast()
  const { user, logout } = useAuth()
  const [isLoading, setIsLoading] = useState(false)
  const [isRevokingSession, setIsRevokingSession] = useState(false)
  const [isLoggingOutAll, setIsLoggingOutAll] = useState(false)
  const [sessions, setSessions] = useState(mockSessions)
  const [loginHistory, setLoginHistory] = useState(mockLoginHistory)

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const [securitySettings, setSecuritySettings] = useState({
    twoFactorEnabled: false,
    twoFactorMethod: "app",
  })

  const handlePasswordChange = (field: string, value: string) => {
    setPasswordForm((prev) => ({ ...prev, [field]: value }))
  }

  const handleUpdatePassword = () => {
    // Validate passwords
    if (!passwordForm.currentPassword) {
      toast({
        title: "Current password required",
        description: "Please enter your current password.",
        variant: "destructive",
      })
      return
    }

    if (!passwordForm.newPassword) {
      toast({
        title: "New password required",
        description: "Please enter a new password.",
        variant: "destructive",
      })
      return
    }

    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "New password and confirmation password must match.",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    // Simulate API call
    setTimeout(async () => {
      try {
        // Reset form
        setPasswordForm({
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        })

        // Send password change notification email
        if (user?.email) {
          await sendEmail({
            to: user.email,
            template: "security-alert",
            subject: "Your password has been changed",
            data: {
              time: new Date().toLocaleString(),
              ip: "192.168.1.1", // This would normally come from the server
              location: "Unknown Location", // This would normally be resolved from the IP
              device: "Unknown Device", // This would normally be parsed from user agent
            },
          })
        }

        toast({
          title: "Password updated",
          description: "Your password has been updated successfully.",
        })
      } catch (error) {
        toast({
          title: "Update failed",
          description: "An error occurred while updating your password. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }, 1500)
  }

  const handleToggle2FA = () => {
    setSecuritySettings((prev) => ({
      ...prev,
      twoFactorEnabled: !prev.twoFactorEnabled,
    }))

    toast({
      title: securitySettings.twoFactorEnabled ? "2FA Disabled" : "2FA Enabled",
      description: securitySettings.twoFactorEnabled
        ? "Two-factor authentication has been disabled."
        : "Two-factor authentication has been enabled for your account.",
    })
  }

  const handleChange2FAMethod = (value: string) => {
    setSecuritySettings((prev) => ({ ...prev, twoFactorMethod: value }))
  }

  const handleRevokeSession = async (sessionId: string) => {
    setIsRevokingSession(true)

    // Simulate API call
    setTimeout(async () => {
      try {
        // Remove the session
        setSessions((prev) => prev.filter((session) => session.id !== sessionId))

        // Send security alert email
        if (user?.email) {
          await sendEmail({
            to: user.email,
            template: "security-alert",
            subject: "Session Revoked",
            data: {
              time: new Date().toLocaleString(),
              action: "Session Revoked",
              device: sessions.find((s) => s.id === sessionId)?.device || "Unknown Device",
              location: sessions.find((s) => s.id === sessionId)?.location || "Unknown Location",
            },
          })
        }

        toast({
          title: "Session revoked",
          description: "The selected session has been revoked successfully.",
        })
      } catch (error) {
        toast({
          title: "Revoke failed",
          description: "An error occurred while revoking the session. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsRevokingSession(false)
      }
    }, 1000)
  }

  const handleLogoutAllSessions = async () => {
    setIsLoggingOutAll(true)

    // Simulate API call
    setTimeout(async () => {
      try {
        // Keep only current session
        setSessions((prev) => prev.filter((session) => session.isCurrent))

        // Send security alert email
        if (user?.email) {
          await sendEmail({
            to: user.email,
            template: "security-alert",
            subject: "All Other Sessions Logged Out",
            data: {
              time: new Date().toLocaleString(),
              action: "All Other Sessions Logged Out",
            },
          })
        }

        toast({
          title: "All sessions logged out",
          description: "All other sessions have been logged out successfully.",
        })
      } catch (error) {
        toast({
          title: "Logout failed",
          description: "An error occurred while logging out all sessions. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoggingOutAll(false)
      }
    }, 1500)
  }

  const handleLogout = () => {
    // Send logout notification
    if (user?.email) {
      sendEmail({
        to: user.email,
        template: "security-alert",
        subject: "You have been logged out",
        data: {
          time: new Date().toLocaleString(),
          action: "Logout",
          device: "Current Device",
        },
      })
    }

    // Perform logout
    logout()

    // Redirect to login page
    window.location.href = "/login"
  }

  const getDeviceIcon = (deviceType: string) => {
    switch (deviceType) {
      case "mobile":
        return <Smartphone className="h-5 w-5 text-primary" />
      case "tablet":
        return <Tablet className="h-5 w-5 text-primary" />
      case "desktop":
      default:
        return <Laptop className="h-5 w-5 text-primary" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Change Password</h3>
          <p className="text-sm text-muted-foreground">Update your password to keep your account secure</p>
        </div>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="current-password">Current Password</Label>
            <Input
              id="current-password"
              type="password"
              value={passwordForm.currentPassword}
              onChange={(e) => handlePasswordChange("currentPassword", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="new-password">New Password</Label>
            <Input
              id="new-password"
              type="password"
              value={passwordForm.newPassword}
              onChange={(e) => handlePasswordChange("newPassword", e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirm-password">Confirm New Password</Label>
            <Input
              id="confirm-password"
              type="password"
              value={passwordForm.confirmPassword}
              onChange={(e) => handlePasswordChange("confirmPassword", e.target.value)}
            />
          </div>

          <Button onClick={handleUpdatePassword} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Updating...
              </>
            ) : (
              "Update Password"
            )}
          </Button>
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Two-Factor Authentication</h3>
          <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="2fa">Enable Two-Factor Authentication</Label>
            <p className="text-sm text-muted-foreground">Require a verification code when logging in</p>
          </div>
          <Switch id="2fa" checked={securitySettings.twoFactorEnabled} onCheckedChange={handleToggle2FA} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="2fa-method">Authentication Method</Label>
          <Select
            value={securitySettings.twoFactorMethod}
            onValueChange={handleChange2FAMethod}
            disabled={!securitySettings.twoFactorEnabled}
          >
            <SelectTrigger id="2fa-method">
              <SelectValue placeholder="Select method" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="app">Authenticator App</SelectItem>
              <SelectItem value="sms">SMS</SelectItem>
              <SelectItem value="email">Email</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Active Sessions</h3>
          <p className="text-sm text-muted-foreground">Manage your active login sessions</p>
        </div>

        <div className="rounded-md border">
          {sessions.map((session) => (
            <div key={session.id} className="border-b last:border-0">
              <div className="flex items-center justify-between p-4">
                <div className="flex items-start gap-3">
                  {getDeviceIcon(session.deviceType)}
                  <div>
                    <div className="font-medium flex items-center gap-2">
                      {session.device}
                      {session.isCurrent && (
                        <Badge variant="outline" className="bg-green-100 text-green-800">
                          Current
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-1">
                      <MapPin className="h-3 w-3" /> {session.location}
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <Globe className="h-3 w-3" /> {session.ip}
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" /> Last active: {session.lastActive}
                    </div>
                  </div>
                </div>
                <div>
                  {session.isCurrent ? (
                    <Button variant="destructive" size="sm" onClick={handleLogout}>
                      Log Out
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleRevokeSession(session.id)}
                      disabled={isRevokingSession}
                    >
                      {isRevokingSession ? "Revoking..." : "Revoke"}
                    </Button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <Button variant="outline" onClick={handleLogoutAllSessions} disabled={isLoggingOutAll || sessions.length <= 1}>
          {isLoggingOutAll ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Logging out...
            </>
          ) : (
            "Log Out All Other Sessions"
          )}
        </Button>
      </div>

      <Separator />

      <div className="space-y-4">
        <div className="space-y-2">
          <h3 className="text-lg font-medium">Recent Login Activity</h3>
          <p className="text-sm text-muted-foreground">Monitor recent activity on your account</p>
        </div>

        <div className="rounded-md border">
          {loginHistory.map((login) => (
            <div key={login.id} className="border-b last:border-0">
              <div className="flex items-center justify-between p-4">
                <div className="flex items-start gap-3">
                  {login.status === "success" ? (
                    <ShieldCheck className="h-5 w-5 text-green-500" />
                  ) : (
                    <ShieldAlert className="h-5 w-5 text-red-500" />
                  )}
                  <div>
                    <div className="font-medium flex items-center gap-2">
                      {login.device}
                      <Badge
                        variant={login.status === "success" ? "outline" : "destructive"}
                        className={login.status === "success" ? "bg-green-100 text-green-800" : ""}
                      >
                        {login.status === "success" ? "Successful" : "Failed"}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground flex items-center gap-1">
                      <MapPin className="h-3 w-3" /> {login.location}
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                      <Globe className="h-3 w-3" /> {login.ip}
                    </div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" /> {login.time}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <Button variant="outline">View Full Activity Log</Button>
      </div>
    </div>
  )
}

