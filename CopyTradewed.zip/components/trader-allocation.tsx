"use client"

import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"

export function TraderAllocation() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [allocations, setAllocations] = useState([
    { traderId: 1, allocation: 50 },
    { traderId: 2, allocation: 30 },
    { traderId: 3, allocation: 20 },
  ])

  const handleAllocationChange = (traderId: number, value: number) => {
    setAllocations((prev) => prev.map((item) => (item.traderId === traderId ? { ...item, allocation: value } : item)))
  }

  const handleSaveSettings = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      try {
        toast({
          title: "Allocations saved",
          description: "Your trader allocations have been updated successfully.",
        })
      } catch (error) {
        toast({
          title: "Save failed",
          description: "An error occurred while saving your allocations. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label>Capital Allocation</Label>
        <p className="text-sm text-muted-foreground">Distribute your capital among the traders you follow</p>
      </div>

      {allocations.map((allocation) => (
        <div key={allocation.traderId} className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>Trader {allocation.traderId}</Label>
            <span>{allocation.allocation}%</span>
          </div>
          <Slider
            value={[allocation.allocation]}
            min={0}
            max={100}
            step={1}
            onValueChange={(value) => handleAllocationChange(allocation.traderId, value[0])}
          />
        </div>
      ))}

      <div className="flex justify-end">
        <Button onClick={handleSaveSettings} disabled={isLoading}>
          Save Allocations
        </Button>
      </div>
    </div>
  )
}

