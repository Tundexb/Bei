import { CheckCircle2, ExternalLink } from "lucide-react"
import Link from "next/link"

interface CompletionStepProps {
  onboardingData: any
  updateOnboardingData: (data: any) => void
}

export function CompletionStep({ onboardingData, updateOnboardingData }: CompletionStepProps) {
  // Calculate completion percentage
  const completedSteps = [
    onboardingData.profileComplete,
    onboardingData.riskProfile !== null,
    onboardingData.brokerConnected,
    onboardingData.followedTraders && onboardingData.followedTraders.length > 0,
    onboardingData.copyTradingEnabled,
  ].filter(Boolean).length

  const totalSteps = 7
  const completionPercentage = Math.round((completedSteps / totalSteps) * 100)

  return (
    <div className="space-y-6 text-center">
      <div className="flex flex-col items-center">
        <div className="rounded-full bg-green-100 p-3 mb-4">
          <CheckCircle2 className="h-10 w-10 text-green-600" />
        </div>
        <h2 className="text-2xl font-bold">Setup Complete!</h2>
        <p className="text-muted-foreground mt-2">You've completed {completionPercentage}% of your account setup</p>
      </div>

      <div className="space-y-4 mt-6 text-left">
        <h3 className="font-medium">Here's what you've accomplished:</h3>
        <ul className="space-y-2">
          <li className="flex items-center">
            <CheckCircle2
              className={`mr-2 h-4 w-4 ${onboardingData.profileComplete ? "text-green-600" : "text-gray-300"}`}
            />
            <span className={onboardingData.profileComplete ? "" : "text-muted-foreground"}>Set up your profile</span>
          </li>
          <li className="flex items-center">
            <CheckCircle2
              className={`mr-2 h-4 w-4 ${onboardingData.riskProfile ? "text-green-600" : "text-gray-300"}`}
            />
            <span className={onboardingData.riskProfile ? "" : "text-muted-foreground"}>
              Completed risk assessment
              {onboardingData.riskProfile && (
                <span className="ml-1 text-sm text-muted-foreground">(Your profile: {onboardingData.riskProfile})</span>
              )}
            </span>
          </li>
          <li className="flex items-center">
            <CheckCircle2
              className={`mr-2 h-4 w-4 ${onboardingData.brokerConnected ? "text-green-600" : "text-gray-300"}`}
            />
            <span className={onboardingData.brokerConnected ? "" : "text-muted-foreground"}>Connected your broker</span>
          </li>
          <li className="flex items-center">
            <CheckCircle2
              className={`mr-2 h-4 w-4 ${
                onboardingData.followedTraders && onboardingData.followedTraders.length > 0
                  ? "text-green-600"
                  : "text-gray-300"
              }`}
            />
            <span
              className={
                onboardingData.followedTraders && onboardingData.followedTraders.length > 0
                  ? ""
                  : "text-muted-foreground"
              }
            >
              Found traders to follow
              {onboardingData.followedTraders && onboardingData.followedTraders.length > 0 && (
                <span className="ml-1 text-sm text-muted-foreground">
                  ({onboardingData.followedTraders.length} traders)
                </span>
              )}
            </span>
          </li>
          <li className="flex items-center">
            <CheckCircle2
              className={`mr-2 h-4 w-4 ${onboardingData.copyTradingEnabled ? "text-green-600" : "text-gray-300"}`}
            />
            <span className={onboardingData.copyTradingEnabled ? "" : "text-muted-foreground"}>
              Set up copy trading
            </span>
          </li>
        </ul>
      </div>

      <div className="bg-muted p-4 rounded-lg mt-6 text-left">
        <h3 className="font-medium mb-2">Next Steps</h3>
        <ul className="space-y-2 text-sm">
          <li className="flex items-center">
            <ExternalLink className="mr-2 h-4 w-4 text-primary" />
            <Link href="/dashboard" className="text-primary hover:underline">
              Go to your dashboard to monitor your portfolio
            </Link>
          </li>
          <li className="flex items-center">
            <ExternalLink className="mr-2 h-4 w-4 text-primary" />
            <Link href="/dashboard/market" className="text-primary hover:underline">
              Explore the markets and add assets to your watchlist
            </Link>
          </li>
          <li className="flex items-center">
            <ExternalLink className="mr-2 h-4 w-4 text-primary" />
            <Link href="/dashboard/settings" className="text-primary hover:underline">
              Customize your account settings
            </Link>
          </li>
        </ul>
      </div>
    </div>
  )
}

