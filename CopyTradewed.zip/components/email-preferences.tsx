"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"
import { useAuth } from "@/lib/auth"

export function EmailPreferences() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [preferences, setPreferences] = useState({
    emailNotifications: true,
    loginAlerts: true,
    tradeExecutions: true,
    positionUpdates: true,
    securityAlerts: true,
    marketingEmails: false,
    newsletterFrequency: "weekly",
    digestFrequency: "daily",
  })

  const handleToggle = (setting: string) => {
    setPreferences((prev) => ({ ...prev, [setting]: !prev[setting] }))
  }

  const handleChange = (setting: string, value: string) => {
    setPreferences((prev) => ({ ...prev, [setting]: value }))
  }

  const handleSavePreferences = () => {
    setIsLoading(true)

    // Simulate API call
    setTimeout(() => {
      try {
        toast({
          title: "Email preferences saved",
          description: "Your email notification preferences have been updated successfully.",
        })
      } catch (error) {
        toast({
          title: "Save failed",
          description: "An error occurred while saving your preferences. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }, 1000)
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h3 className="text-lg font-medium">Email Notifications</h3>
        <p className="text-sm text-muted-foreground">Manage the emails you receive from TradeCopy</p>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="email-notifications">All Email Notifications</Label>
            <p className="text-sm text-muted-foreground">Enable or disable all email notifications</p>
          </div>
          <Switch
            id="email-notifications"
            checked={preferences.emailNotifications}
            onCheckedChange={() => handleToggle("emailNotifications")}
          />
        </div>

        <Separator />

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="login-alerts">Login Alerts</Label>
              <p className="text-sm text-muted-foreground">Receive an email when a new login is detected</p>
            </div>
            <Switch
              id="login-alerts"
              checked={preferences.loginAlerts}
              onCheckedChange={() => handleToggle("loginAlerts")}
              disabled={!preferences.emailNotifications}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="trade-executions">Trade Executions</Label>
              <p className="text-sm text-muted-foreground">Receive an email when a trade is executed</p>
            </div>
            <Switch
              id="trade-executions"
              checked={preferences.tradeExecutions}
              onCheckedChange={() => handleToggle("tradeExecutions")}
              disabled={!preferences.emailNotifications}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="position-updates">Position Updates</Label>
              <p className="text-sm text-muted-foreground">Receive an email when a position is opened or closed</p>
            </div>
            <Switch
              id="position-updates"
              checked={preferences.positionUpdates}
              onCheckedChange={() => handleToggle("positionUpdates")}
              disabled={!preferences.emailNotifications}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="security-alerts">Security Alerts</Label>
              <p className="text-sm text-muted-foreground">Receive an email for important security events</p>
            </div>
            <Switch
              id="security-alerts"
              checked={preferences.securityAlerts}
              onCheckedChange={() => handleToggle("securityAlerts")}
              disabled={!preferences.emailNotifications}
            />
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="marketing-emails">Marketing Emails</Label>
              <p className="text-sm text-muted-foreground">Receive promotional emails and special offers</p>
            </div>
            <Switch
              id="marketing-emails"
              checked={preferences.marketingEmails}
              onCheckedChange={() => handleToggle("marketingEmails")}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="newsletter-frequency">Newsletter Frequency</Label>
            <Select
              value={preferences.newsletterFrequency}
              onValueChange={(value) => handleChange("newsletterFrequency", value)}
              disabled={!preferences.marketingEmails}
            >
              <SelectTrigger id="newsletter-frequency">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="weekly">Weekly</SelectItem>
                <SelectItem value="biweekly">Bi-weekly</SelectItem>
                <SelectItem value="monthly">Monthly</SelectItem>
                <SelectItem value="never">Never</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Separator />

        <div className="space-y-2">
          <Label htmlFor="digest-frequency">Activity Digest Frequency</Label>
          <Select
            value={preferences.digestFrequency}
            onValueChange={(value) => handleChange("digestFrequency", value)}
            disabled={!preferences.emailNotifications}
          >
            <SelectTrigger id="digest-frequency">
              <SelectValue placeholder="Select frequency" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="never">Never</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground mt-1">
            Receive a summary of your account activity and performance
          </p>
        </div>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleSavePreferences} disabled={isLoading}>
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            "Save Preferences"
          )}
        </Button>
      </div>
    </div>
  )
}

