"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { CheckCircle, XCircle, Eye } from "lucide-react"

type VerificationStatus = "pending" | "approved" | "rejected"

interface TraderVerificationRequest {
  id: string
  traderId: string
  traderName: string
  submittedDate: string
  status: VerificationStatus
  documents: {
    type: string
    url: string
  }[]
  tradingExperience: string
  strategy: string
}

export function TraderVerification() {
  const [verificationRequests, setVerificationRequests] = useState<TraderVerificationRequest[]>([
    {
      id: "vr-001",
      traderId: "trader-123",
      traderName: "Alex Johnson",
      submittedDate: "2023-11-15",
      status: "pending",
      documents: [
        { type: "ID Verification", url: "#" },
        { type: "Trading Certificate", url: "#" },
      ],
      tradingExperience: "5+ years in forex trading",
      strategy: "Swing trading with technical analysis",
    },
    {
      id: "vr-002",
      traderId: "trader-456",
      traderName: "Sarah Williams",
      submittedDate: "2023-11-14",
      status: "approved",
      documents: [
        { type: "ID Verification", url: "#" },
        { type: "Trading Certificate", url: "#" },
        { type: "Performance History", url: "#" },
      ],
      tradingExperience: "8 years in crypto and forex",
      strategy: "Scalping with market sentiment analysis",
    },
    {
      id: "vr-003",
      traderId: "trader-789",
      traderName: "Michael Chen",
      submittedDate: "2023-11-13",
      status: "rejected",
      documents: [{ type: "ID Verification", url: "#" }],
      tradingExperience: "3 years in stock trading",
      strategy: "Position trading with fundamental analysis",
    },
  ])

  const [selectedRequest, setSelectedRequest] = useState<TraderVerificationRequest | null>(null)
  const [viewDialogOpen, setViewDialogOpen] = useState(false)

  const handleStatusChange = (id: string, newStatus: VerificationStatus) => {
    setVerificationRequests((prev) =>
      prev.map((request) => (request.id === id ? { ...request, status: newStatus } : request)),
    )
    setViewDialogOpen(false)
  }

  const getStatusBadge = (status: VerificationStatus) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800">
            Pending
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="bg-green-100 text-green-800">
            Approved
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-red-100 text-red-800">
            Rejected
          </Badge>
        )
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-xl font-bold">Trader Verification Requests</CardTitle>
        <CardDescription>Review and approve trader verification requests</CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Trader</TableHead>
              <TableHead>Submitted</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Documents</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {verificationRequests.map((request) => (
              <TableRow key={request.id}>
                <TableCell className="font-medium">{request.traderName}</TableCell>
                <TableCell>{request.submittedDate}</TableCell>
                <TableCell>{getStatusBadge(request.status)}</TableCell>
                <TableCell>{request.documents.length}</TableCell>
                <TableCell className="text-right">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setSelectedRequest(request)
                      setViewDialogOpen(true)
                    }}
                  >
                    <Eye className="h-4 w-4" />
                    <span className="sr-only">View details</span>
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>

      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        {selectedRequest && (
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Verification Request: {selectedRequest.traderName}</DialogTitle>
              <DialogDescription>Submitted on {selectedRequest.submittedDate}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div>
                <h3 className="font-medium mb-2">Status</h3>
                <p>{getStatusBadge(selectedRequest.status)}</p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Trading Experience</h3>
                <p>{selectedRequest.tradingExperience}</p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Trading Strategy</h3>
                <p>{selectedRequest.strategy}</p>
              </div>
              <div>
                <h3 className="font-medium mb-2">Documents</h3>
                <ul className="list-disc pl-5">
                  {selectedRequest.documents.map((doc, index) => (
                    <li key={index} className="mb-1">
                      <a href={doc.url} className="text-blue-600 hover:underline">
                        {doc.type}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <DialogFooter className="flex justify-between">
              {selectedRequest.status === "pending" && (
                <>
                  <Button variant="destructive" onClick={() => handleStatusChange(selectedRequest.id, "rejected")}>
                    <XCircle className="mr-2 h-4 w-4" />
                    Reject
                  </Button>
                  <Button onClick={() => handleStatusChange(selectedRequest.id, "approved")}>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Approve
                  </Button>
                </>
              )}
              {selectedRequest.status !== "pending" && <Button onClick={() => setViewDialogOpen(false)}>Close</Button>}
            </DialogFooter>
          </DialogContent>
        )}
      </Dialog>
    </Card>
  )
}

