"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useBrokerIntegration } from "@/lib/broker-integration"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle, ArrowRight, Check, ExternalLink, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface BrokerConnectionStepProps {
  onboardingData: any
  updateOnboardingData: (data: any) => void
}

export function BrokerConnectionStep({ onboardingData, updateOnboardingData }: BrokerConnectionStepProps) {
  const { availableBrokers, connectBroker } = useBrokerIntegration()
  const { toast } = useToast()

  const [selectedBroker, setSelectedBroker] = useState<string | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)

  const handleSelectBroker = (brokerId: string) => {
    setSelectedBroker(brokerId)
  }

  const handleConnectBroker = async () => {
    if (!selectedBroker) return

    setIsConnecting(true)

    try {
      // Connect to the selected broker
      const result = await connectBroker(selectedBroker as any, "oauth", {})

      if (result.success) {
        // Update onboarding data
        updateOnboardingData({ brokerConnected: true })

        toast({
          title: "Broker connected",
          description: "Your broker account has been successfully connected.",
        })
      } else {
        toast({
          title: "Connection failed",
          description: result.error || "Failed to connect broker. Please try again.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Connection error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsConnecting(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold">Connect Your Broker</h2>
        <p className="text-muted-foreground">Link your brokerage account to enable automatic trade copying</p>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Secure Connection</AlertTitle>
        <AlertDescription>
          We use OAuth to securely connect to your broker without storing your credentials. You can revoke access at any
          time.
        </AlertDescription>
      </Alert>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {availableBrokers.slice(0, 6).map((broker) => (
          <Card
            key={broker.id}
            className={`cursor-pointer transition-all hover:border-primary ${
              selectedBroker === broker.id ? "border-2 border-primary" : ""
            }`}
            onClick={() => handleSelectBroker(broker.id)}
          >
            <CardContent className="p-4 flex flex-col items-center text-center">
              <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                <img src={broker.logo || "/placeholder.svg"} alt={broker.name} className="h-8 w-8 object-contain" />
              </div>
              <h3 className="font-medium">{broker.name}</h3>
              <p className="text-xs text-muted-foreground">{broker.description}</p>

              {selectedBroker === broker.id && (
                <div className="mt-3">
                  <Check className="h-5 w-5 text-primary mx-auto" />
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-between items-center">
        <Button variant="outline" onClick={() => window.open("/supported-brokers", "_blank")} className="gap-2">
          View all supported brokers
          <ExternalLink className="ml-2 h-4 w-4" />
        </Button>

        <Button onClick={handleConnectBroker} disabled={!selectedBroker || isConnecting} className="gap-2">
          {isConnecting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Connecting...
            </>
          ) : (
            <>
              Connect Broker
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </Button>
      </div>

      <div className="text-sm text-muted-foreground mt-4">
        <p>
          Don't see your broker?{" "}
          <a href="#" className="text-primary hover:underline">
            Request a new integration
          </a>
        </p>
      </div>
    </div>
  )
}

