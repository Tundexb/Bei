"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  BookOpen,
  Search,
  Play,
  FileText,
  BarChart2,
  Briefcase,
  CreditCard,
  Bitcoin,
  ChevronRight,
  Clock,
  Star,
  BookmarkPlus,
} from "lucide-react"
import Image from "next/image"
import Link from "next/link"

// Sample education content
const educationContent = {
  beginner: [
    {
      id: 1,
      title: "Introduction to Copy Trading",
      description: "Learn the basics of copy trading and how to get started",
      type: "video",
      duration: "12 min",
      thumbnail: "/education/intro-copy-trading.jpg",
      category: "general",
      popular: true,
    },
    {
      id: 2,
      title: "Understanding Stock Markets",
      description: "A beginner's guide to stock markets and how they work",
      type: "article",
      duration: "8 min read",
      thumbnail: "/education/stock-markets.jpg",
      category: "stocks",
      popular: true,
    },
    {
      id: 3,
      title: "Forex Trading Fundamentals",
      description: "Learn the basics of forex trading and currency pairs",
      type: "video",
      duration: "15 min",
      thumbnail: "/education/forex-fundamentals.jpg",
      category: "forex",
      popular: false,
    },
    {
      id: 4,
      title: "Cryptocurrency Basics",
      description: "Understanding blockchain and cryptocurrency markets",
      type: "article",
      duration: "10 min read",
      thumbnail: "/education/crypto-basics.jpg",
      category: "crypto",
      popular: true,
    },
  ],
  intermediate: [
    {
      id: 5,
      title: "Technical Analysis Fundamentals",
      description: "Learn how to read charts and identify patterns",
      type: "course",
      duration: "1.5 hours",
      thumbnail: "/education/technical-analysis.jpg",
      category: "general",
      popular: true,
    },
    {
      id: 6,
      title: "Risk Management Strategies",
      description: "Protect your capital with proper risk management",
      type: "article",
      duration: "12 min read",
      thumbnail: "/education/risk-management.jpg",
      category: "general",
      popular: true,
    },
    {
      id: 7,
      title: "Options Trading Strategies",
      description: "Learn about calls, puts, and options strategies",
      type: "video",
      duration: "25 min",
      thumbnail: "/education/options-trading.jpg",
      category: "stocks",
      popular: false,
    },
    {
      id: 8,
      title: "Understanding Leverage in Forex",
      description: "How to use leverage responsibly in forex trading",
      type: "article",
      duration: "15 min read",
      thumbnail: "/education/forex-leverage.jpg",
      category: "forex",
      popular: true,
    },
  ],
  advanced: [
    {
      id: 9,
      title: "Advanced Chart Patterns",
      description: "Master complex chart patterns for better entries and exits",
      type: "course",
      duration: "2 hours",
      thumbnail: "/education/advanced-charts.jpg",
      category: "general",
      popular: true,
    },
    {
      id: 10,
      title: "Algorithmic Trading Basics",
      description: "Introduction to automated trading strategies",
      type: "video",
      duration: "30 min",
      thumbnail: "/education/algo-trading.jpg",
      category: "general",
      popular: false,
    },
    {
      id: 11,
      title: "Advanced Options Strategies",
      description: "Complex options strategies for experienced traders",
      type: "course",
      duration: "3 hours",
      thumbnail: "/education/advanced-options.jpg",
      category: "stocks",
      popular: true,
    },
    {
      id: 12,
      title: "DeFi and Yield Farming",
      description: "Advanced cryptocurrency concepts and DeFi protocols",
      type: "article",
      duration: "20 min read",
      thumbnail: "/education/defi-yield.jpg",
      category: "crypto",
      popular: true,
    },
  ],
  brokerGuides: [
    {
      id: 13,
      title: "How to Connect Your Schwab Account",
      description: "Step-by-step guide to connecting your Schwab brokerage account",
      type: "guide",
      duration: "5 min read",
      thumbnail: "/brokers/schwab.png",
      category: "stocks",
      popular: false,
    },
    {
      id: 14,
      title: "Setting Up OANDA API Access",
      description: "Complete guide to generating and using OANDA API keys",
      type: "guide",
      duration: "8 min read",
      thumbnail: "/brokers/oanda.png",
      category: "forex",
      popular: true,
    },
    {
      id: 15,
      title: "Connecting Binance to Copy Trading Platform",
      description: "Secure your Binance account while enabling copy trading",
      type: "video",
      duration: "10 min",
      thumbnail: "/brokers/binance.png",
      category: "crypto",
      popular: true,
    },
    {
      id: 16,
      title: "Interactive Brokers Integration Guide",
      description: "Complete walkthrough for IBKR account connection",
      type: "guide",
      duration: "7 min read",
      thumbnail: "/brokers/interactive-brokers.png",
      category: "stocks",
      popular: false,
    },
  ],
}

export function EducationCenter() {
  const [activeTab, setActiveTab] = useState("beginner")
  const [activeCategory, setActiveCategory] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")

  const getContentTypeIcon = (type: string) => {
    switch (type) {
      case "video":
        return <Play className="h-4 w-4" />
      case "article":
        return <FileText className="h-4 w-4" />
      case "course":
        return <BookOpen className="h-4 w-4" />
      case "guide":
        return <FileText className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "stocks":
        return <Briefcase className="h-4 w-4" />
      case "forex":
        return <CreditCard className="h-4 w-4" />
      case "crypto":
        return <Bitcoin className="h-4 w-4" />
      case "general":
        return <BarChart2 className="h-4 w-4" />
      default:
        return <BarChart2 className="h-4 w-4" />
    }
  }

  const filterContent = (content: any[]) => {
    let filtered = content

    // Filter by category
    if (activeCategory !== "all") {
      filtered = filtered.filter((item) => item.category === activeCategory)
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (item) => item.title.toLowerCase().includes(query) || item.description.toLowerCase().includes(query),
      )
    }

    return filtered
  }

  const currentContent = educationContent[activeTab as keyof typeof educationContent] || []
  const filteredContent = filterContent(currentContent)

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Education Center</h2>
          <p className="text-muted-foreground mt-1">Learn trading concepts and how to use the platform</p>
        </div>
        <div className="relative w-full sm:w-auto">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search resources..."
            className="w-full sm:w-[300px] pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="beginner" value={activeTab} onValueChange={setActiveTab}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <TabsList>
            <TabsTrigger value="beginner" className="flex items-center">
              <BookOpen className="mr-2 h-4 w-4" />
              Beginner
            </TabsTrigger>
            <TabsTrigger value="intermediate" className="flex items-center">
              <BarChart2 className="mr-2 h-4 w-4" />
              Intermediate
            </TabsTrigger>
            <TabsTrigger value="advanced" className="flex items-center">
              <Star className="mr-2 h-4 w-4" />
              Advanced
            </TabsTrigger>
            <TabsTrigger value="brokerGuides" className="flex items-center">
              <Briefcase className="mr-2 h-4 w-4" />
              Broker Guides
            </TabsTrigger>
          </TabsList>

          <div className="flex">
            <TabsList>
              <TabsTrigger
                value="all"
                onClick={() => setActiveCategory("all")}
                className={activeCategory === "all" ? "bg-primary text-primary-foreground" : ""}
              >
                All
              </TabsTrigger>
              <TabsTrigger
                value="stocks"
                onClick={() => setActiveCategory("stocks")}
                className={activeCategory === "stocks" ? "bg-primary text-primary-foreground" : ""}
              >
                <Briefcase className="mr-2 h-4 w-4" />
                Stocks
              </TabsTrigger>
              <TabsTrigger
                value="forex"
                onClick={() => setActiveCategory("forex")}
                className={activeCategory === "forex" ? "bg-primary text-primary-foreground" : ""}
              >
                <CreditCard className="mr-2 h-4 w-4" />
                Forex
              </TabsTrigger>
              <TabsTrigger
                value="crypto"
                onClick={() => setActiveCategory("crypto")}
                className={activeCategory === "crypto" ? "bg-primary text-primary-foreground" : ""}
              >
                <Bitcoin className="mr-2 h-4 w-4" />
                Crypto
              </TabsTrigger>
            </TabsList>
          </div>
        </div>

        <div className="mt-6">
          {filteredContent.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No resources found matching your criteria.</p>
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => {
                  setSearchQuery("")
                  setActiveCategory("all")
                }}
              >
                Clear filters
              </Button>
            </div>
          ) : (
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredContent.map((item) => (
                <Card key={item.id} className="overflow-hidden">
                  <div className="aspect-video relative bg-muted">
                    <Image
                      src={item.thumbnail || "/placeholder.svg?height=200&width=300"}
                      alt={item.title}
                      fill
                      className="object-cover"
                    />
                    <div className="absolute top-2 right-2 flex gap-2">
                      <Badge variant="secondary" className="flex items-center gap-1">
                        {getContentTypeIcon(item.type)}
                        {item.type}
                      </Badge>
                      {item.popular && (
                        <Badge className="bg-yellow-500/20 text-yellow-700 hover:bg-yellow-500/20 flex items-center gap-1">
                          <Star className="h-3 w-3 fill-yellow-500" />
                          Popular
                        </Badge>
                      )}
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg">{item.title}</CardTitle>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <BookmarkPlus className="h-4 w-4" />
                      </Button>
                    </div>
                    <CardDescription>{item.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Badge variant="outline" className="flex items-center gap-1 mr-2">
                        {getCategoryIcon(item.category)}
                        {item.category}
                      </Badge>
                      <span className="flex items-center">
                        <Clock className="mr-1 h-3 w-3" />
                        {item.duration}
                      </span>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button asChild className="w-full">
                      <Link href={`/education/${item.id}`}>
                        View {item.type}
                        <ChevronRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </div>
      </Tabs>
    </div>
  )
}

