// This is a simple client-side auth implementation for the prototype
// In a real application, you would use a proper auth solution like NextAuth.js

import { create } from "zustand"
import { persist } from "zustand/middleware"

export type User = {
  id: string
  name: string
  email: string
  avatar?: string
  balance: number
  onboardingComplete?: boolean
}

type AuthState = {
  user: User | null
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<boolean>
  signup: (name: string, email: string, password: string) => Promise<boolean>
  logout: () => void
  updateUser: (user: Partial<User>) => void
}

// Mock user for demo purposes
const mockUser: User = {
  id: "1",
  name: "John Doe",
  email: "john.doe@example.com",
  avatar: "/placeholder.svg?height=32&width=32",
  balance: 24892,
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: async (email, password) => {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // In a real app, you would validate credentials with your backend
        if (email && password) {
          set({ user: mockUser, isAuthenticated: true })
          return true
        }
        return false
      },
      signup: async (name, email, password) => {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // In a real app, you would create a user in your backend
        if (name && email && password) {
          const newUser = { ...mockUser, name, email }
          set({ user: newUser, isAuthenticated: true })
          return true
        }
        return false
      },
      logout: () => {
        set({ user: null, isAuthenticated: false })
      },
      updateUser: (userData) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...userData } : null,
        }))
      },
    }),
    {
      name: "auth-storage",
    },
  ),
)

