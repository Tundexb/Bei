import { create } from "zustand"

type CopiedTrade = {
  originalTradeId: string
  symbol: string
  name: string
  type: "BUY" | "SELL"
  price: number
  quantity: number
  total: number
  date: string
  traderId: number
  traderName: string
}

type CopyTradingState = {
  isEnabled: boolean
  copiedTrades: CopiedTrade[]
  maxDailyLoss: number
  maxPositionSize: number
  stopLossEnabled: boolean
  stopLossPercentage: number
  takeProfitEnabled: boolean
  takeProfitPercentage: number
  traderAllocations: { traderId: number; allocation: number }[]
  toggleCopyTrading: (enabled: boolean) => void
  addCopiedTrade: (trade: CopiedTrade) => void
  updateSettings: (settings: Partial<CopyTradingState>) => void
  updateTraderAllocation: (traderId: number, allocation: number) => void
  getPerformanceData: () => PerformanceData
  autoCloseEnabled?: boolean
  autoCloseThreshold?: number
  volatilityProtection?: boolean
  volatilityThreshold?: number
  correlationProtection?: boolean
  correlationThreshold?: number
}

interface PerformanceData {
  totalCopiedTrades: number
  successfulTrades: number
  failedTrades: number
  winRate: number
  netProfitLoss: number
  totalProfit: number
  totalLoss: number
  averageProfit: number
  averageLoss: number
  profitFactor: number
  largestDrawdown: number
  dailyPerformance: { date: string; profit: number }[]
  traderPerformance: { traderId: number; traderName: string; trades: number; winRate: number; profit: number }[]
  bestTrade: number
  worstTrade: number
}

interface CopyTradingStats {
  totalCopiedTrades: number
  executedTrades: number
  pendingTrades: number
  failedTrades: number
  successRate: number
  totalVolume: number
  recentActivities: {
    id: string
    timestamp: string
    type: string
    description: string
    metadata?: Record<string, string | number>
  }[]
}

const initialCopiedTrades: CopiedTrade[] = []

const initialTraderAllocations: { traderId: number; allocation: number }[] = [
  { traderId: 1, allocation: 50 },
  { traderId: 2, allocation: 30 },
  { traderId: 3, allocation: 20 },
]

export const useCopyTrading = create<CopyTradingState>()((set, get) => ({
  isEnabled: false,
  copiedTrades: initialCopiedTrades,
  maxDailyLoss: 5,
  maxPositionSize: 10,
  stopLossEnabled: true,
  stopLossPercentage: 5,
  takeProfitEnabled: true,
  takeProfitPercentage: 10,
  traderAllocations: initialTraderAllocations,
  toggleCopyTrading: (enabled) => set({ isEnabled: enabled }),
  addCopiedTrade: (trade) => {
    set((state) => ({ copiedTrades: [trade, ...state.copiedTrades] }))
  },
  updateSettings: (settings) => {
    set(settings)
  },
  updateTraderAllocation: (traderId, allocation) => {
    set((state) => ({
      traderAllocations: state.traderAllocations.map((item) =>
        item.traderId === traderId ? { ...item, allocation } : item,
      ),
    }))
  },
  getPerformanceData: () => {
    const copiedTrades = get().copiedTrades

    const totalCopiedTrades = copiedTrades.length
    const successfulTrades = copiedTrades.filter((trade) => trade.type === "BUY").length
    const failedTrades = copiedTrades.filter((trade) => trade.type === "SELL").length
    const winRate = totalCopiedTrades > 0 ? (successfulTrades / totalCopiedTrades) * 100 : 0

    let netProfitLoss = 0
    let totalProfit = 0
    let totalLoss = 0
    let bestTrade = 0
    let worstTrade = 0

    copiedTrades.forEach((trade) => {
      const profit = trade.type === "BUY" ? trade.price * trade.quantity : -trade.price * trade.quantity
      netProfitLoss += profit

      if (profit > 0) {
        totalProfit += profit
        if (profit > bestTrade) {
          bestTrade = profit
        }
      } else {
        totalLoss += profit
        if (profit < worstTrade) {
          worstTrade = profit
        }
      }
    })

    const averageProfit = successfulTrades > 0 ? totalProfit / successfulTrades : 0
    const averageLoss = failedTrades > 0 ? totalLoss / failedTrades : 0
    const profitFactor = totalLoss !== 0 ? totalProfit / Math.abs(totalLoss) : 0
    const largestDrawdown = 10 // Mock value

    const dailyPerformance = [] // Mock value
    const traderPerformance = [] // Mock value

    return {
      totalCopiedTrades,
      successfulTrades,
      failedTrades,
      winRate,
      netProfitLoss,
      totalProfit,
      totalLoss,
      averageProfit,
      averageLoss,
      profitFactor,
      largestDrawdown,
      dailyPerformance,
      traderPerformance,
      bestTrade,
      worstTrade,
    }
  },
  autoCloseEnabled: false,
  autoCloseThreshold: 20,
  volatilityProtection: false,
  volatilityThreshold: 30,
  correlationProtection: false,
  correlationThreshold: 80,
}))

export const useCopyTradingStats = () => {
  const copiedTrades = useCopyTrading((state) => state.copiedTrades)

  const totalCopiedTrades = copiedTrades.length
  const executedTrades = copiedTrades.filter((trade) => trade.type === "BUY").length
  const pendingTrades = 0 // Mock value
  const failedTrades = copiedTrades.filter((trade) => trade.type === "SELL").length
  const successRate = totalCopiedTrades > 0 ? (executedTrades / totalCopiedTrades) * 100 : 0
  const totalVolume = copiedTrades.reduce((acc, trade) => acc + trade.price * trade.quantity, 0)

  const recentActivities = [
    {
      id: "activity-1",
      timestamp: new Date().toISOString(),
      type: "trade_copied",
      description: "Copied trade from Alex Morgan",
      metadata: {
        symbol: "AAPL",
        type: "Buy",
        price: "190.50",
      },
    },
    {
      id: "activity-2",
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      type: "settings_changed",
      description: "Updated risk management settings",
    },
  ]

  return {
    totalCopiedTrades,
    executedTrades,
    pendingTrades,
    failedTrades,
    successRate,
    totalVolume,
    recentActivities,
  }
}

import { useTraders } from "./traders"

export const simulateTraderTrade = () => {
  const { isEnabled } = useCopyTrading()
  const { traders } = useTraders()

  if (!isEnabled) return null

  const followedTraders = traders.filter((trader) => trader.following)

  if (followedTraders.length === 0) return null

  const randomTrader = followedTraders[Math.floor(Math.random() * followedTraders.length)]
  const trade = {
    symbol: "AAPL",
    name: "Apple Inc.",
    type: Math.random() > 0.5 ? "BUY" : "SELL",
    price: 190.5,
    quantity: 1,
    total: 190.5,
  }

  return { trader: randomTrader, trade }
}

