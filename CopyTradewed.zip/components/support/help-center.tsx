"use client"

import { Label } from "@/components/ui/label"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import {
  Search,
  MessageSquare,
  FileQuestion,
  BookOpen,
  Video,
  Send,
  Loader2,
  CheckCircle,
  Clock,
  AlertCircle,
  HelpCircle,
  ChevronRight,
} from "lucide-react"

export function HelpCenter() {
  const router = useRouter()
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [ticketSubject, setTicketSubject] = useState("")
  const [ticketCategory, setTicketCategory] = useState("")
  const [ticketMessage, setTicketMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!ticketSubject || !ticketCategory || !ticketMessage) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields to submit your support ticket.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: "Support ticket submitted",
      description: "We've received your ticket and will respond shortly.",
    })

    // Reset form
    setTicketSubject("")
    setTicketCategory("")
    setTicketMessage("")
    setIsSubmitting(false)
  }

  const faqCategories = [
    {
      id: "account",
      title: "Account & Profile",
      faqs: [
        {
          question: "How do I create an account?",
          answer:
            "To create an account, click on the 'Sign Up' button in the top right corner of the homepage. Fill in your details, verify your email address, and complete the registration process.",
        },
        {
          question: "How do I reset my password?",
          answer:
            "Click on 'Login', then select 'Forgot Password'. Enter your email address, and we'll send you instructions to reset your password.",
        },
        {
          question: "How do I verify my identity?",
          answer:
            "Go to your Account Settings, select 'Verification', and follow the instructions to upload your identification documents. Verification typically takes 1-2 business days.",
        },
      ],
    },
    {
      id: "copy-trading",
      title: "Copy Trading",
      faqs: [
        {
          question: "How does copy trading work?",
          answer:
            "Copy trading allows you to automatically replicate the trades of experienced traders. When a trader you follow opens a position, the same position is opened in your account proportionally to your settings.",
        },
        {
          question: "How do I start copy trading?",
          answer:
            "First, connect your broker account. Then, browse the trader leaderboard, select traders you want to follow, and configure your copy trading settings such as allocation amount and risk parameters.",
        },
        {
          question: "Can I modify copy trading settings?",
          answer:
            "Yes, you can adjust your copy trading settings at any time. Go to 'Copy Trading Settings' to modify parameters such as allocation, risk management, and automation rules.",
        },
      ],
    },
    {
      id: "brokers",
      title: "Broker Integration",
      faqs: [
        {
          question: "Which brokers are supported?",
          answer:
            "We support a wide range of brokers including Interactive Brokers, TD Ameritrade, Charles Schwab, Robinhood, E*TRADE, and many more. You can find the full list in the 'Connect Broker' section.",
        },
        {
          question: "How do I connect my broker account?",
          answer:
            "Go to 'Connect Broker' in your dashboard, select your broker from the list, and follow the authentication process. You can connect via OAuth, API keys, or credentials depending on your broker.",
        },
        {
          question: "Is my broker connection secure?",
          answer:
            "Yes, we use industry-standard encryption and security protocols to protect your broker connection. We never store your broker passwords, and you can revoke access at any time.",
        },
      ],
    },
    {
      id: "billing",
      title: "Billing & Subscription",
      faqs: [
        {
          question: "How much does the platform cost?",
          answer:
            "We offer several subscription plans starting from $9.99/month for the Basic plan. You can view all our pricing options in the 'Subscription' section.",
        },
        {
          question: "How do I cancel my subscription?",
          answer:
            "Go to 'Account Settings', select 'Subscription', and click on 'Cancel Subscription'. Your subscription will remain active until the end of the current billing period.",
        },
        {
          question: "Do you offer refunds?",
          answer:
            "We offer a 7-day money-back guarantee for new subscribers. If you're not satisfied with our service, contact support within 7 days of your initial subscription for a full refund.",
        },
      ],
    },
  ]

  const supportTickets = [
    {
      id: "TICKET-1234",
      subject: "Issue with broker connection",
      status: "open",
      created: "2023-11-20T10:30:00Z",
      lastUpdate: "2023-11-20T14:45:00Z",
    },
    {
      id: "TICKET-1233",
      subject: "Subscription payment failed",
      status: "closed",
      created: "2023-11-15T08:20:00Z",
      lastUpdate: "2023-11-17T11:15:00Z",
    },
    {
      id: "TICKET-1232",
      subject: "Question about risk management",
      status: "pending",
      created: "2023-11-10T16:40:00Z",
      lastUpdate: "2023-11-12T09:30:00Z",
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "open":
        return (
          <Badge className="bg-blue-500">
            <Clock className="mr-1 h-3 w-3" />
            Open
          </Badge>
        )
      case "pending":
        return (
          <Badge className="bg-yellow-500">
            <AlertCircle className="mr-1 h-3 w-3" />
            Pending
          </Badge>
        )
      case "closed":
        return (
          <Badge variant="outline">
            <CheckCircle className="mr-1 h-3 w-3" />
            Closed
          </Badge>
        )
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold">Help Center</h2>
        <p className="text-muted-foreground mt-2">Find answers or get support from our team</p>
      </div>

      <div className="relative max-w-2xl mx-auto">
        <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
        <Input
          placeholder="Search for help articles, FAQs, or topics..."
          className="pl-10 py-6 text-lg"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-3 max-w-5xl mx-auto">
        <Card className="cursor-pointer hover:border-primary transition-colors">
          <CardHeader className="pb-3">
            <FileQuestion className="h-8 w-8 text-primary mb-2" />
            <CardTitle>FAQs</CardTitle>
            <CardDescription>Browse frequently asked questions</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button variant="ghost" className="w-full justify-between" onClick={() => router.push("/help/faqs")}>
              View FAQs
              <ChevronRight className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>

        <Card className="cursor-pointer hover:border-primary transition-colors">
          <CardHeader className="pb-3">
            <BookOpen className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Knowledge Base</CardTitle>
            <CardDescription>Detailed guides and documentation</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button
              variant="ghost"
              className="w-full justify-between"
              onClick={() => router.push("/help/knowledge-base")}
            >
              Browse Articles
              <ChevronRight className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>

        <Card className="cursor-pointer hover:border-primary transition-colors">
          <CardHeader className="pb-3">
            <Video className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Video Tutorials</CardTitle>
            <CardDescription>Learn with step-by-step videos</CardDescription>
          </CardHeader>
          <CardFooter>
            <Button variant="ghost" className="w-full justify-between" onClick={() => router.push("/help/tutorials")}>
              Watch Tutorials
              <ChevronRight className="h-4 w-4" />
            </Button>
          </CardFooter>
        </Card>
      </div>

      <Tabs defaultValue="faqs" className="max-w-5xl mx-auto">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="faqs">
            <HelpCircle className="mr-2 h-4 w-4" />
            FAQs
          </TabsTrigger>
          <TabsTrigger value="contact">
            <MessageSquare className="mr-2 h-4 w-4" />
            Contact Support
          </TabsTrigger>
          <TabsTrigger value="tickets">
            <FileQuestion className="mr-2 h-4 w-4" />
            My Tickets
          </TabsTrigger>
        </TabsList>

        <TabsContent value="faqs" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
              <CardDescription>Find quick answers to common questions</CardDescription>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                {faqCategories.map((category) => (
                  <AccordionItem key={category.id} value={category.id}>
                    <AccordionTrigger>{category.title}</AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4 pt-2">
                        {category.faqs.map((faq, index) => (
                          <div key={index} className="space-y-2">
                            <h4 className="font-medium">{faq.question}</h4>
                            <p className="text-sm text-muted-foreground">{faq.answer}</p>
                          </div>
                        ))}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Contact Support</CardTitle>
              <CardDescription>Submit a ticket and our team will assist you</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitTicket} className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Input
                    id="subject"
                    placeholder="Brief description of your issue"
                    value={ticketSubject}
                    onChange={(e) => setTicketSubject(e.target.value)}
                    required
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={ticketCategory} onValueChange={setTicketCategory} required>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="account">Account & Profile</SelectItem>
                      <SelectItem value="copy-trading">Copy Trading</SelectItem>
                      <SelectItem value="broker">Broker Integration</SelectItem>
                      <SelectItem value="billing">Billing & Subscription</SelectItem>
                      <SelectItem value="technical">Technical Issue</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="message">Message</Label>
                  <Textarea
                    id="message"
                    placeholder="Describe your issue in detail"
                    rows={6}
                    value={ticketMessage}
                    onChange={(e) => setTicketMessage(e.target.value)}
                    required
                  />
                </div>

                <Button type="submit" className="w-full" disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Submit Ticket
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tickets" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>My Support Tickets</CardTitle>
              <CardDescription>View and manage your support requests</CardDescription>
            </CardHeader>
            <CardContent>
              {supportTickets.length > 0 ? (
                <div className="space-y-4">
                  {supportTickets.map((ticket) => (
                    <div
                      key={ticket.id}
                      className="flex items-center justify-between p-4 border rounded-md hover:bg-muted/50 cursor-pointer"
                      onClick={() => router.push(`/help/tickets/${ticket.id}`)}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{ticket.subject}</span>
                          {getStatusBadge(ticket.status)}
                        </div>
                        <div className="text-sm text-muted-foreground mt-1">
                          <span>Ticket ID: {ticket.id}</span>
                          <span className="mx-2">•</span>
                          <span>Created: {new Date(ticket.created).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <FileQuestion className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Support Tickets</h3>
                  <p className="text-sm text-muted-foreground mb-6">You haven't submitted any support tickets yet.</p>
                  <Button onClick={() => document.querySelector('[data-value="contact"]')?.click()}>
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Contact Support
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

