import { create } from "zustand"
import { persist } from "zustand/middleware"

export type MarketAsset = {
  symbol: string
  name: string
  price: number
  change: number
  changePercent: number
  volume: string
  marketCap?: string
  range?: string
  type: "stock" | "crypto" | "forex"
}

export type WatchlistItem = MarketAsset & {
  alerts: number
}

type MarketState = {
  watchlist: WatchlistItem[]
  addToWatchlist: (asset: MarketAsset) => void
  removeFromWatchlist: (symbol: string) => void
  isInWatchlist: (symbol: string) => boolean
  setAlert: (symbol: string, alertCount: number) => void
}

// Mock watchlist data
const initialWatchlist: WatchlistItem[] = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: 187.42,
    change: 1.24,
    changePercent: 0.67,
    volume: "32.5M",
    marketCap: "2.94T",
    type: "stock",
    alerts: 1,
  },
  {
    symbol: "BTC",
    name: "Bitcoin",
    price: 62487.23,
    change: 1245.67,
    changePercent: 2.03,
    volume: "$42.8B",
    marketCap: "$1.22T",
    type: "crypto",
    alerts: 2,
  },
  {
    symbol: "EUR/USD",
    name: "Euro / US Dollar",
    price: 1.0842,
    change: -0.0012,
    changePercent: -0.11,
    volume: "$98.7B",
    range: "1.0830-1.0865",
    type: "forex",
    alerts: 0,
  },
  {
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    price: 824.36,
    change: 12.45,
    changePercent: 1.53,
    volume: "42.8M",
    marketCap: "2.03T",
    type: "stock",
    alerts: 1,
  },
  {
    symbol: "ETH",
    name: "Ethereum",
    price: 3421.56,
    change: 87.34,
    changePercent: 2.62,
    volume: "$28.3B",
    marketCap: "$411.2B",
    type: "crypto",
    alerts: 0,
  },
]

export const useMarket = create<MarketState>()(
  persist(
    (set, get) => ({
      watchlist: initialWatchlist,
      addToWatchlist: (asset) => {
        if (get().isInWatchlist(asset.symbol)) return

        const watchlistItem: WatchlistItem = {
          ...asset,
          alerts: 0,
        }

        set((state) => ({
          watchlist: [...state.watchlist, watchlistItem],
        }))
      },
      removeFromWatchlist: (symbol) => {
        set((state) => ({
          watchlist: state.watchlist.filter((item) => item.symbol !== symbol),
        }))
      },
      isInWatchlist: (symbol) => {
        return get().watchlist.some((item) => item.symbol === symbol)
      },
      setAlert: (symbol, alertCount) => {
        set((state) => ({
          watchlist: state.watchlist.map((item) => (item.symbol === symbol ? { ...item, alerts: alertCount } : item)),
        }))
      },
    }),
    {
      name: "market-storage",
    },
  ),
)

