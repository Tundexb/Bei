"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { TrendingUp, Search, Filter, Star, StarOff, ChevronDown, ChevronUp, Shield, AlertTriangle } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useTraders } from "@/lib/traders"

export function EnhancedLeaderboard() {
  const router = useRouter()
  const { toast } = useToast()
  const { traders, toggleFollow } = useTraders()
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredTraders, setFilteredTraders] = useState(traders)
  const [sortField, setSortField] = useState("roi")
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc")
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState({
    minRoi: 0,
    maxRoi: 100,
    minWinRate: 0,
    maxWinRate: 100,
    riskLevels: ["Low", "Medium", "High"],
    verifiedOnly: false,
    minFollowers: 0,
    markets: ["Stocks", "Forex", "Crypto", "Commodities", "Options"],
  })

  useEffect(() => {
    applyFilters()
  }, [searchQuery, sortField, sortDirection, filters, traders])

  const applyFilters = () => {
    let result = [...traders]

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      result = result.filter(
        (trader) =>
          trader.name.toLowerCase().includes(query) ||
          trader.bio?.toLowerCase().includes(query) ||
          trader.tradingStyle?.toLowerCase().includes(query),
      )
    }

    // Apply numeric filters
    result = result.filter((trader) => {
      const roi = Number.parseFloat(trader.roi)
      const winRate = Number.parseFloat(trader.winRate)

      return (
        roi >= filters.minRoi &&
        roi <= filters.maxRoi &&
        winRate >= filters.minWinRate &&
        winRate <= filters.maxWinRate &&
        trader.followers >= filters.minFollowers &&
        (!filters.verifiedOnly || trader.verified) &&
        filters.riskLevels.includes(trader.riskLevel) &&
        (trader.markets ? trader.markets.some((market) => filters.markets.includes(market)) : true)
      )
    })

    // Apply sorting
    result.sort((a, b) => {
      let aValue, bValue

      switch (sortField) {
        case "roi":
          aValue = Number.parseFloat(a.roi)
          bValue = Number.parseFloat(b.roi)
          break
        case "winRate":
          aValue = Number.parseFloat(a.winRate)
          bValue = Number.parseFloat(b.winRate)
          break
        case "followers":
          aValue = a.followers
          bValue = b.followers
          break
        case "trades":
          aValue = a.trades
          bValue = b.trades
          break
        default:
          aValue = Number.parseFloat(a.roi)
          bValue = Number.parseFloat(b.roi)
      }

      return sortDirection === "asc" ? aValue - bValue : bValue - aValue
    })

    setFilteredTraders(result)
  }

  const handleToggleFollow = (traderId: number, traderName: string, isFollowing: boolean) => {
    toggleFollow(traderId)

    toast({
      title: isFollowing ? "Trader unfollowed" : "Trader followed",
      description: isFollowing
        ? `You are no longer following ${traderName}.`
        : `You are now following ${traderName}. Their trades will be copied to your account.`,
    })
  }

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortField(field)
      setSortDirection("desc")
    }
  }

  const renderSortIcon = (field: string) => {
    if (sortField !== field) return null

    return sortDirection === "asc" ? <ChevronUp className="h-4 w-4 ml-1" /> : <ChevronDown className="h-4 w-4 ml-1" />
  }

  const handleViewTrader = (traderId: number) => {
    router.push(`/traders/${traderId}`)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search traders by name, bio, or style..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="mr-2 h-4 w-4" />
            {showFilters ? "Hide Filters" : "Show Filters"}
          </Button>

          <Select defaultValue="roi" onValueChange={(value) => handleSort(value)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="roi">Sort by ROI</SelectItem>
              <SelectItem value="winRate">Sort by Win Rate</SelectItem>
              <SelectItem value="followers">Sort by Followers</SelectItem>
              <SelectItem value="trades">Sort by Trade Count</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {showFilters && (
        <Card>
          <CardHeader>
            <CardTitle>Advanced Filters</CardTitle>
            <CardDescription>Refine your trader search with specific criteria</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-4">
                <div>
                  <Label>ROI Range (%)</Label>
                  <div className="flex items-center gap-4">
                    <Slider
                      value={[filters.minRoi, filters.maxRoi]}
                      min={0}
                      max={100}
                      step={1}
                      onValueChange={(value) => setFilters({ ...filters, minRoi: value[0], maxRoi: value[1] })}
                      className="flex-1"
                    />
                    <span className="w-24 text-center">
                      {filters.minRoi}% - {filters.maxRoi}%
                    </span>
                  </div>
                </div>

                <div>
                  <Label>Win Rate Range (%)</Label>
                  <div className="flex items-center gap-4">
                    <Slider
                      value={[filters.minWinRate, filters.maxWinRate]}
                      min={0}
                      max={100}
                      step={1}
                      onValueChange={(value) => setFilters({ ...filters, minWinRate: value[0], maxWinRate: value[1] })}
                      className="flex-1"
                    />
                    <span className="w-24 text-center">
                      {filters.minWinRate}% - {filters.maxWinRate}%
                    </span>
                  </div>
                </div>

                <div>
                  <Label>Minimum Followers</Label>
                  <div className="flex items-center gap-4">
                    <Slider
                      value={[filters.minFollowers]}
                      min={0}
                      max={10000}
                      step={100}
                      onValueChange={(value) => setFilters({ ...filters, minFollowers: value[0] })}
                      className="flex-1"
                    />
                    <span className="w-24 text-center">{filters.minFollowers}+</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label className="mb-2 block">Risk Levels</Label>
                  <div className="flex flex-wrap gap-4">
                    {["Low", "Medium", "High"].map((risk) => (
                      <div key={risk} className="flex items-center space-x-2">
                        <Checkbox
                          id={`risk-${risk}`}
                          checked={filters.riskLevels.includes(risk)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFilters({ ...filters, riskLevels: [...filters.riskLevels, risk] })
                            } else {
                              setFilters({
                                ...filters,
                                riskLevels: filters.riskLevels.filter((r) => r !== risk),
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor={`risk-${risk}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {risk}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <Label className="mb-2 block">Markets</Label>
                  <div className="flex flex-wrap gap-4">
                    {["Stocks", "Forex", "Crypto", "Commodities", "Options"].map((market) => (
                      <div key={market} className="flex items-center space-x-2">
                        <Checkbox
                          id={`market-${market}`}
                          checked={filters.markets.includes(market)}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              setFilters({ ...filters, markets: [...filters.markets, market] })
                            } else {
                              setFilters({
                                ...filters,
                                markets: filters.markets.filter((m) => m !== market),
                              })
                            }
                          }}
                        />
                        <label
                          htmlFor={`market-${market}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {market}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="verified-only"
                    checked={filters.verifiedOnly}
                    onCheckedChange={(checked) => {
                      setFilters({ ...filters, verifiedOnly: !!checked })
                    }}
                  />
                  <label
                    htmlFor="verified-only"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center"
                  >
                    <Shield className="mr-1 h-4 w-4 text-blue-500" />
                    Verified traders only
                  </label>
                </div>
              </div>
            </div>

            <div className="flex justify-end mt-6">
              <Button
                variant="outline"
                onClick={() =>
                  setFilters({
                    minRoi: 0,
                    maxRoi: 100,
                    minWinRate: 0,
                    maxWinRate: 100,
                    riskLevels: ["Low", "Medium", "High"],
                    verifiedOnly: false,
                    minFollowers: 0,
                    markets: ["Stocks", "Forex", "Crypto", "Commodities", "Options"],
                  })
                }
              >
                Reset Filters
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Traders</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="new">New Traders</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[250px]">Trader</TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort("roi")}>
                        <div className="flex items-center">
                          ROI (30d)
                          {renderSortIcon("roi")}
                        </div>
                      </TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort("winRate")}>
                        <div className="flex items-center">
                          Win Rate
                          {renderSortIcon("winRate")}
                        </div>
                      </TableHead>
                      <TableHead>Risk Level</TableHead>
                      <TableHead className="cursor-pointer" onClick={() => handleSort("followers")}>
                        <div className="flex items-center">
                          Followers
                          {renderSortIcon("followers")}
                        </div>
                      </TableHead>
                      <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredTraders.length > 0 ? (
                      filteredTraders.map((trader) => (
                        <TableRow
                          key={trader.id}
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => handleViewTrader(trader.id)}
                        >
                          <TableCell className="font-medium" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarImage src={trader.avatar} alt={trader.name} />
                                <AvatarFallback>{trader.initials}</AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium flex items-center">
                                  {trader.name}
                                  {trader.verified && (
                                    <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700">
                                      <Shield className="mr-1 h-3 w-3" />
                                      Verified
                                    </Badge>
                                  )}
                                </div>
                                <div className="text-xs text-muted-foreground flex items-center gap-2">
                                  <span>{trader.trades} trades</span>
                                  {trader.tradingStyle && (
                                    <>
                                      <span>•</span>
                                      <span>{trader.tradingStyle}</span>
                                    </>
                                  )}
                                </div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1 font-medium text-green-600">
                              {trader.roi}% <TrendingUp className="h-4 w-4" />
                            </div>
                          </TableCell>
                          <TableCell>{trader.winRate}%</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                trader.riskLevel === "Low"
                                  ? "outline"
                                  : trader.riskLevel === "Medium"
                                    ? "secondary"
                                    : "destructive"
                              }
                            >
                              {trader.riskLevel === "High" && <AlertTriangle className="mr-1 h-3 w-3" />}
                              {trader.riskLevel}
                            </Badge>
                          </TableCell>
                          <TableCell>{trader.followers.toLocaleString()}</TableCell>
                          <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end gap-2">
                              <Button
                                variant={trader.following ? "outline" : "default"}
                                size="sm"
                                onClick={() => handleToggleFollow(trader.id, trader.name, trader.following)}
                              >
                                {trader.following ? (
                                  <>
                                    <StarOff className="mr-1 h-4 w-4" />
                                    Unfollow
                                  </>
                                ) : (
                                  <>
                                    <Star className="mr-1 h-4 w-4" />
                                    Follow
                                  </>
                                )}
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={6} className="h-24 text-center">
                          No traders found matching your criteria.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="following" className="mt-6">
          {/* Similar table structure for following traders */}
        </TabsContent>

        <TabsContent value="recommended" className="mt-6">
          {/* Similar table structure for recommended traders */}
        </TabsContent>

        <TabsContent value="trending" className="mt-6">
          {/* Similar table structure for trending traders */}
        </TabsContent>

        <TabsContent value="new" className="mt-6">
          {/* Similar table structure for new traders */}
        </TabsContent>
      </Tabs>
    </div>
  )
}

