"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"
import { Award, TrendingUp, TrendingDown, Users, Clock, BarChart3, LineChart, PieChart, Share2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"

// Mock data for trader profile
const mockTraderProfile = {
  id: "trader-1",
  name: "Alex Johnson",
  image: "/placeholder.svg?height=80&width=80",
  verified: true,
  bio: "Professional forex trader with 8+ years of experience. Specializing in swing trading major currency pairs with a focus on technical analysis and market sentiment.",
  performance: {
    monthly: 12.5,
    quarterly: 28.7,
    yearly: 67.3,
    total: 87.3,
    drawdown: {
      current: 3.2,
      maximum: 15.8,
    },
  },
  statistics: {
    winRate: 68,
    profitFactor: 2.3,
    averageTrade: {
      win: 2.1,
      loss: -0.9,
    },
    tradesPerWeek: 15,
    averageHoldingTime: "2.5 days",
  },
  followers: 1245,
  tradingStyle: "Swing Trading",
  markets: ["EUR/USD", "GBP/USD", "USD/JPY", "BTC/USD"],
  riskLevel: "Medium",
  tradingSince: "2015",
  subscription: {
    fee: 29.99,
    period: "monthly",
  },
  recentTrades: [
    {
      id: "trade-1",
      symbol: "EUR/USD",
      type: "buy",
      openPrice: 1.0876,
      closePrice: 1.0923,
      profit: 0.47,
      date: "2023-11-15",
    },
    {
      id: "trade-2",
      symbol: "GBP/USD",
      type: "sell",
      openPrice: 1.2345,
      closePrice: 1.2298,
      profit: 0.38,
      date: "2023-11-14",
    },
    {
      id: "trade-3",
      symbol: "USD/JPY",
      type: "buy",
      openPrice: 149.21,
      closePrice: 148.95,
      profit: -0.17,
      date: "2023-11-13",
    },
    {
      id: "trade-4",
      symbol: "BTC/USD",
      type: "buy",
      openPrice: 35420,
      closePrice: 36780,
      profit: 3.84,
      date: "2023-11-12",
    },
  ],
}

const subscriptionSchema = z.object({
  copyRatio: z.number().min(0.1).max(2),
  maxRiskPerTrade: z.number().min(1).max(100),
  enableStopLoss: z.boolean(),
  stopLossPercentage: z.number().min(5).max(50),
  tradingCapital: z.string().min(1, "Trading capital is required"),
})

type SubscriptionFormValues = z.infer<typeof subscriptionSchema>

export default function TraderProfilePage() {
  const params = useParams()
  const traderId = params.traderId as string

  const [isLoading, setIsLoading] = useState(true)
  const [trader, setTrader] = useState<typeof mockTraderProfile | null>(null)
  const [isSubscribing, setIsSubscribing] = useState(false)

  useEffect(() => {
    // Simulate API call
    const timer = setTimeout(() => {
      setTrader(mockTraderProfile)
      setIsLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [traderId])

  const form = useForm<SubscriptionFormValues>({
    resolver: zodResolver(subscriptionSchema),
    defaultValues: {
      copyRatio: 1,
      maxRiskPerTrade: 5,
      enableStopLoss: true,
      stopLossPercentage: 20,
      tradingCapital: "1000",
    },
  })

  const enableStopLoss = form.watch("enableStopLoss")

  const onSubmit = async (data: SubscriptionFormValues) => {
    setIsSubscribing(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    console.log("Subscription data:", {
      traderId,
      ...data,
    })

    setIsSubscribing(false)
    // In a real app, you would redirect to a success page or show a success message
  }

  if (isLoading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="flex flex-col md:flex-row gap-8">
          <div className="w-full md:w-2/3 space-y-6">
            <Skeleton className="h-48 rounded-lg" />
            <Skeleton className="h-64 rounded-lg" />
          </div>
          <div className="w-full md:w-1/3 space-y-6">
            <Skeleton className="h-64 rounded-lg" />
            <Skeleton className="h-48 rounded-lg" />
          </div>
        </div>
      </div>
    )
  }

  if (!trader) {
    return (
      <div className="container mx-auto py-8 px-4">
        <h1 className="text-2xl font-bold">Trader not found</h1>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-2/3 space-y-6">
          {/* Trader Profile Header */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={trader.image} alt={trader.name} />
                  <AvatarFallback>{trader.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="space-y-2 flex-1">
                  <div className="flex items-center flex-wrap gap-2">
                    <h1 className="text-2xl font-bold">{trader.name}</h1>
                    {trader.verified && (
                      <Badge variant="outline" className="bg-blue-50 text-blue-700">
                        <Award className="mr-1 h-4 w-4" />
                        Verified Trader
                      </Badge>
                    )}
                  </div>
                  <p className="text-muted-foreground">{trader.bio}</p>
                  <div className="flex flex-wrap gap-2 pt-2">
                    <div className="flex items-center text-sm">
                      <Users className="mr-1 h-4 w-4 text-muted-foreground" />
                      <span>{trader.followers} followers</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Clock className="mr-1 h-4 w-4 text-muted-foreground" />
                      <span>Trading since {trader.tradingSince}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <BarChart3 className="mr-1 h-4 w-4 text-muted-foreground" />
                      <span>{trader.tradingStyle}</span>
                    </div>
                  </div>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Share2 className="mr-2 h-4 w-4" />
                      Copy Trades
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <DialogTitle>Copy {trader.name}'s Trades</DialogTitle>
                      <DialogDescription>
                        Configure your copy trading settings to start copying trades from this trader.
                      </DialogDescription>
                    </DialogHeader>
                    <Form {...form}>
                      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                        <FormField
                          control={form.control}
                          name="tradingCapital"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Trading Capital (USD)</FormLabel>
                              <FormControl>
                                <Input type="number" {...field} />
                              </FormControl>
                              <FormDescription>The amount you want to allocate for copy trading</FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="copyRatio"
                          render={({ field: { value, onChange } }) => (
                            <FormItem>
                              <FormLabel>Copy Ratio: {value}x</FormLabel>
                              <FormControl>
                                <Slider
                                  value={[value]}
                                  min={0.1}
                                  max={2}
                                  step={0.1}
                                  onValueChange={(vals) => onChange(vals[0])}
                                />
                              </FormControl>
                              <FormDescription>
                                Multiply or reduce the position size relative to the trader
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="maxRiskPerTrade"
                          render={({ field: { value, onChange } }) => (
                            <FormItem>
                              <FormLabel>Max Risk Per Trade: {value}%</FormLabel>
                              <FormControl>
                                <Slider
                                  value={[value]}
                                  min={1}
                                  max={20}
                                  step={1}
                                  onValueChange={(vals) => onChange(vals[0])}
                                />
                              </FormControl>
                              <FormDescription>
                                Maximum percentage of your capital to risk on a single trade
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="enableStopLoss"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Enable Stop Loss</FormLabel>
                                <FormDescription>
                                  Automatically stop copying if drawdown exceeds threshold
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch checked={field.value} onCheckedChange={field.onChange} />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                        {enableStopLoss && (
                          <FormField
                            control={form.control}
                            name="stopLossPercentage"
                            render={({ field: { value, onChange } }) => (
                              <FormItem>
                                <FormLabel>Stop Loss Threshold: {value}%</FormLabel>
                                <FormControl>
                                  <Slider
                                    value={[value]}
                                    min={5}
                                    max={50}
                                    step={5}
                                    onValueChange={(vals) => onChange(vals[0])}
                                  />
                                </FormControl>
                                <FormDescription>
                                  Stop copying if your account drawdown reaches this percentage
                                </FormDescription>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        )}
                        <DialogFooter>
                          <Button type="submit" disabled={isSubscribing}>
                            {isSubscribing ? "Processing..." : "Start Copying"}
                          </Button>
                        </DialogFooter>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>
            </CardContent>
          </Card>

          {/* Performance Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Performance</CardTitle>
              <CardDescription>Historical trading performance and key metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Monthly Return</p>
                  <p
                    className={`text-2xl font-semibold flex items-center ${trader.performance.monthly >= 0 ? "text-green-600" : "text-red-600"}`}
                  >
                    {trader.performance.monthly >= 0 ? (
                      <TrendingUp className="mr-1 h-5 w-5" />
                    ) : (
                      <TrendingDown className="mr-1 h-5 w-5" />
                    )}
                    {trader.performance.monthly >= 0 ? "+" : ""}
                    {trader.performance.monthly.toFixed(2)}%
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Quarterly Return</p>
                  <p
                    className={`text-2xl font-semibold flex items-center ${trader.performance.quarterly >= 0 ? "text-green-600" : "text-red-600"}`}
                  >
                    {trader.performance.quarterly >= 0 ? (
                      <TrendingUp className="mr-1 h-5 w-5" />
                    ) : (
                      <TrendingDown className="mr-1 h-5 w-5" />
                    )}
                    {trader.performance.quarterly >= 0 ? "+" : ""}
                    {trader.performance.quarterly.toFixed(2)}%
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Yearly Return</p>
                  <p
                    className={`text-2xl font-semibold flex items-center ${trader.performance.yearly >= 0 ? "text-green-600" : "text-red-600"}`}
                  >
                    {trader.performance.yearly >= 0 ? (
                      <TrendingUp className="mr-1 h-5 w-5" />
                    ) : (
                      <TrendingDown className="mr-1 h-5 w-5" />
                    )}
                    {trader.performance.yearly >= 0 ? "+" : ""}
                    {trader.performance.yearly.toFixed(2)}%
                  </p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm text-muted-foreground">Total Return</p>
                  <p
                    className={`text-2xl font-semibold flex items-center ${trader.performance.total >= 0 ? "text-green-600" : "text-red-600"}`}
                  >
                    {trader.performance.total >= 0 ? (
                      <TrendingUp className="mr-1 h-5 w-5" />
                    ) : (
                      <TrendingDown className="mr-1 h-5 w-5" />
                    )}
                    {trader.performance.total >= 0 ? "+" : ""}
                    {trader.performance.total.toFixed(2)}%
                  </p>
                </div>
              </div>

              <div className="mt-8">
                <Tabs defaultValue="statistics">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="statistics">Statistics</TabsTrigger>
                    <TabsTrigger value="chart">Performance Chart</TabsTrigger>
                    <TabsTrigger value="trades">Recent Trades</TabsTrigger>
                  </TabsList>
                  <TabsContent value="statistics" className="pt-4">
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Win Rate</p>
                        <p className="text-lg font-medium">{trader.statistics.winRate}%</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Profit Factor</p>
                        <p className="text-lg font-medium">{trader.statistics.profitFactor}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Avg. Winning Trade</p>
                        <p className="text-lg font-medium text-green-600">+{trader.statistics.averageTrade.win}%</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Avg. Losing Trade</p>
                        <p className="text-lg font-medium text-red-600">{trader.statistics.averageTrade.loss}%</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Trades Per Week</p>
                        <p className="text-lg font-medium">{trader.statistics.tradesPerWeek}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Avg. Holding Time</p>
                        <p className="text-lg font-medium">{trader.statistics.averageHoldingTime}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Current Drawdown</p>
                        <p className="text-lg font-medium text-amber-600">{trader.performance.drawdown.current}%</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Maximum Drawdown</p>
                        <p className="text-lg font-medium text-amber-600">{trader.performance.drawdown.maximum}%</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Risk Level</p>
                        <p className="text-lg font-medium">{trader.riskLevel}</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="chart" className="pt-4">
                    <div className="flex items-center justify-center h-64 bg-muted/20 rounded-md">
                      <div className="text-center">
                        <LineChart className="h-10 w-10 mx-auto text-muted-foreground" />
                        <p className="mt-2 text-sm text-muted-foreground">Performance chart will be displayed here</p>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="trades" className="pt-4">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b">
                            <th className="text-left py-2 px-2">Symbol</th>
                            <th className="text-left py-2 px-2">Type</th>
                            <th className="text-left py-2 px-2">Entry</th>
                            <th className="text-left py-2 px-2">Exit</th>
                            <th className="text-right py-2 px-2">Profit</th>
                            <th className="text-right py-2 px-2">Date</th>
                          </tr>
                        </thead>
                        <tbody>
                          {trader.recentTrades.map((trade) => (
                            <tr key={trade.id} className="border-b">
                              <td className="py-2 px-2">{trade.symbol}</td>
                              <td className="py-2 px-2 capitalize">
                                <Badge variant={trade.type === "buy" ? "success" : "destructive"}>{trade.type}</Badge>
                              </td>
                              <td className="py-2 px-2">{trade.openPrice}</td>
                              <td className="py-2 px-2">{trade.closePrice}</td>
                              <td
                                className={`py-2 px-2 text-right ${trade.profit >= 0 ? "text-green-600" : "text-red-600"}`}
                              >
                                {trade.profit >= 0 ? "+" : ""}
                                {trade.profit}%
                              </td>
                              <td className="py-2 px-2 text-right">{trade.date}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="w-full md:w-1/3 space-y-6">
          {/* Subscription Card */}
          <Card>
            <CardHeader>
              <CardTitle>Subscription</CardTitle>
              <CardDescription>Copy trading subscription details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <p className="text-3xl font-bold">${trader.subscription.fee}</p>
                <p className="text-sm text-muted-foreground">per {trader.subscription.period}</p>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Subscription Fee</span>
                  <span>
                    ${trader.subscription.fee}/{trader.subscription.period}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Platform Fee</span>
                  <span>5%</span>
                </div>
                <div className="flex justify-between text-sm font-medium">
                  <span>Total</span>
                  <span>
                    ${(trader.subscription.fee * 1.05).toFixed(2)}/{trader.subscription.period}
                  </span>
                </div>
              </div>
              <Button className="w-full">Subscribe & Copy Trades</Button>
              <p className="text-xs text-center text-muted-foreground">You can cancel your subscription at any time</p>
            </CardContent>
          </Card>

          {/* Markets Card */}
          <Card>
            <CardHeader>
              <CardTitle>Markets Traded</CardTitle>
              <CardDescription>Instruments this trader specializes in</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {trader.markets.map((market) => (
                  <Badge key={market} variant="outline">
                    {market}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Allocation Pie Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Portfolio Allocation</CardTitle>
              <CardDescription>Current asset allocation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-center h-48 bg-muted/20 rounded-md">
                <div className="text-center">
                  <PieChart className="h-10 w-10 mx-auto text-muted-foreground" />
                  <p className="mt-2 text-sm text-muted-foreground">Allocation chart will be displayed here</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

